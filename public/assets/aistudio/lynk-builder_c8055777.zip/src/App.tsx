import { useCallback, useEffect, useRef, useState } from 'react';
import { TopBar } from './components/TopBar';
import { LeftSidebar } from './components/LeftSidebar';
import { MobileCanvas } from './components/MobileCanvas';
import { RightInspector } from './components/RightInspector';
import { DomainAndAdsModal } from './components/DomainAndAdsModal';
import { WaTrafficDashboardModal } from './components/WaTrafficDashboardModal';
import { AccessSettingsModal } from './components/AccessSettingsModal';
import {
  CodeModal,
  ImportModal,
  ImportedPayload,
  PreviewModal,
  ProjectsModal,
} from './components/Modals';
import {
  AccessSettingsConfig,
  AdvanceOptions,
  BlockType,
  BottomNavbarConfig,
  BuilderBlock,
  BuilderProject,
  PageTheme,
  ProjectAdsConfig,
  ProjectPublishingConfig,
  ProjectRecord,
  WorkspaceBundle,
} from './types/builder';
import {
  INITIAL_PROJECT,
  PREBUILT_SECTIONS,
  PrebuiltSection,
  createBlock,
  createId,
  resolveBottomNavbar,
} from './data/presets';
import {
  deleteBlockById,
  duplicateBlockById,
  findBlockById,
  insertBlocksAtTarget,
  insertChildIntoContainer,
  moveBlockInTree,
  reorderBlockInTree,
  updateBlockById,
} from './utils/treeHelpers';
import { generateProjectHtml } from './utils/htmlExporter';
import {
  cloneProjectForNewBusiness,
  createBlankProject,
  downloadTextFile,
  getInitialWorkspaceSync,
  loadWorkspaceFromIndexedDb,
  normalizeProject,
  saveWorkspaceToIndexedDb,
  slugifyFilename,
} from './utils/projectStorage';
import {
  deleteProjectOnServer,
  saveProjectToServer,
} from './utils/analyticsClient';
import {
  resolveProjectPublishing,
  sanitizeSlug,
} from './utils/publishingHelpers';
import {
  createDefaultAccessSettings,
  fetchAccessSettings,
  saveAccessSettings,
} from './utils/accessControl';
import { copyTextToClipboard } from './utils/clipboardHelpers';

export default function App() {
  const [workspace, setWorkspace] = useState<WorkspaceBundle>(() => getInitialWorkspaceSync());
  const isHydratedRef = useRef(false);
  const hasUserMutatedBeforeHydrationRef = useRef(false);
  const [selectedId, setSelectedId] = useState<string | null>(
    () => workspace.projects[0]?.project.blocks[0]?.id ?? null
  );
  const [copied, setCopied] = useState(false);
  const [copyWarning, setCopyWarning] = useState<string | null>(null);
  const [saveToast, setSaveToast] = useState<{ type: 'ok' | 'warn'; text: string } | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [showCode, setShowCode] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [showProjects, setShowProjects] = useState(false);
  const [showDomainAds, setShowDomainAds] = useState(false);
  const [showDashboard, setShowDashboard] = useState(false);
  const [showAccessSettings, setShowAccessSettings] = useState(false);
  const [accessSettings, setAccessSettings] = useState<AccessSettingsConfig>(() =>
    createDefaultAccessSettings()
  );
  const [inspectorMode, setInspectorMode] = useState<'element' | 'navbar'>('element');
  const [activeNavItemId, setActiveNavItemId] = useState<string>('nav_galeri');

  const activeRecord =
    workspace.projects.find((p) => p.id === workspace.activeProjectId) ?? workspace.projects[0];
  const project = activeRecord.project;
  const bottomNavbar = resolveBottomNavbar(project);
  const activePublishing = resolveProjectPublishing(project);
  const hasUnsavedChanges = activeRecord.updatedAt > (activeRecord.lastSavedAt ?? 0);

  useEffect(() => {
    let cancelled = false;
    loadWorkspaceFromIndexedDb().then((loaded) => {
      if (cancelled) return;
      isHydratedRef.current = true;
      if (hasUserMutatedBeforeHydrationRef.current) {
        return;
      }
      setWorkspace(loaded);
      const loadedActive =
        loaded.projects.find((p) => p.id === loaded.activeProjectId) ?? loaded.projects[0];
      setSelectedId(loadedActive?.project.blocks[0]?.id ?? null);
    });
    fetchAccessSettings().then((loadedAccess) => {
      if (!cancelled) {
        setAccessSettings(loadedAccess);
      }
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!isHydratedRef.current) return;
    void saveWorkspaceToIndexedDb(workspace);
  }, [workspace]);

  const commitProject = (updater: (prev: BuilderProject) => BuilderProject) => {
    if (!isHydratedRef.current) {
      hasUserMutatedBeforeHydrationRef.current = true;
    }
    setWorkspace((prev) => {
      const idx = prev.projects.findIndex((p) => p.id === prev.activeProjectId);
      const targetIdx = idx >= 0 ? idx : 0;
      const currentProj = prev.projects[targetIdx].project;
      const nextProj = updater(currentProj);

      const nextProjects = [...prev.projects];
      nextProjects[targetIdx] = {
        ...nextProjects[targetIdx],
        project: nextProj,
        updatedAt: Date.now(),
      };

      return {
        ...prev,
        projects: nextProjects,
      };
    });
  };

  const handleSelectProject = (id: string) => {
    if (id === workspace.activeProjectId) return;
    const target = workspace.projects.find((p) => p.id === id);
    if (!target) return;
    if (!isHydratedRef.current) hasUserMutatedBeforeHydrationRef.current = true;
    setWorkspace((prev) => ({ ...prev, activeProjectId: id }));
    setSelectedId(target.project.blocks[0]?.id ?? null);
  };

  const makeUniqueSlug = (baseSlug: string, excludeId?: string) => {
    const used = new Set(
      workspace.projects
        .filter((p) => p.id !== excludeId)
        .map((p) => sanitizeSlug(p.project.publishing?.slug || p.project.title, ''))
    );
    const clean = sanitizeSlug(baseSlug, 'unit-usaha');
    if (!used.has(clean)) return clean;
    let i = 2;
    while (used.has(`${clean}-${i}`)) i += 1;
    return `${clean}-${i}`;
  };

  const handleCreateProject = (mode: 'template' | 'blank') => {
    if (!isHydratedRef.current) hasUserMutatedBeforeHydrationRef.current = true;
    const nextNum = workspace.projects.length + 1;
    const title = `Usaha #${nextNum}`;
    const rawProj =
      mode === 'template'
        ? cloneProjectForNewBusiness(INITIAL_PROJECT, title)
        : createBlankProject(title);
    const uniqueSlug = makeUniqueSlug(rawProj.publishing?.slug || title);
    const newProj: BuilderProject = {
      ...rawProj,
      publishing: {
        ...resolveProjectPublishing(rawProj),
        slug: uniqueSlug,
      },
    };
    const newId = createId('proj');
    const now = Date.now();
    const nextRecord: ProjectRecord = {
      id: newId,
      project: newProj,
      updatedAt: now,
      lastSavedAt: 0,
    };
    setWorkspace((prev) => ({
      ...prev,
      activeProjectId: newId,
      projects: [...prev.projects, nextRecord],
    }));
    setSelectedId(newProj.blocks[0]?.id ?? null);
  };

  const handleDuplicateProject = (id: string) => {
    if (!isHydratedRef.current) hasUserMutatedBeforeHydrationRef.current = true;
    const source = workspace.projects.find((p) => p.id === id);
    if (!source) return;
    const rawCloned = cloneProjectForNewBusiness(
      source.project,
      `${source.project.title || 'Usaha'} (Salinan)`
    );
    const uniqueSlug = makeUniqueSlug(rawCloned.publishing?.slug || rawCloned.title);
    const cloned: BuilderProject = {
      ...rawCloned,
      publishing: {
        ...resolveProjectPublishing(rawCloned),
        slug: uniqueSlug,
      },
    };
    const newId = createId('proj');
    const now = Date.now();
    const nextRecord: ProjectRecord = {
      id: newId,
      project: cloned,
      updatedAt: now,
      lastSavedAt: 0,
    };
    setWorkspace((prev) => ({
      ...prev,
      activeProjectId: newId,
      projects: [...prev.projects, nextRecord],
    }));
    setSelectedId(cloned.blocks[0]?.id ?? null);
  };

  const handleDeleteProject = (id: string) => {
    if (workspace.projects.length <= 1) return;
    if (!isHydratedRef.current) hasUserMutatedBeforeHydrationRef.current = true;
    const remaining = workspace.projects.filter((p) => p.id !== id);
    const isDeletingActive = id === workspace.activeProjectId;
    const nextActiveId = isDeletingActive ? remaining[0].id : workspace.activeProjectId;
    setWorkspace((prev) => ({
      ...prev,
      activeProjectId: nextActiveId,
      projects: remaining,
    }));
    void deleteProjectOnServer(id);
    if (isDeletingActive) {
      const nextProj = remaining[0].project;
      setSelectedId(nextProj.blocks[0]?.id ?? null);
    }
  };

  const handleSelectBlock = (id: string | null) => {
    setSelectedId(id);
    if (id) {
      setInspectorMode('element');
    }
  };

  const handleOpenNavbarSettings = (itemId?: string) => {
    setSelectedId(null);
    setInspectorMode('navbar');
    if (itemId) setActiveNavItemId(itemId);
  };

  const handleActivateNavbar = () => {
    commitProject((prev) => {
      const curNav = resolveBottomNavbar(prev);
      return {
        ...prev,
        bottomNavbar: { ...curNav, enabled: true },
      };
    });
    setSelectedId(null);
    setInspectorMode('navbar');
  };

  const handleUpdateBottomNavbar = (updater: (prev: BottomNavbarConfig) => BottomNavbarConfig) => {
    commitProject((prev) => ({
      ...prev,
      bottomNavbar: updater(resolveBottomNavbar(prev)),
    }));
  };

  const handleAddBlock = (
    type: BlockType,
    targetId?: string,
    position: 'before' | 'after' | 'inside' = 'inside'
  ) => {
    const newBlock = createBlock(type, project.theme);
    commitProject((prev) => {
      const curNav = resolveBottomNavbar(prev);
      const isNavTarget = targetId && curNav.items.some((it) => it.id === targetId);
      if (isNavTarget && position === 'inside') {
        return {
          ...prev,
          bottomNavbar: {
            ...curNav,
            items: curNav.items.map((it) =>
              it.id === targetId ? { ...it, children: [...it.children, newBlock] } : it
            ),
          },
        };
      }
      const nextBlocks = targetId
        ? position === 'inside'
          ? insertChildIntoContainer(prev.blocks, targetId, newBlock)
          : insertBlocksAtTarget(prev.blocks, [newBlock], targetId, position)
        : [...prev.blocks, newBlock];
      const nextNavItems = targetId
        ? curNav.items.map((it) => ({
            ...it,
            children:
              position === 'inside'
                ? insertChildIntoContainer(it.children, targetId, newBlock)
                : insertBlocksAtTarget(it.children, [newBlock], targetId, position),
          }))
        : curNav.items;
      return {
        ...prev,
        blocks: nextBlocks,
        bottomNavbar: prev.bottomNavbar ? { ...curNav, items: nextNavItems } : prev.bottomNavbar,
      };
    });
    setSelectedId(newBlock.id);
    setInspectorMode('element');
  };

  const handleAddSection = (
    section: PrebuiltSection,
    targetId?: string,
    position: 'before' | 'after' | 'inside' = 'after'
  ) => {
    const created = section.createBlocks(project.theme);
    commitProject((prev) => ({
      ...prev,
      blocks: targetId
        ? insertBlocksAtTarget(prev.blocks, created, targetId, position)
        : [...prev.blocks, ...created],
    }));
    if (created[0]) setSelectedId(created[0].id);
  };

  const handleDropSectionById = (
    sectionId: string,
    targetId?: string,
    position: 'before' | 'after' | 'inside' = 'after'
  ) => {
    const section = PREBUILT_SECTIONS.find((s) => s.id === sectionId);
    if (section) {
      handleAddSection(section, targetId, position);
    }
  };

  const handleReorderBlock = (
    draggedId: string,
    targetId: string,
    position: 'before' | 'after' | 'inside'
  ) => {
    commitProject((prev) => ({
      ...prev,
      blocks: reorderBlockInTree(prev.blocks, draggedId, targetId, position),
    }));
    setSelectedId(draggedId);
  };

  const remapBlocksForTheme = (
    blocks: BuilderBlock[],
    prevTheme: PageTheme,
    nextTheme: PageTheme
  ): BuilderBlock[] => {
    const eq = (a?: string, b?: string) =>
      Boolean(a && b && a.trim().toLowerCase() === b.trim().toLowerCase());

    return blocks.map((blk) => ({
      ...blk,
      style: {
        ...blk.style,
        textColor:
          blk.style.useThemeTextColor !== false || eq(blk.style.textColor, prevTheme.textColor)
            ? nextTheme.textColor
            : blk.style.textColor,
        backgroundColor: eq(blk.style.backgroundColor, prevTheme.cardBg)
          ? nextTheme.cardBg
          : blk.style.backgroundColor,
        borderColor: eq(blk.style.borderColor, prevTheme.borderColor)
          ? nextTheme.borderColor
          : blk.style.borderColor,
      },
      content: {
        ...blk.content,
        buttonBg: eq(blk.content.buttonBg, prevTheme.accentColor)
          ? nextTheme.accentColor
          : blk.content.buttonBg,
        buttonColor: eq(blk.content.buttonColor, prevTheme.accentColor)
          ? nextTheme.accentColor
          : blk.content.buttonColor,
        toggleButtonBg: eq(blk.content.toggleButtonBg, prevTheme.accentColor)
          ? nextTheme.accentColor
          : blk.content.toggleButtonBg,
        sheetTriggerBg: eq(blk.content.sheetTriggerBg, prevTheme.accentColor)
          ? nextTheme.accentColor
          : blk.content.sheetTriggerBg,
        socialColor: eq(blk.content.socialColor, prevTheme.accentColor)
          ? nextTheme.accentColor
          : blk.content.socialColor,
        lineColor: eq(blk.content.lineColor, prevTheme.borderColor)
          ? nextTheme.borderColor
          : blk.content.lineColor,
      },
      children: blk.children
        ? remapBlocksForTheme(blk.children, prevTheme, nextTheme)
        : undefined,
    }));
  };

  const handleSelectTheme = (theme: PageTheme) => {
    const eq = (a?: string, b?: string) =>
      Boolean(a && b && a.trim().toLowerCase() === b.trim().toLowerCase());
    commitProject((prev) => {
      const curNav = resolveBottomNavbar(prev);
      return {
        ...prev,
        theme,
        blocks: remapBlocksForTheme(prev.blocks, prev.theme, theme),
        bottomNavbar: {
          ...curNav,
          barBg: eq(curNav.barBg, prev.theme.cardBg) ? theme.cardBg : curNav.barBg,
          textColor: eq(curNav.textColor, prev.theme.textColor) ? theme.textColor : curNav.textColor,
          accentColor: eq(curNav.accentColor, prev.theme.accentColor)
            ? theme.accentColor
            : curNav.accentColor,
          borderColor: eq(curNav.borderColor, prev.theme.borderColor)
            ? theme.borderColor
            : curNav.borderColor,
          items: curNav.items.map((it) => ({
            ...it,
            children: remapBlocksForTheme(it.children, prev.theme, theme),
          })),
        },
      };
    });
  };

  const handleUpdateAdvanceOptions = (patch: Partial<AdvanceOptions>) => {
    commitProject((prev) => ({
      ...prev,
      advanceOptions: {
        ...prev.advanceOptions,
        ...patch,
      },
    }));
  };

  const handleUpdateBlock = (id: string, updater: (block: BuilderBlock) => BuilderBlock) => {
    commitProject((prev) => {
      const curNav = prev.bottomNavbar;
      return {
        ...prev,
        blocks: updateBlockById(prev.blocks, id, updater),
        bottomNavbar: curNav
          ? {
              ...curNav,
              items: curNav.items.map((it) => ({
                ...it,
                children: updateBlockById(it.children, id, updater),
              })),
            }
          : curNav,
      };
    });
  };

  const handleMoveBlock = (id: string, dir: 'up' | 'down') => {
    commitProject((prev) => {
      const curNav = prev.bottomNavbar;
      return {
        ...prev,
        blocks: moveBlockInTree(prev.blocks, id, dir),
        bottomNavbar: curNav
          ? {
              ...curNav,
              items: curNav.items.map((it) => ({
                ...it,
                children: moveBlockInTree(it.children, id, dir),
              })),
            }
          : curNav,
      };
    });
  };

  const handleDuplicateBlock = (id: string) => {
    const topRes = duplicateBlockById(project.blocks, id);
    if (topRes.clonedId) {
      commitProject((prev) => ({
        ...prev,
        blocks: topRes.nextBlocks,
      }));
      setSelectedId(topRes.clonedId);
      return;
    }
    const curNav = resolveBottomNavbar(project);
    let navClonedId: string | null = null;
    const nextNavItems = curNav.items.map((it) => {
      const res = duplicateBlockById(it.children, id);
      if (res.clonedId) navClonedId = res.clonedId;
      return { ...it, children: res.nextBlocks };
    });
    if (navClonedId) {
      commitProject((prev) => ({
        ...prev,
        bottomNavbar: { ...resolveBottomNavbar(prev), items: nextNavItems },
      }));
      setSelectedId(navClonedId);
    }
  };

  const handleDeleteBlock = (id: string) => {
    commitProject((prev) => {
      const curNav = prev.bottomNavbar;
      return {
        ...prev,
        blocks: deleteBlockById(prev.blocks, id),
        bottomNavbar: curNav
          ? {
              ...curNav,
              items: curNav.items.map((it) => ({
                ...it,
                children: deleteBlockById(it.children, id),
              })),
            }
          : curNav,
      };
    });
    if (selectedId === id) setSelectedId(null);
  };

  const handleBackup = () => {
    const json = JSON.stringify(project, null, 2);
    downloadTextFile(
      `${slugifyFilename(project.title, 'lynk-backup')}.json`,
      json,
      'application/json;charset=utf-8'
    );
  };

  const handleBackupAll = () => {
    const json = JSON.stringify(workspace, null, 2);
    downloadTextFile(
      `lynk-semua-usaha-${workspace.projects.length}.json`,
      json,
      'application/json;charset=utf-8'
    );
  };

  const showSaveToast = (type: 'ok' | 'warn', text: string) => {
    setSaveToast({ type, text });
    setTimeout(() => {
      setSaveToast((prev) => (prev?.text === text ? null : prev));
    }, 3000);
  };

  const persistActiveRecord = useCallback(
    async (targetRecord: ProjectRecord, publishNow = false): Promise<{ ok: boolean; error?: string }> => {
      setIsSaving(true);
      const html = generateProjectHtml(targetRecord.project, { projectId: targetRecord.id });
      const res = await saveProjectToServer(targetRecord, html, publishNow);
      const savedAt = res.savedAt || Date.now();

      setWorkspace((prev) => {
        const nextProjects = prev.projects.map((p) =>
          p.id === targetRecord.id
            ? {
                ...targetRecord,
                updatedAt: savedAt,
                lastSavedAt: savedAt,
              }
            : p
        );
        const nextWorkspace: WorkspaceBundle = {
          ...prev,
          projects: nextProjects,
        };
        void saveWorkspaceToIndexedDb(nextWorkspace);
        return nextWorkspace;
      });

      setIsSaving(false);
      return res;
    },
    []
  );

  const handleSaveProject = useCallback(async () => {
    const res = await persistActiveRecord(activeRecord, false);
    if (res.ok) {
      showSaveToast('ok', `Perubahan "${activeRecord.project.title}" berhasil disimpan.`);
    } else {
      showSaveToast('warn', res.error || 'Tersimpan lokal, sinkronisasi server tertunda.');
    }
  }, [activeRecord, persistActiveRecord]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        void handleSaveProject();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleSaveProject]);

  const handleApplyDomainAndAds = async (
    nextPublishing: ProjectPublishingConfig,
    nextAdsConfig: ProjectAdsConfig,
    publishNow: boolean
  ): Promise<{ ok: boolean; error?: string }> => {
    const now = Date.now();
    const updatedProject: BuilderProject = {
      ...activeRecord.project,
      publishing: nextPublishing,
      adsConfig: nextAdsConfig,
    };
    const updatedRecord: ProjectRecord = {
      ...activeRecord,
      project: updatedProject,
      updatedAt: now,
    };
    const res = await persistActiveRecord(updatedRecord, publishNow);
    if (res.ok) {
      showSaveToast(
        'ok',
        publishNow
          ? `Unit usaha tayang di /p/${nextPublishing.slug}`
          : 'Pengaturan Domain, Slug & Iklan tersimpan.'
      );
    }
    return res;
  };

  const handleSaveAccessSettings = async (nextSettings: AccessSettingsConfig) => {
    const res = await saveAccessSettings(nextSettings);
    setAccessSettings(res.settings);
    if (res.ok) {
      showSaveToast(
        'ok',
        res.settings.allUsersSuperAdmin
          ? 'Setting akses tersimpan — semua akun aktif sebagai Super Admin (Full Fitur).'
          : 'Setting akses akun berhasil disimpan.'
      );
    } else {
      showSaveToast('warn', res.error || 'Setting akses disimpan lokal.');
    }
    return res;
  };

  const handleDownloadHtml = (targetRecord: ProjectRecord) => {
    const html = generateProjectHtml(targetRecord.project, { projectId: targetRecord.id });
    downloadTextFile(
      `${slugifyFilename(targetRecord.project.title, 'halaman-usaha')}.html`,
      html,
      'text/html;charset=utf-8'
    );
  };

  const handleImportData = (payload: ImportedPayload) => {
    if (!isHydratedRef.current) hasUserMutatedBeforeHydrationRef.current = true;
    if (payload.kind === 'single') {
      const imported = normalizeProject(payload.project);
      const newId = createId('proj');
      const nextRecord: ProjectRecord = {
        id: newId,
        project: imported,
        updatedAt: Date.now(),
      };
      setWorkspace((prev) => ({
        ...prev,
        activeProjectId: newId,
        projects: [...prev.projects, nextRecord],
      }));
      setSelectedId(imported.blocks[0]?.id ?? null);
      return;
    }

    const importedRecords: ProjectRecord[] = payload.bundle.projects
      .filter((r) => r && r.project && Array.isArray(r.project.blocks) && r.project.theme)
      .map((r) => ({
        id: createId('proj'),
        project: normalizeProject(r.project),
        updatedAt: typeof r.updatedAt === 'number' ? r.updatedAt : Date.now(),
      }));

    if (importedRecords.length === 0) return;

    setWorkspace((prev) => ({
      ...prev,
      activeProjectId: importedRecords[0].id,
      projects: [...prev.projects, ...importedRecords],
    }));
    setSelectedId(importedRecords[0].project.blocks[0]?.id ?? null);
  };

  const handleCopyHtml = async () => {
    const html = generateProjectHtml(project, { projectId: activeRecord.id });
    const ok = await copyTextToClipboard(html);
    if (ok) {
      setCopyWarning(null);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } else {
      setShowCode(true);
      setCopyWarning('Browser membatasi akses clipboard otomatis. Gunakan tombol Salin Kode atau Unduh .html.');
      setTimeout(() => setCopyWarning(null), 4000);
    }
  };

  const findBlockAndNavParent = (): {
    block: BuilderBlock | null;
    navItemId: string | null;
    navItemLabel: string | null;
  } => {
    const topFound = findBlockById(project.blocks, selectedId);
    if (topFound) return { block: topFound, navItemId: null, navItemLabel: null };
    for (const navItem of bottomNavbar.items) {
      const childFound = findBlockById(navItem.children, selectedId);
      if (childFound) {
        return { block: childFound, navItemId: navItem.id, navItemLabel: navItem.label };
      }
    }
    return { block: null, navItemId: null, navItemLabel: null };
  };

  const {
    block: selectedBlock,
    navItemId: selectedParentNavId,
    navItemLabel: selectedParentNavLabel,
  } = findBlockAndNavParent();

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden bg-[#F7F9F8] text-slate-800 relative">
      <TopBar
        projectTitle={project.title}
        projectSlug={activePublishing.slug}
        isPublished={activePublishing.isPublished}
        projectCount={workspace.projects.length}
        onChangeTitle={(title) => commitProject((prev) => ({ ...prev, title }))}
        onOpenProjects={() => setShowProjects(true)}
        onOpenDomainAndAds={() => setShowDomainAds(true)}
        onOpenDashboard={() => setShowDashboard(true)}
        onOpenAccessSettings={() => setShowAccessSettings(true)}
        isAllSuperAdmin={accessSettings.allUsersSuperAdmin}
        onOpenImport={() => setShowImport(true)}
        onBackup={handleBackup}
        onCopyHtml={handleCopyHtml}
        onOpenCode={() => setShowCode(true)}
        copied={copied}
      />

      <div className="flex-1 flex overflow-hidden">
        <LeftSidebar
          blocks={project.blocks}
          selectedId={selectedId}
          currentTheme={project.theme}
          onAddBlock={(type) => handleAddBlock(type)}
          onAddSection={(section) => handleAddSection(section)}
          onSelectTheme={handleSelectTheme}
          onSelectBlock={handleSelectBlock}
          onMoveBlock={handleMoveBlock}
          onReorderBlock={handleReorderBlock}
          onDeleteBlock={handleDeleteBlock}
          bottomNavbarEnabled={bottomNavbar.enabled}
          onActivateNavbar={handleActivateNavbar}
        />

        <MobileCanvas
          blocks={project.blocks}
          theme={project.theme}
          advanceOptions={project.advanceOptions}
          bottomNavbar={bottomNavbar}
          inspectorMode={inspectorMode}
          selectedId={selectedId}
          hasUnsavedChanges={hasUnsavedChanges}
          isSaving={isSaving}
          onSaveProject={() => void handleSaveProject()}
          onOpenPreview={() => setShowPreview(true)}
          onSelectBlock={handleSelectBlock}
          onOpenNavbarSettings={handleOpenNavbarSettings}
          onMoveBlock={handleMoveBlock}
          onDuplicateBlock={handleDuplicateBlock}
          onDeleteBlock={handleDeleteBlock}
          onToggleFullBleed={(id) =>
            handleUpdateBlock(id, (blk) => {
              const nextFull = !blk.style.fullBleed;
              return {
                ...blk,
                style: {
                  ...blk.style,
                  fullBleed: nextFull,
                  widthPercent: nextFull ? 100 : blk.style.widthPercent,
                },
              };
            })
          }
          onDropNewBlock={handleAddBlock}
          onDropSection={handleDropSectionById}
          onReorderBlock={handleReorderBlock}
        />

        <RightInspector
          selectedBlock={selectedBlock}
          theme={project.theme}
          advanceOptions={project.advanceOptions}
          bottomNavbar={bottomNavbar}
          inspectorMode={inspectorMode}
          activeNavItemId={activeNavItemId}
          selectedParentNavId={selectedParentNavId}
          selectedParentNavLabel={selectedParentNavLabel}
          onChangeInspectorMode={setInspectorMode}
          onSelectNavItem={setActiveNavItemId}
          onUpdateBottomNavbar={handleUpdateBottomNavbar}
          onUpdateAdvanceOptions={handleUpdateAdvanceOptions}
          onUpdateBlock={handleUpdateBlock}
          onDuplicateBlock={handleDuplicateBlock}
          onAddChildToContainer={(containerId, type) => handleAddBlock(type, containerId)}
          onSelectBlock={handleSelectBlock}
        />
      </div>

      {showPreview && (
        <PreviewModal
          projectId={activeRecord.id}
          project={project}
          onClose={() => setShowPreview(false)}
        />
      )}
      {showCode && (
        <CodeModal
          projectId={activeRecord.id}
          project={project}
          onClose={() => setShowCode(false)}
        />
      )}
      {showImport && (
        <ImportModal onImport={handleImportData} onClose={() => setShowImport(false)} />
      )}
      {showProjects && (
        <ProjectsModal
          projects={workspace.projects}
          activeProjectId={workspace.activeProjectId}
          onSelectProject={handleSelectProject}
          onCreateProject={handleCreateProject}
          onDuplicateProject={handleDuplicateProject}
          onDeleteProject={handleDeleteProject}
          onDownloadHtml={handleDownloadHtml}
          onOpenDomainAndAds={(id) => {
            handleSelectProject(id);
            setShowDomainAds(true);
          }}
          onOpenDashboard={() => setShowDashboard(true)}
          onBackupAll={handleBackupAll}
          onOpenImport={() => setShowImport(true)}
          onClose={() => setShowProjects(false)}
        />
      )}
      {showDomainAds && (
        <DomainAndAdsModal
          activeRecord={activeRecord}
          allProjects={workspace.projects}
          onApplySettings={handleApplyDomainAndAds}
          onClose={() => setShowDomainAds(false)}
        />
      )}
      {showDashboard && (
        <WaTrafficDashboardModal
          projects={workspace.projects}
          activeProjectId={workspace.activeProjectId}
          onSelectProject={handleSelectProject}
          onOpenDomainSettings={(id) => {
            handleSelectProject(id);
            setShowDomainAds(true);
          }}
          onClose={() => setShowDashboard(false)}
        />
      )}
      {showAccessSettings && (
        <AccessSettingsModal
          settings={accessSettings}
          projects={workspace.projects}
          onSaveSettings={handleSaveAccessSettings}
          onClose={() => setShowAccessSettings(false)}
        />
      )}
      {saveToast && (
        <div
          className={`fixed bottom-4 left-1/2 -translate-x-1/2 z-[60] px-4 py-2 rounded-xl text-xs font-semibold shadow-lg border ${
            saveToast.type === 'ok'
              ? 'bg-emerald-950 text-emerald-50 border-emerald-700/60'
              : 'bg-amber-950 text-amber-50 border-amber-700/60'
          }`}
        >
          {saveToast.text}
        </div>
      )}
      {copyWarning && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[60] px-4 py-2 rounded-xl bg-amber-950 text-amber-50 text-xs font-medium shadow-lg border border-amber-700/60">
          {copyWarning}
        </div>
      )}
    </div>
  );
}
