import {
  DEFAULT_ADVANCE_OPTIONS,
  INITIAL_PROJECT,
  createDefaultBottomNavbar,
  createId,
  resolveBottomNavbar,
} from '../data/presets';
import { BuilderBlock, BuilderProject, ProjectRecord, WorkspaceBundle } from '../types/builder';
import {
  DEFAULT_ADS_CONFIG,
  createDefaultPublishingConfig,
  resolveProjectAds,
  resolveProjectPublishing,
  sanitizeSlug,
} from './publishingHelpers';

const LEGACY_STORAGE_KEY = 'lynk_builder_project_v2';
const IDB_NAME = 'lynk_builder_idb';
const IDB_VERSION = 1;
const IDB_STORE = 'workspace';
const IDB_KEY = 'state';

function cloneBlocksWithNewIds(blocks: BuilderBlock[]): BuilderBlock[] {
  return blocks.map((blk) => ({
    ...blk,
    id: createId(blk.type.slice(0, 3)),
    style: { ...blk.style },
    content: {
      ...blk.content,
      catalogItems: blk.content.catalogItems?.map((it) => ({
        ...it,
        gallery: it.gallery ? [...it.gallery] : undefined,
      })),
      socialItems: blk.content.socialItems?.map((it) => ({ ...it })),
      carouselItems: blk.content.carouselItems?.map((it) => ({ ...it })),
      socialFeedPosts: blk.content.socialFeedPosts?.map((it) => ({ ...it })),
      socialFollowerAccounts: blk.content.socialFollowerAccounts?.map((it) => ({
        ...it,
        id: createId('sfa'),
      })),
      catalogShippingOptions: blk.content.catalogShippingOptions?.map((it) => ({ ...it })),
    },
    children: blk.children ? cloneBlocksWithNewIds(blk.children) : undefined,
  }));
}

export function normalizeProject(raw: BuilderProject): BuilderProject {
  const title = typeof raw.title === 'string' && raw.title.trim() ? raw.title : 'Halaman Usaha';
  const baseNormalized: BuilderProject = {
    title,
    theme: raw.theme,
    blocks: Array.isArray(raw.blocks) ? raw.blocks : [],
    advanceOptions: {
      ...DEFAULT_ADVANCE_OPTIONS,
      ...(raw.advanceOptions ?? {}),
    },
    bottomNavbar: raw.bottomNavbar,
    publishing: raw.publishing,
    adsConfig: raw.adsConfig,
  };
  return {
    ...baseNormalized,
    bottomNavbar: resolveBottomNavbar(baseNormalized),
    publishing: resolveProjectPublishing(baseNormalized),
    adsConfig: resolveProjectAds(baseNormalized),
  };
}

export function cloneProjectForNewBusiness(
  source: BuilderProject,
  nextTitle: string
): BuilderProject {
  const normalized = normalizeProject(source);
  const srcAds = resolveProjectAds(normalized);
  const srcNav = resolveBottomNavbar(normalized);
  return {
    title: nextTitle,
    theme: { ...normalized.theme },
    advanceOptions: { ...normalized.advanceOptions },
    blocks: cloneBlocksWithNewIds(normalized.blocks),
    bottomNavbar: {
      ...srcNav,
      items: srcNav.items.map((it) => ({
        ...it,
        children: cloneBlocksWithNewIds(it.children),
      })),
    },
    publishing: {
      ...createDefaultPublishingConfig(nextTitle),
      slug: sanitizeSlug(nextTitle, 'unit-usaha'),
      customDomain: '',
      useCustomDomain: false,
      isPublished: false,
    },
    adsConfig: {
      ...srcAds,
    },
  };
}

export function createBlankProject(title: string): BuilderProject {
  return {
    title,
    theme: { ...INITIAL_PROJECT.theme },
    advanceOptions: { ...DEFAULT_ADVANCE_OPTIONS },
    blocks: [],
    bottomNavbar: createDefaultBottomNavbar(INITIAL_PROJECT.theme, false),
    publishing: createDefaultPublishingConfig(title),
    adsConfig: { ...DEFAULT_ADS_CONFIG },
  };
}

export function readLegacyLocalProject(): BuilderProject | null {
  try {
    const raw = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as BuilderProject;
    if (parsed && Array.isArray(parsed.blocks) && parsed.theme) {
      return normalizeProject(parsed);
    }
  } catch {
    // Ignore invalid JSON
  }
  return null;
}

export function getInitialWorkspaceSync(): WorkspaceBundle {
  const legacy = readLegacyLocalProject();
  const starter = legacy ?? normalizeProject(INITIAL_PROJECT);
  const firstId = createId('proj');
  const now = Date.now();
  return {
    version: 1,
    activeProjectId: firstId,
    projects: [
      {
        id: firstId,
        project: starter,
        updatedAt: now,
        lastSavedAt: now,
      },
    ],
  };
}

function openWorkspaceDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB tidak tersedia'));
      return;
    }
    const req = indexedDB.open(IDB_NAME, IDB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(IDB_STORE)) {
        db.createObjectStore(IDB_STORE);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error('Gagal membuka IndexedDB'));
  });
}

function normalizeWorkspace(raw: unknown): WorkspaceBundle | null {
  if (!raw || typeof raw !== 'object') return null;
  const candidate = raw as Partial<WorkspaceBundle>;
  if (!Array.isArray(candidate.projects) || candidate.projects.length === 0) return null;

  const validRecords: ProjectRecord[] = [];
  for (const item of candidate.projects) {
    if (
      item &&
      typeof item.id === 'string' &&
      item.project &&
      Array.isArray(item.project.blocks) &&
      item.project.theme
    ) {
      const updated = typeof item.updatedAt === 'number' ? item.updatedAt : Date.now();
      validRecords.push({
        id: item.id,
        project: normalizeProject(item.project),
        updatedAt: updated,
        lastSavedAt: typeof item.lastSavedAt === 'number' ? item.lastSavedAt : updated,
      });
    }
  }

  if (validRecords.length === 0) return null;
  const hasActive = validRecords.some((p) => p.id === candidate.activeProjectId);
  return {
    version: 1,
    activeProjectId: hasActive && candidate.activeProjectId ? candidate.activeProjectId : validRecords[0].id,
    projects: validRecords,
  };
}

export async function loadWorkspaceFromIndexedDb(): Promise<WorkspaceBundle> {
  try {
    const db = await openWorkspaceDb();
    const stored = await new Promise<unknown>((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const store = tx.objectStore(IDB_STORE);
      const req = store.get(IDB_KEY);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    db.close();

    const normalized = normalizeWorkspace(stored);
    if (normalized) {
      return normalized;
    }
  } catch {
    // Fallback to legacy localStorage migration
  }

  const migrated = getInitialWorkspaceSync();
  await saveWorkspaceToIndexedDb(migrated);
  return migrated;
}

export async function saveWorkspaceToIndexedDb(workspace: WorkspaceBundle): Promise<void> {
  try {
    const active = workspace.projects.find((p) => p.id === workspace.activeProjectId);
    if (active) {
      try {
        localStorage.setItem(LEGACY_STORAGE_KEY, JSON.stringify(active.project));
      } catch {
        // Ignore localStorage 5MB quota limit; IndexedDB holds full capacity
      }
    }

    const db = await openWorkspaceDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      const store = tx.objectStore(IDB_STORE);
      store.put(workspace, IDB_KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch {
    // Ignore storage write failure in restricted contexts
  }
}

export function downloadTextFile(filename: string, content: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function slugifyFilename(title: string, fallback = 'halaman-usaha'): string {
  return (
    title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || fallback
  );
}
