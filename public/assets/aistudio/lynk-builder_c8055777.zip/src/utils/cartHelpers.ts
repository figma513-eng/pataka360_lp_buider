import {
  BlockContent,
  CatalogCartButtonSize,
  CatalogItem,
  CatalogProductType,
  CatalogShippingOptionConfig,
  ShippingMethodId,
} from '../types/builder';

export type { CatalogShippingOptionConfig, ShippingMethodId };

export interface CartButtonMetrics {
  gridPadding: string;
  gridFontSize: number;
  gridRadius: number;
  gridGap: number;
  gridIconSize: number;
  iconBoxSize: number;
  iconBoxRadius: number;
  iconOnlySize: number;
  compactPadding: string;
  compactRadius: number;
  compactIconSize: number;
}

export function resolveCartButtonMetrics(
  size: CatalogCartButtonSize = 'md'
): CartButtonMetrics {
  if (size === 'sm') {
    return {
      gridPadding: '4px 8px',
      gridFontSize: 10,
      gridRadius: 6,
      gridGap: 4,
      gridIconSize: 11,
      iconBoxSize: 26,
      iconBoxRadius: 6,
      iconOnlySize: 12,
      compactPadding: '6px 8px',
      compactRadius: 6,
      compactIconSize: 12,
    };
  }
  if (size === 'lg') {
    return {
      gridPadding: '10px 12px',
      gridFontSize: 13,
      gridRadius: 10,
      gridGap: 6,
      gridIconSize: 15,
      iconBoxSize: 40,
      iconBoxRadius: 10,
      iconOnlySize: 17,
      compactPadding: '10px 13px',
      compactRadius: 10,
      compactIconSize: 16,
    };
  }
  return {
    gridPadding: '7px 10px',
    gridFontSize: 11,
    gridRadius: 8,
    gridGap: 5,
    gridIconSize: 13,
    iconBoxSize: 32,
    iconBoxRadius: 8,
    iconOnlySize: 14,
    compactPadding: '8px 10px',
    compactRadius: 8,
    compactIconSize: 14,
  };
}

export interface ShippingOption {
  id: ShippingMethodId;
  title: string;
  subtitle?: string;
}

export const SHIPPING_OPTIONS: ShippingOption[] = [
  {
    id: 'makan_ditempat',
    title: 'Makan di tempat',
  },
  {
    id: 'ambil_sendiri',
    title: 'Ambil sendiri ke lokasi',
  },
  {
    id: 'kurir_sendiri',
    title: 'Pesan kurir sendiri',
  },
  {
    id: 'gosend_penjual',
    title: 'Dikirim Via Gosend Oleh Penjual',
  },
];

export const DEFAULT_SHIPPING_NOTE =
  'Biaya makanan / pesanan tidak termasuk biaya kirim (kurir).';

export const DEFAULT_CATALOG_SHIPPING_OPTIONS: CatalogShippingOptionConfig[] = [
  {
    id: 'makan_ditempat',
    enabled: true,
    label: 'Makan di tempat',
    askArrivalTime: true,
    arrivalTimeLabel: 'Waktu Kedatangan',
    arrivalTimePlaceholder: 'Contoh: 18:30 WIB',
    askGuestCount: true,
    guestCountLabel: 'Jumlah Orang',
    guestCountPlaceholder: 'Contoh: 4 orang',
    checklistEnabled: false,
    checklistText: '',
    noteTitle: 'Catatan:',
    noteText: 'Durasi masak ± 30 menit',
  },
  {
    id: 'ambil_sendiri',
    enabled: true,
    label: 'Ambil sendiri ke lokasi',
    askArrivalTime: true,
    arrivalTimeLabel: 'Diambil Jam Berapa',
    arrivalTimePlaceholder: 'Contoh: 17:00 WIB',
    askGuestCount: false,
    guestCountLabel: 'Jumlah Orang',
    guestCountPlaceholder: 'Contoh: 2 orang',
    checklistEnabled: false,
    checklistText: '',
    noteTitle: 'Catatan:',
    noteText: 'Durasi masak ± 30 menit',
  },
  {
    id: 'kurir_sendiri',
    enabled: true,
    label: 'Pesan kurir sendiri',
    askArrivalTime: false,
    arrivalTimeLabel: 'Waktu Pengiriman',
    arrivalTimePlaceholder: 'Contoh: 18:00 WIB',
    askGuestCount: false,
    guestCountLabel: 'Jumlah Orang',
    guestCountPlaceholder: 'Contoh: 1 orang',
    checklistEnabled: true,
    checklistText: 'Pesan kurir setelah pembayaran dan makanan telah siap',
    noteTitle: 'Catatan Penting:',
    noteText: 'Biaya makanan / pesanan tidak termasuk biaya kirim (kurir).',
  },
  {
    id: 'gosend_penjual',
    enabled: true,
    label: 'Dikirim Via Gosend Oleh Penjual',
    askArrivalTime: false,
    arrivalTimeLabel: 'Waktu Pengiriman',
    arrivalTimePlaceholder: 'Contoh: 18:00 WIB',
    askGuestCount: false,
    guestCountLabel: 'Jumlah Orang',
    guestCountPlaceholder: 'Contoh: 1 orang',
    checklistEnabled: true,
    checklistText:
      'Penjual akan pesan kurir setelah pembayaran dan makanan telah siap dan mengirimkan tracking pengiriman via WA',
    noteTitle: 'Catatan Penting:',
    noteText: 'Biaya makanan / pesanan tidak termasuk biaya kirim (kurir).',
  },
];

export function cloneDefaultCatalogShippingOptions(): CatalogShippingOptionConfig[] {
  return DEFAULT_CATALOG_SHIPPING_OPTIONS.map((opt) => ({ ...opt }));
}

export function resolveCatalogShippingOptions(
  content?: Pick<
    BlockContent,
    'catalogShippingOptions' | 'catalogPickupNote' | 'catalogShippingNote'
  >
): CatalogShippingOptionConfig[] {
  const saved = content?.catalogShippingOptions;
  if (Array.isArray(saved) && saved.length > 0) {
    return DEFAULT_CATALOG_SHIPPING_OPTIONS.map((def) => {
      const found = saved.find((s) => s && s.id === def.id);
      if (!found) return { ...def };
      return {
        ...def,
        ...found,
        enabled: found.enabled !== false,
        label:
          typeof found.label === 'string' && found.label.trim()
            ? found.label
            : def.label,
        askArrivalTime: found.askArrivalTime ?? def.askArrivalTime,
        arrivalTimeLabel: found.arrivalTimeLabel ?? def.arrivalTimeLabel,
        arrivalTimePlaceholder:
          found.arrivalTimePlaceholder ?? def.arrivalTimePlaceholder,
        askGuestCount: found.askGuestCount ?? def.askGuestCount,
        guestCountLabel: found.guestCountLabel ?? def.guestCountLabel,
        guestCountPlaceholder:
          found.guestCountPlaceholder ?? def.guestCountPlaceholder,
        checklistEnabled: found.checklistEnabled ?? def.checklistEnabled,
        checklistText: found.checklistText ?? def.checklistText,
        noteTitle: found.noteTitle ?? def.noteTitle,
        noteText: found.noteText ?? def.noteText,
      };
    });
  }

  const legacyPickup = content?.catalogPickupNote?.trim();
  const legacyShipNote = content?.catalogShippingNote?.trim();
  const isLegacyCustomShipNote =
    Boolean(legacyShipNote) &&
    legacyShipNote !== 'Biaya pesanan tidak termasuk biaya kirim maupun biaya kurir.' &&
    legacyShipNote !== DEFAULT_SHIPPING_NOTE;

  return DEFAULT_CATALOG_SHIPPING_OPTIONS.map((def) => {
    if (def.id === 'ambil_sendiri' && legacyPickup) {
      return { ...def, noteText: legacyPickup };
    }
    if (
      (def.id === 'kurir_sendiri' || def.id === 'gosend_penjual') &&
      isLegacyCustomShipNote &&
      legacyShipNote
    ) {
      return { ...def, noteText: legacyShipNote };
    }
    return { ...def };
  });
}

export interface CartEntry {
  key: string;
  blockId: string;
  itemId: string;
  title: string;
  priceText: string;
  unitPrice: number;
  image: string;
  variant: string;
  qty: number;
  productType: CatalogProductType;
  pickupNote?: string;
}

export interface CustomerOrderInfo {
  name: string;
  phone: string;
  address: string;
  notes: string;
  shippingMethod?: ShippingMethodId;
  shippingOptionNumber?: number;
  shippingOptionLabel?: string;
  arrivalTimeLabel?: string;
  arrivalTime?: string;
  guestCountLabel?: string;
  guestCount?: string;
  checklistConfirmed?: boolean;
  checklistText?: string;
  pickupNote?: string;
  shippingNoteTitle?: string;
  shippingNote?: string;
}

export function resolveItemProductType(
  item: Pick<CatalogItem, 'productType'>,
  blockProductType: CatalogProductType = 'physical'
): CatalogProductType {
  if (item.productType === 'physical' || item.productType === 'service') {
    return item.productType;
  }
  return blockProductType;
}

export function collectCartPickupNotes(
  entries: CartEntry[],
  blockPickupNote?: string
): string[] {
  const seen = new Set<string>();
  const result: string[] = [];
  const pushUnique = (raw?: string) => {
    const cleaned = (raw ?? '').trim();
    if (!cleaned || seen.has(cleaned)) return;
    seen.add(cleaned);
    result.push(cleaned);
  };
  pushUnique(blockPickupNote);
  entries.forEach((entry) => pushUnique(entry.pickupNote));
  return result;
}

export function parseVariants(variants?: string): string[] {
  if (!variants) return [];
  return variants
    .split(',')
    .map((v) => v.trim())
    .filter(Boolean);
}

export function parsePriceToNumber(priceStr: string): number {
  if (!priceStr) return 0;
  // Strip Indonesian decimal suffix like ",00" or ".00" if followed by exactly 2 digits at end after separator
  const cleaned = priceStr.trim().replace(/,\d{1,2}$/, '');
  const digits = cleaned.replace(/[^\d]/g, '');
  if (!digits) return 0;
  const parsed = Number(digits);
  return Number.isFinite(parsed) ? parsed : 0;
}

export function formatRupiah(amount: number): string {
  return `Rp ${Math.max(0, Math.round(amount)).toLocaleString('id-ID')}`;
}

export function normalizeWhatsappNumber(raw?: string): string {
  const digits = (raw ?? '').replace(/[^\d]/g, '');
  if (!digits) return '6281234567890';
  if (digits.startsWith('0')) return `62${digits.slice(1)}`;
  if (digits.startsWith('8')) return `62${digits}`;
  return digits;
}

export function makeCartKey(blockId: string, itemId: string, variant = ''): string {
  return `${blockId}::${itemId}::${variant}`;
}

export function createCartEntry(
  blockId: string,
  item: CatalogItem,
  variant = '',
  qty = 1,
  blockProductType: CatalogProductType = 'physical'
): CartEntry {
  return {
    key: makeCartKey(blockId, item.id, variant),
    blockId,
    itemId: item.id,
    title: item.title,
    priceText: item.price,
    unitPrice: parsePriceToNumber(item.price),
    image: item.image,
    variant,
    qty: Math.max(1, qty),
    productType: resolveItemProductType(item, blockProductType),
    pickupNote: item.pickupNote?.trim() || undefined,
  };
}

export function buildWhatsappOrderUrl(params: {
  phone?: string;
  storeName?: string;
  intro?: string;
  items: CartEntry[];
  customer?: Partial<CustomerOrderInfo>;
}): string {
  const targetPhone = normalizeWhatsappNumber(params.phone);
  const storeName = (params.storeName ?? '').trim();
  const intro =
    (params.intro ?? '').trim() || 'Halo, saya ingin memesan produk berikut:';

  const lines: string[] = [];
  if (storeName) {
    lines.push(`*${storeName}*`);
  }
  lines.push(intro);
  lines.push('');

  let grandTotal = 0;
  let hasNumericPrice = false;

  params.items.forEach((entry, idx) => {
    const variantLabel = entry.variant ? ` (${entry.variant})` : '';
    const lineTotal = entry.unitPrice * entry.qty;
    if (entry.unitPrice > 0) {
      hasNumericPrice = true;
      grandTotal += lineTotal;
      lines.push(
        `${idx + 1}. ${entry.title}${variantLabel} x${entry.qty} — ${formatRupiah(lineTotal)}`
      );
    } else {
      lines.push(
        `${idx + 1}. ${entry.title}${variantLabel} x${entry.qty}${entry.priceText ? ` (${entry.priceText})` : ''}`
      );
    }
  });

  if (hasNumericPrice) {
    lines.push('');
    lines.push(`*Total Pesanan: ${formatRupiah(grandTotal)}*`);
  }

  const c = params.customer;
  const customerLines: string[] = [];
  if (c?.name?.trim()) customerLines.push(`Nama: ${c.name.trim()}`);
  if (c?.phone?.trim()) customerLines.push(`No. WA: ${c.phone.trim()}`);
  if (c?.address?.trim()) customerLines.push(`Alamat: ${c.address.trim()}`);
  if (c?.notes?.trim()) customerLines.push(`Catatan: ${c.notes.trim()}`);

  const hasPhysical = params.items.some((entry) => entry.productType === 'physical');
  let selectedOptionLabel = '';
  if (hasPhysical && c?.shippingMethod) {
    const optIndex = SHIPPING_OPTIONS.findIndex((o) => o.id === c.shippingMethod);
    const opt = optIndex >= 0 ? SHIPPING_OPTIONS[optIndex] : undefined;
    const displayNum = c.shippingOptionNumber ?? (optIndex >= 0 ? optIndex + 1 : 1);
    const displayTitle = c.shippingOptionLabel?.trim() || opt?.title || '';
    if (displayTitle) {
      selectedOptionLabel = `${displayNum}. ${displayTitle}`;
      customerLines.push(`Pilihan: ${selectedOptionLabel}`);
      if (c.arrivalTime?.trim()) {
        customerLines.push(
          `${(c.arrivalTimeLabel ?? 'Waktu').trim()}: ${c.arrivalTime.trim()}`
        );
      }
      if (c.guestCount?.trim()) {
        customerLines.push(
          `${(c.guestCountLabel ?? 'Jumlah Orang').trim()}: ${c.guestCount.trim()}`
        );
      }
      if (c.checklistConfirmed && c.checklistText?.trim()) {
        customerLines.push(`Konfirmasi: [✓] ${c.checklistText.trim()}`);
      }
      if (c.pickupNote?.trim()) {
        customerLines.push(`Info Produk: ${c.pickupNote.trim()}`);
      }
      if (c.shippingNote?.trim()) {
        const noteHeading = (c.shippingNoteTitle?.trim() || 'Catatan:').replace(/:+$/, '');
        customerLines.push(`${noteHeading}: ${c.shippingNote.trim()}`);
      }
    }
  }

  if (customerLines.length > 0) {
    lines.push('');
    lines.push(selectedOptionLabel ? '*Data Pemesan & Pilihan:*' : '*Data Pemesan:*');
    lines.push(...customerLines);
  }

  return `https://wa.me/${targetPhone}?text=${encodeURIComponent(lines.join('\n'))}`;
}
