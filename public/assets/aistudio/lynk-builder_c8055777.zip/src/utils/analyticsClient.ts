import { AdChannel, AnalyticsEventRecord, ProjectRecord } from '../types/builder';
import { AD_CHANNEL_META } from './publishingHelpers';

const LOCAL_ANALYTICS_KEY = 'lynk_builder_analytics_v1';

export interface SaveProjectResponse {
  ok: boolean;
  savedAt: number;
  slug: string;
  error?: string;
}

export interface AnalyticsSummaryResponse {
  events: AnalyticsEventRecord[];
  capiConfiguredOnServer: boolean;
}

function readLocalEvents(): AnalyticsEventRecord[] {
  try {
    const raw = localStorage.getItem(LOCAL_ANALYTICS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as AnalyticsEventRecord[]) : [];
  } catch {
    return [];
  }
}

function writeLocalEvents(events: AnalyticsEventRecord[]) {
  try {
    localStorage.setItem(LOCAL_ANALYTICS_KEY, JSON.stringify(events.slice(0, 1000)));
  } catch {
    // Abaikan kuota penyimpanan browser
  }
}

export async function saveProjectToServer(
  record: ProjectRecord,
  renderedHtml: string,
  publishNow = false
): Promise<SaveProjectResponse> {
  const endpoint = publishNow
    ? `/api/projects/${encodeURIComponent(record.id)}/publish`
    : `/api/projects/${encodeURIComponent(record.id)}/save`;

  try {
    const resp = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ record, renderedHtml }),
    });
    const data = (await resp.json().catch(() => ({}))) as Partial<SaveProjectResponse> & {
      error?: string;
    };
    if (!resp.ok) {
      return {
        ok: false,
        savedAt: Date.now(),
        slug: record.project.publishing?.slug || '',
        error: data.error || 'Gagal menyimpan ke server.',
      };
    }
    return {
      ok: true,
      savedAt: data.savedAt ?? Date.now(),
      slug: data.slug ?? record.project.publishing?.slug ?? '',
    };
  } catch {
    return {
      ok: false,
      savedAt: Date.now(),
      slug: record.project.publishing?.slug || '',
      error: 'Koneksi server tidak tersedia, tersimpan secara lokal.',
    };
  }
}

export async function deleteProjectOnServer(projectId: string): Promise<void> {
  try {
    await fetch(`/api/projects/${encodeURIComponent(projectId)}`, {
      method: 'DELETE',
    });
  } catch {
    // Abaikan jika offline
  }
}

export async function trackAnalyticsEvent(params: {
  projectId: string;
  projectTitle: string;
  slug: string;
  eventType: 'page_view' | 'wa_click' | 'form_submit';
  channel?: AdChannel;
  ctaLabel?: string;
  waPhone?: string;
  orderValue?: number;
  utmSource?: string;
  utmMedium?: string;
  utmCampaign?: string;
  utmContent?: string;
  clickIdType?: 'fbclid' | 'ctwa_clid' | 'ttclid' | 'gclid';
  isTest?: boolean;
}): Promise<void> {
  const channel: AdChannel = params.channel ?? 'organic';
  const event: AnalyticsEventRecord = {
    id: `evt_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`,
    projectId: params.projectId,
    projectTitle: params.projectTitle,
    slug: params.slug,
    eventType: params.eventType,
    channel,
    sourceLabel: AD_CHANNEL_META[channel].shortLabel,
    ctaLabel: params.ctaLabel,
    waPhone: params.waPhone,
    orderValue: params.orderValue,
    utmSource: params.utmSource,
    utmMedium: params.utmMedium,
    utmCampaign: params.utmCampaign,
    utmContent: params.utmContent,
    clickIdType: params.clickIdType,
    deviceType:
      typeof window !== 'undefined' && window.innerWidth < 768 ? 'mobile' : 'desktop',
    isTest: params.isTest,
    createdAt: Date.now(),
  };

  const existing = readLocalEvents();
  writeLocalEvents([event, ...existing]);

  try {
    await fetch('/api/track/event', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(event),
      keepalive: true,
    });
  } catch {
    // Fallback sudah tersimpan di localStorage
  }
}

export async function fetchAnalyticsSummary(): Promise<AnalyticsSummaryResponse> {
  const localEvents = readLocalEvents();
  try {
    const resp = await fetch('/api/analytics');
    if (!resp.ok) {
      return { events: localEvents, capiConfiguredOnServer: false };
    }
    const data = (await resp.json()) as Partial<AnalyticsSummaryResponse>;
    const serverEvents = Array.isArray(data.events) ? data.events : [];
    const seen = new Set<string>();
    const merged: AnalyticsEventRecord[] = [];
    for (const ev of [...serverEvents, ...localEvents]) {
      if (!ev || !ev.id || seen.has(ev.id)) continue;
      seen.add(ev.id);
      merged.push(ev);
    }
    merged.sort((a, b) => b.createdAt - a.createdAt);
    writeLocalEvents(merged);
    return {
      events: merged,
      capiConfiguredOnServer: Boolean(data.capiConfiguredOnServer),
    };
  } catch {
    return { events: localEvents, capiConfiguredOnServer: false };
  }
}

export async function clearAnalyticsOnServer(projectId?: string): Promise<void> {
  const localEvents = readLocalEvents();
  if (projectId) {
    writeLocalEvents(localEvents.filter((ev) => ev.projectId !== projectId));
  } else {
    writeLocalEvents([]);
  }
  try {
    const query = projectId ? `?projectId=${encodeURIComponent(projectId)}` : '';
    await fetch(`/api/analytics${query}`, { method: 'DELETE' });
  } catch {
    // Abaikan jika offline
  }
}
