import {
  AdvanceOptions,
  BlockStyle,
  BuilderBlock,
  BuilderProject,
  CatalogProductType,
  CatalogShippingOptionConfig,
  PageTheme,
  ShadowPreset,
} from '../types/builder';
import { renderButtonIconSvgString, resolveButtonIcon } from './buttonIcons';
import { SOCIAL_PLATFORMS, resolveSocialMetrics } from './socialIcons';
import {
  VideoEmbedPlatform,
  extractInstagramInfo,
  extractTikTokId,
  extractYouTubeId,
  isDirectVideoUrl,
  isValidFacebookVideoUrl,
  isValidInstagramVideoUrl,
  isValidTikTokUrl,
  normalizeFacebookVideoUrl,
} from './videoHelpers';
import { sanitizeExternalUrl } from './urlHelpers';
import {
  normalizeWhatsappNumber,
  resolveCartButtonMetrics,
  resolveCatalogShippingOptions,
} from './cartHelpers';
import { resolveProjectAds, resolveProjectPublishing } from './publishingHelpers';
import { resolveBottomNavbar } from '../data/presets';

export { extractYouTubeId };

function hexToRgb(hex?: string): { r: number; g: number; b: number } | null {
  if (!hex) return null;
  const clean = hex.trim().replace(/^#/, '');
  if (!/^[0-9a-fA-F]{6}$/.test(clean)) return null;
  return {
    r: parseInt(clean.slice(0, 2), 16),
    g: parseInt(clean.slice(2, 4), 16),
    b: parseInt(clean.slice(4, 6), 16),
  };
}

export function shadowToCss(shadow: ShadowPreset, shadowColor?: string): string {
  const rgb = hexToRgb(shadowColor);
  const c = (alpha: number) =>
    rgb ? `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${alpha})` : `rgba(15, 23, 42, ${alpha})`;
  switch (shadow) {
    case 'sm':
      return `0 2px 8px ${c(rgb ? 0.22 : 0.08)}`;
    case 'md':
      return `0 8px 24px ${c(rgb ? 0.30 : 0.14)}`;
    case 'lg':
      return `0 16px 36px ${c(rgb ? 0.38 : 0.22)}`;
    default:
      return 'none';
  }
}

export function resolveBlockTextColor(
  style: BlockStyle,
  theme: PageTheme,
  inheritedTextColor?: string
): string {
  if (style.useThemeTextColor === false) {
    return style.textColor || theme.textColor;
  }
  if (
    style.useThemeTextColor === undefined &&
    style.textColor &&
    style.textColor.trim().toLowerCase() !== theme.textColor.trim().toLowerCase()
  ) {
    return style.textColor;
  }
  return inheritedTextColor ?? theme.textColor;
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function styleObjectToCss(style: BlockStyle, resolvedTextColor?: string): string {
  const padX = style.paddingX ?? style.padding;
  const padTop = style.paddingTop ?? style.padding;
  const padBottom = style.paddingBottom ?? style.padding;
  const parts: string[] = [
    `width: ${style.widthPercent}%`,
    `margin: 0 auto ${style.marginBottom}px auto`,
    `padding: ${padTop}px ${padX}px ${padBottom}px ${padX}px`,
    `min-height: ${style.minHeight}px`,
    `border-radius: ${style.borderRadius}px`,
    `text-align: ${style.align}`,
    `color: ${resolvedTextColor ?? style.textColor}`,
    `background-color: ${style.backgroundColor}`,
    `box-sizing: border-box`,
  ];

  if (style.borderWidth > 0) {
    parts.push(`border: ${style.borderWidth}px solid ${style.borderColor}`);
  }
  if (style.shadow !== 'none') {
    parts.push(`box-shadow: ${shadowToCss(style.shadow, style.shadowColor)}`);
  }
  if (style.blur > 0) {
    parts.push(`backdrop-filter: blur(${style.blur}px)`);
    parts.push(`-webkit-backdrop-filter: blur(${style.blur}px)`);
  }

  return parts.join('; ');
}

function renderBlockHtml(
  block: BuilderBlock,
  theme: PageTheme,
  advance: AdvanceOptions,
  indent = '      ',
  inheritedTextColor?: string
): string {
  const resolvedTextColor = resolveBlockTextColor(block.style, theme, inheritedTextColor);
  const nextInheritedTextColor =
    block.style.useThemeTextColor === false
      ? block.style.textColor
      : block.style.useThemeTextColor === undefined &&
        block.style.textColor &&
        block.style.textColor.trim().toLowerCase() !== theme.textColor.trim().toLowerCase()
      ? block.style.textColor
      : inheritedTextColor;
  const css = styleObjectToCss(block.style, resolvedTextColor);

  switch (block.type) {
    case 'container': {
      const inner = (block.children ?? [])
        .map((child) =>
          renderBlockHtml(child, theme, advance, indent + '  ', nextInheritedTextColor)
        )
        .filter(Boolean)
        .join('\n');
      return `${indent}<div style="${css}">\n${inner}\n${indent}</div>`;
    }

    case 'toggle_container': {
      const defaultOpen = Boolean(block.content.toggleDefaultOpen);
      const showLabel = block.content.toggleShowLabel || 'Tampilkan Konten';
      const hideLabel = block.content.toggleHideLabel || showLabel;
      const btnBg = block.content.toggleButtonBg || theme.accentColor;
      const btnText = block.content.toggleButtonText || '#FFFFFF';
      const btnStyle = block.content.toggleButtonStyle ?? 'solid';
      const btnRadius = Math.min(block.style.borderRadius, 12);
      const btnCss =
        btnStyle === 'outline'
          ? `width: 100%; padding: 10px 14px; border-radius: ${btnRadius}px; border: 1.5px solid ${btnBg}; background: transparent; color: ${btnBg}; font-size: 14px; font-weight: 600; display: flex; align-items: center; justify-content: space-between; gap: 8px; cursor: pointer; font-family: inherit; box-sizing: border-box;`
          : `width: 100%; padding: 10px 14px; border-radius: ${btnRadius}px; border: 0; background: ${btnBg}; color: ${btnText}; font-size: 14px; font-weight: 600; display: flex; align-items: center; justify-content: space-between; gap: 8px; cursor: pointer; font-family: inherit; box-sizing: border-box;`;
      const inner = (block.children ?? [])
        .map((child) =>
          renderBlockHtml(child, theme, advance, indent + '    ', nextInheritedTextColor)
        )
        .filter(Boolean)
        .join('\n');
      const initialLabel = defaultOpen ? hideLabel : showLabel;
      const chevronRot = defaultOpen ? 'rotate(180deg)' : 'rotate(0deg)';
      const leftIconId = resolveButtonIcon(block.content.toggleButtonIcon, showLabel);
      const leftIconSvg = renderButtonIconSvgString(leftIconId, 16);
      return `${indent}<div data-toggle-box style="${css}">
${indent}  <button type="button" data-toggle-btn data-show-label="${escapeHtml(showLabel)}" data-hide-label="${escapeHtml(
        hideLabel
      )}" aria-expanded="${defaultOpen ? 'true' : 'false'}" style="${btnCss}">
${indent}    <span style="display: inline-flex; align-items: center; gap: 8px; min-width: 0;">${leftIconSvg}<span data-toggle-label style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${escapeHtml(
        initialLabel
      )}</span></span>
${indent}    <svg data-toggle-chevron viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0; transition: transform 0.2s ease; transform: ${chevronRot};" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
${indent}  </button>
${indent}  <div data-toggle-panel style="display: ${defaultOpen ? 'block' : 'none'}; margin-top: 12px;">
${inner}
${indent}  </div>
${indent}</div>`;
    }

    case 'bottom_sheet': {
      const safeId = block.id.replace(/[^a-zA-Z0-9_-]/g, '');
      const sheetId = `sheet_${safeId}`;
      const triggerStyle = block.content.sheetTriggerStyle ?? 'icon';
      const triggerLabel = block.content.sheetTriggerLabel ?? 'Lokasi Maps';
      const triggerSublabel = block.content.sheetTriggerSublabel ?? '';
      const triggerBg = block.content.sheetTriggerBg || theme.accentColor;
      const triggerText = block.content.sheetTriggerText || '#FFFFFF';
      const iconSize = Math.max(36, Math.min(72, block.content.sheetIconSize ?? 52));
      const glyphSize = Math.round(iconSize * 0.44);
      const iconId = resolveButtonIcon(block.content.sheetTriggerIcon ?? 'map-pin', triggerLabel);
      const iconSvg =
        renderButtonIconSvgString(iconId, triggerStyle === 'icon' ? glyphSize : 16) ||
        `<svg viewBox="0 0 24 24" width="${
          triggerStyle === 'icon' ? glyphSize : 16
        }" height="${
          triggerStyle === 'icon' ? glyphSize : 16
        }" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 15h18"/><path d="m9 10 3-3 3 3"/></svg>`;
      const sheetTitle = block.content.sheetTitle?.trim() || 'Bottom Sheet';
      const align = block.style.align;
      const justify = align === 'left' ? 'flex-start' : align === 'right' ? 'flex-end' : 'center';
      const btnRadius = Math.min(block.style.borderRadius, 14);
      const inner = (block.children ?? [])
        .map((child) =>
          renderBlockHtml(child, theme, advance, indent + '        ', theme.textColor)
        )
        .filter(Boolean)
        .join('\n');

      let triggerHtml = '';
      if (triggerStyle === 'icon') {
        const labelHtml = triggerLabel.trim()
          ? `<span style="font-size: 12px; font-weight: 600; line-height: 1.25;">${escapeHtml(
              triggerLabel
            )}</span>`
          : '';
        const sublabelHtml = triggerSublabel.trim()
          ? `<span style="font-size: 11px; opacity: 0.72; line-height: 1.25;">${escapeHtml(
              triggerSublabel
            )}</span>`
          : '';
        triggerHtml = `<button type="button" data-sheet-open="${sheetId}" style="display: inline-flex; flex-direction: column; align-items: center; gap: 6px; border: 0; background: transparent; color: inherit; cursor: pointer; padding: 0; font-family: inherit;">
${indent}    <span style="width: ${iconSize}px; height: ${iconSize}px; border-radius: 9999px; background: ${triggerBg}; color: ${triggerText}; display: flex; align-items: center; justify-content: center; box-shadow: 0 6px 16px rgba(15, 23, 42, 0.16);">${iconSvg}</span>${labelHtml}${sublabelHtml}
${indent}  </button>`;
      } else if (triggerStyle === 'pill') {
        const sublabelHtml = triggerSublabel.trim()
          ? `<span style="display: block; font-size: 10px; opacity: 0.85; line-height: 1.2; margin-top: 2px;">${escapeHtml(
              triggerSublabel
            )}</span>`
          : '';
        triggerHtml = `<button type="button" data-sheet-open="${sheetId}" style="display: inline-flex; align-items: center; gap: 10px; padding: 10px 16px; border: 0; border-radius: 9999px; background: ${triggerBg}; color: ${triggerText}; cursor: pointer; font-family: inherit; box-shadow: 0 4px 12px rgba(15, 23, 42, 0.14);">
${indent}    ${iconSvg}<span style="text-align: left; min-width: 0;"><span style="display: block; font-size: 12px; font-weight: 700; line-height: 1.2;">${escapeHtml(
          triggerLabel || 'Buka Panel'
        )}</span>${sublabelHtml}</span>
${indent}  </button>`;
      } else {
        triggerHtml = `<button type="button" data-sheet-open="${sheetId}" style="width: 100%; display: flex; align-items: center; justify-content: center; gap: 8px; padding: 11px 16px; border: 0; border-radius: ${btnRadius}px; background: ${triggerBg}; color: ${triggerText}; font-size: 14px; font-weight: 600; cursor: pointer; font-family: inherit; box-shadow: 0 4px 12px rgba(15, 23, 42, 0.12); box-sizing: border-box;">
${indent}    ${iconSvg}<span>${escapeHtml(triggerLabel || 'Buka Bottom Sheet')}</span>
${indent}  </button>`;
      }

      return `${indent}<div style="${css}; display: flex; justify-content: ${justify};">
${indent}  ${triggerHtml}
${indent}  <div id="${sheetId}" data-bottom-sheet class="lynk-sheet-backdrop" role="dialog" aria-modal="true" aria-label="${escapeHtml(
        sheetTitle
      )}">
${indent}    <div class="lynk-sheet-panel" style="background-color: ${theme.cardBg}; color: ${
        theme.textColor
      }; border-top: 1px solid ${theme.borderColor};">
${indent}      <div class="lynk-sheet-header" style="border-bottom: 1px solid ${theme.borderColor};">
${indent}        <div class="lynk-sheet-handle"></div>
${indent}        <div style="width: 100%; display: flex; align-items: center; justify-content: space-between; gap: 8px;">
${indent}          <div style="font-size: 15px; font-weight: 700; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${escapeHtml(
        sheetTitle
      )}</div>
${indent}          <button type="button" data-sheet-close aria-label="Tutup Bottom Sheet" style="width: 30px; height: 30px; border-radius: 9999px; border: 0; background: rgba(148, 163, 184, 0.16); color: inherit; font-size: 14px; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">&#10005;</button>
${indent}        </div>
${indent}      </div>
${indent}      <div class="lynk-sheet-body">
${inner || `${indent}        <div style="padding: 28px 0; text-align: center; font-size: 12px; opacity: 0.65;">Belum ada konten di dalam Bottom Sheet.</div>`}
${indent}      </div>
${indent}    </div>
${indent}  </div>
${indent}</div>`;
    }

    case 'row': {
      const cols = (block.children ?? [])
        .map(
          (child) =>
            `${indent}  <div style="flex: 1; min-width: 0;">\n${renderBlockHtml(
              child,
              theme,
              advance,
              indent + '    ',
              nextInheritedTextColor
            )}\n${indent}  </div>`
        )
        .join('\n');
      return `${indent}<div style="${css}; display: flex; gap: 12px; align-items: stretch;">\n${cols}\n${indent}</div>`;
    }

    case 'text': {
      const rawText = block.content.text ?? '';
      if (!rawText.trim()) return '';
      const tag = block.content.variant === 'h1' ? 'h1' : block.content.variant === 'h2' ? 'h2' : 'p';
      const fontSize =
        block.content.variant === 'h1'
          ? '22px'
          : block.content.variant === 'h2'
          ? '18px'
          : '14px';
      const weight =
        block.content.fontWeight === 'bold'
          ? '700'
          : block.content.fontWeight === 'semibold'
          ? '600'
          : '400';
      return `${indent}<${tag} style="${css}; font-size: ${fontSize}; font-weight: ${weight}; line-height: 1.5; white-space: pre-line;">${escapeHtml(
        rawText
      )}</${tag}>`;
    }

    case 'image': {
      const src = escapeHtml(block.content.src ?? '');
      const alt = escapeHtml(block.content.alt ?? 'Gambar');
      const fit = block.content.objectFit ?? 'cover';

      if (block.content.imageShape === 'circle') {
        const s = block.style;
        const padX = s.paddingX ?? s.padding;
        const padTop = s.paddingTop ?? s.padding;
        const padBottom = s.paddingBottom ?? s.padding;
        const circleSize = Math.max(40, Math.min(280, block.content.circleSize ?? 112));
        const imageZoom = Math.max(40, Math.min(250, block.content.imageZoom ?? 100));
        const justify =
          s.align === 'left' ? 'flex-start' : s.align === 'right' ? 'flex-end' : 'center';
        const circleBg =
          s.backgroundColor && s.backgroundColor !== 'transparent'
            ? s.backgroundColor
            : '#F1F5F9';
        const circleBorder =
          s.borderWidth > 0 ? `border: ${s.borderWidth}px solid ${s.borderColor};` : '';
        const circleShadow =
          s.shadow !== 'none' ? `box-shadow: ${shadowToCss(s.shadow, s.shadowColor)};` : '';
        const wrapCss = `width: ${s.widthPercent}%; margin: 0 auto ${s.marginBottom}px auto; padding: ${padTop}px ${padX}px ${padBottom}px ${padX}px; box-sizing: border-box; display: flex; justify-content: ${justify};`;

        return `${indent}<div style="${wrapCss}">\n${indent}  <div style="width: ${circleSize}px; height: ${circleSize}px; border-radius: 9999px; overflow: hidden; display: flex; align-items: center; justify-content: center; flex-shrink: 0; background-color: ${circleBg}; ${circleBorder} ${circleShadow}">\n${indent}    <img src="${src}" alt="${alt}" style="width: 100%; height: 100%; display: block; object-fit: ${fit}; transform: scale(${(
          imageZoom / 100
        ).toFixed(2)}); transform-origin: center center;" />\n${indent}  </div>\n${indent}</div>`;
      }

      const ratioCss =
        block.content.aspectRatio && block.content.aspectRatio !== 'auto'
          ? `aspect-ratio: ${block.content.aspectRatio};`
          : '';
      return `${indent}<div style="${css}; overflow: hidden;">\n${indent}  <img src="${src}" alt="${alt}" style="width: 100%; height: 100%; display: block; object-fit: ${fit}; border-radius: ${block.style.borderRadius}px; ${ratioCss}" />\n${indent}</div>`;
    }

    case 'button': {
      const href = escapeHtml(sanitizeExternalUrl(block.content.url, '#'));
      const rawLabel = block.content.label ?? 'Tautan';
      const label = escapeHtml(rawLabel);
      const bg = block.content.buttonBg ?? '#2563EB';
      const fg = block.content.buttonText ?? '#FFFFFF';
      const leftIconId = resolveButtonIcon(block.content.buttonIcon, rawLabel);
      const leftIconSvg = renderButtonIconSvgString(leftIconId, 16);
      return `${indent}<a href="${href}" target="_blank" rel="noopener noreferrer" style="${css}; display: flex; align-items: center; justify-content: center; gap: 8px; text-decoration: none; font-weight: 600; font-size: 14px; background-color: ${bg}; color: ${fg}; padding: 12px 18px;">${leftIconSvg}<span>${label}</span></a>`;
    }

    case 'form': {
      const title = escapeHtml(block.content.formTitle ?? 'Formulir');
      const namePh = escapeHtml(block.content.namePlaceholder ?? 'Nama');
      const emailPh = escapeHtml(block.content.emailPlaceholder ?? 'Email');
      const btnLabel = escapeHtml(block.content.submitLabel ?? 'Kirim');
      const btnBg = block.content.buttonColor ?? '#2563EB';
      const successMsg = escapeHtml(block.content.successMessage ?? 'Terima kasih!');
      return `${indent}<form onsubmit="event.preventDefault(); this.querySelector('.form-msg').style.display='block';" style="${css}">
${indent}  <div style="font-weight: 700; font-size: 15px; margin-bottom: 12px;">${title}</div>
${indent}  <input type="text" required placeholder="${namePh}" style="width: 100%; padding: 10px 12px; margin-bottom: 8px; border: 1px solid #CBD5E1; border-radius: 8px; box-sizing: border-box; font-size: 14px;" />
${indent}  <input type="text" required placeholder="${emailPh}" style="width: 100%; padding: 10px 12px; margin-bottom: 12px; border: 1px solid #CBD5E1; border-radius: 8px; box-sizing: border-box; font-size: 14px;" />
${indent}  <button type="submit" style="width: 100%; padding: 11px 16px; border: none; border-radius: 8px; background-color: ${btnBg}; color: #FFFFFF; font-weight: 600; font-size: 14px; cursor: pointer;">${btnLabel}</button>
${indent}  <div class="form-msg" style="display: none; margin-top: 10px; font-size: 13px; color: #16A34A; font-weight: 500;">${successMsg}</div>
${indent}</form>`;
    }

    case 'divider': {
      const lineColor = block.content.lineColor ?? '#E2E8F0';
      const thickness = block.content.thickness ?? 1;
      const lineStyle = block.content.lineStyle ?? 'solid';
      return `${indent}<div style="${css}; display: flex; align-items: center;">\n${indent}  <hr style="width: 100%; border: none; border-top: ${thickness}px ${lineStyle} ${lineColor}; margin: 0;" />\n${indent}</div>`;
    }

    case 'youtube':
    case 'facebook_video':
    case 'tiktok_video':
    case 'instagram_video': {
      const platform: VideoEmbedPlatform =
        block.type === 'facebook_video'
          ? 'facebook'
          : block.type === 'tiktok_video'
          ? 'tiktok'
          : block.type === 'instagram_video'
          ? 'instagram'
          : 'youtube';
      const platformLabel =
        platform === 'facebook'
          ? 'Facebook'
          : platform === 'tiktok'
          ? 'TikTok'
          : platform === 'instagram'
          ? 'Instagram'
          : 'YouTube';
      const rawUrl =
        platform === 'youtube'
          ? block.content.youtubeUrl ?? block.content.videoUrl
          : block.content.videoUrl;
      const ratio =
        block.content.videoAspectRatio ??
        block.content.youtubeAspectRatio ??
        (platform === 'tiktok' || platform === 'instagram' ? '9/16' : '16/9');
      const autoPlay = block.content.videoAutoplay ?? block.content.youtubeAutoplay ?? true;
      const volume = block.content.videoVolume ?? block.content.youtubeVolume ?? 75;
      const poster = block.content.videoPoster?.trim() ?? '';

      const trimmedRawUrl = rawUrl?.trim() ?? '';
      const directUrl = isDirectVideoUrl(trimmedRawUrl) ? trimmedRawUrl : null;
      const ytId = !directUrl && platform === 'youtube' ? extractYouTubeId(trimmedRawUrl) : null;
      const ttId = !directUrl && platform === 'tiktok' ? extractTikTokId(trimmedRawUrl) : null;
      const fbUrl =
        !directUrl && platform === 'facebook' && isValidFacebookVideoUrl(trimmedRawUrl)
          ? normalizeFacebookVideoUrl(trimmedRawUrl)
          : null;
      const igInfo = !directUrl && platform === 'instagram' ? extractInstagramInfo(trimmedRawUrl) : null;
      const igId = igInfo ? `${igInfo.kind}/${igInfo.code}` : null;
      const validShort =
        (platform === 'tiktok' && isValidTikTokUrl(trimmedRawUrl)) ||
        (platform === 'instagram' && isValidInstagramVideoUrl(trimmedRawUrl));

      const vidId = directUrl || ytId || ttId || fbUrl || igId || (validShort ? trimmedRawUrl : null);

      if (!vidId) {
        return `${indent}<div style="${css}; padding: 16px; background: #F1F5F9; font-size: 13px;">URL Video ${platformLabel} belum valid</div>`;
      }

      const initialPoster =
        poster || (ytId ? `https://i.ytimg.com/vi/${ytId}/maxresdefault.jpg` : '');
      const initialStageInner = initialPoster
        ? `<img src="${escapeHtml(initialPoster)}" alt="Video preview" referrerpolicy="no-referrer" style="width: 100%; height: 100%; object-fit: cover; display: block;" />`
        : `<div style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #0F172A, #020617); color: #CBD5E1; font-size: 12px; font-weight: 500;">Video siap diputar</div>`;

      return `${indent}<div data-vid-player data-vid-platform="${platform}" data-vid-id="${escapeHtml(
        vidId
      )}" data-vid-direct="${escapeHtml(directUrl ?? '')}" data-vid-url="${escapeHtml(
        trimmedRawUrl || vidId
      )}" data-vid-poster="${escapeHtml(poster)}" data-vid-autoplay="${
        autoPlay ? '1' : '0'
      }" data-vid-volume="${volume}" data-vid-accent="${escapeHtml(
        theme.accentColor
      )}" style="${css}">
${indent}  <div data-vid-stage style="width: 100%; aspect-ratio: ${ratio}; border-radius: ${block.style.borderRadius}px; overflow: hidden; background: #020617; position: relative;">
${indent}    <div data-vid-cover style="position: absolute; inset: 0; z-index: 2; transition: opacity 0.3s ease; opacity: 1;">
${indent}      ${initialStageInner}
${indent}    </div>
${indent}  </div>
${indent}  <div style="display: flex; align-items: center; gap: 6px; margin-top: 8px; padding: 6px; border-radius: 12px; background: #F1F5F9; border: 1px solid #E2E8F0;">
${indent}    <button type="button" data-vid-play style="padding: 6px 10px; border: none; border-radius: 8px; background: ${theme.accentColor}; color: #FFFFFF; font-size: 11px; font-weight: 600; cursor: pointer; white-space: nowrap; flex-shrink: 0;">&#9654; Play</button>
${indent}    <button type="button" data-vid-pause disabled style="padding: 6px 10px; border: 1px solid #CBD5E1; border-radius: 8px; background: #FFFFFF; color: #0F172A; font-size: 11px; font-weight: 600; cursor: not-allowed; opacity: 0.45; white-space: nowrap; flex-shrink: 0;">&#10074;&#10074; Pause</button>
${indent}    <div style="flex: 1; min-width: 0; display: flex; align-items: center; gap: 6px; padding: 0 4px;">
${indent}      <button type="button" data-vid-mute aria-label="Toggle suara" style="padding: 4px; border: none; background: transparent; cursor: pointer; font-size: 13px; line-height: 1; flex-shrink: 0;">&#128266;</button>
${indent}      <input type="range" data-vid-vol min="0" max="100" value="${volume}" aria-label="Volume Audio" style="flex: 1; min-width: 44px; accent-color: ${theme.accentColor}; cursor: pointer;" />
${indent}      <span data-vid-vol-label style="font-size: 11px; font-weight: 600; color: #475569; min-width: 30px; text-align: right; flex-shrink: 0;">${volume}%</span>
${indent}    </div>
${indent}  </div>
${indent}</div>`;
    }

    case 'catalog': {
      const items = block.content.catalogItems ?? [];
      const layout = advance.blockLayout;
      const isGrid = layout === 'grid';
      const detailEnabled = block.content.catalogDetailEnabled ?? true;
      const cartEnabled = block.content.catalogCartEnabled ?? true;
      const cartBtn = resolveCartButtonMetrics(block.content.catalogCartButtonSize);
      const wrapperStyle = isGrid
        ? `${css}; display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; text-align: left;`
        : `${css}; display: flex; flex-direction: column; gap: 10px; text-align: left;`;

      const makeCartSvg = (sz: number) =>
        `<svg viewBox="0 0 24 24" width="${sz}" height="${sz}" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>`;
      const gridCartSvg = makeCartSvg(cartBtn.gridIconSize);
      const iconCartSvg = makeCartSvg(cartBtn.iconOnlySize);
      const compactCartSvg = makeCartSvg(cartBtn.compactIconSize);

      const itemCards = items
        .map((item) => {
          const soldHtml = advance.showUnitSold
            ? ` · ${item.unitSold} terjual`
            : '';
          const meta = `${escapeHtml(item.price)}${soldHtml}`;
          const cardBase = `background: ${theme.cardBg}; border: 1px solid ${theme.borderColor}; border-radius: 14px; overflow: hidden; text-decoration: none; color: ${theme.textColor};`;
          const fit = item.imageObjectFit ?? 'cover';
          const ratio = item.imageAspectRatio;
          const ratioCss = (fallback?: string) => {
            const eff = ratio === 'auto' ? undefined : ratio ?? fallback;
            return eff ? `aspect-ratio: ${eff};` : '';
          };
          const badgeHtml = item.badge?.trim()
            ? `<span style="display:inline-block; padding:2px 6px; border-radius:6px; font-size:9px; font-weight:700; color:#FFFFFF; background:${theme.accentColor};">${escapeHtml(item.badge.trim())}</span>`
            : '';
          const detailAttr = detailEnabled
            ? `data-open-detail="${escapeHtml(block.id)}::${escapeHtml(item.id)}" role="button" tabindex="0"`
            : '';
          const quickBtnAttr = `data-quick-add="${escapeHtml(block.id)}::${escapeHtml(item.id)}"`;

          if (layout === 'grid') {
            const inner = `
${indent}    ${badgeHtml ? `<div style="position:absolute; top:8px; left:8px; z-index:2;">${badgeHtml}</div>` : ''}
${indent}    <img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.title)}" style="width: 100%; ${ratioCss('1/1')} object-fit: ${fit}; display: block;" />
${indent}    <div style="padding: 10px; flex: 1; display: flex; flex-direction: column; justify-content: space-between; gap: 8px;">
${indent}      <div>
${indent}        <div style="font-size: 13px; font-weight: 700; margin-bottom: 4px;">${escapeHtml(item.title)}</div>
${indent}        <div style="font-size: 11px; opacity: 0.75;">${meta}</div>
${indent}      </div>
${indent}      ${cartEnabled ? `<button type="button" ${quickBtnAttr} style="width:100%; padding:${cartBtn.gridPadding}; border:0; border-radius:${cartBtn.gridRadius}px; background:${theme.accentColor}; color:#FFFFFF; font-size:${cartBtn.gridFontSize}px; font-weight:600; display:inline-flex; align-items:center; justify-content:center; gap:${cartBtn.gridGap}px; cursor:pointer;">${gridCartSvg}<span>+ Keranjang</span></button>` : ''}
${indent}    </div>`;
            const safeItemUrl = escapeHtml(sanitizeExternalUrl(item.url, '#'));
            if (detailEnabled) {
              return `${indent}  <div ${detailAttr} style="${cardBase} position: relative; display: flex; flex-direction: column; cursor: pointer;">${inner}\n${indent}  </div>`;
            }
            return `${indent}  <a href="${safeItemUrl}" target="_blank" rel="noopener noreferrer" style="${cardBase} position: relative; display: flex; flex-direction: column;">${inner}\n${indent}  </a>`;
          }

          if (layout === 'large-image') {
            const inner = `
${indent}    ${badgeHtml ? `<div style="position:absolute; top:10px; left:10px; z-index:2;">${badgeHtml}</div>` : ''}
${indent}    <img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.title)}" style="width: 100%; ${ratioCss('16/10')} object-fit: ${fit}; display: block;" />
${indent}    <div style="padding: 12px 14px; display: flex; justify-content: space-between; align-items: center; gap: 8px;">
${indent}      <div style="min-width: 0;">
${indent}        <div style="font-size: 14px; font-weight: 700;">${escapeHtml(item.title)}</div>
${indent}        <div style="font-size: 12px; opacity: 0.75; margin-top: 2px;">${meta}</div>
${indent}      </div>
${indent}      <div style="display:flex; align-items:center; gap:6px; flex-shrink:0;">
${indent}        <span style="font-size: 12px; font-weight: 600; color: ${theme.accentColor}; white-space: nowrap;">${escapeHtml(item.ctaLabel)}</span>
${indent}        ${cartEnabled ? `<button type="button" ${quickBtnAttr} aria-label="Tambah ke keranjang" style="width:${cartBtn.iconBoxSize}px; height:${cartBtn.iconBoxSize}px; border:0; border-radius:${cartBtn.iconBoxRadius}px; background:${theme.accentColor}; color:#FFFFFF; display:inline-flex; align-items:center; justify-content:center; cursor:pointer;">${iconCartSvg}</button>` : ''}
${indent}      </div>
${indent}    </div>`;
            const safeItemUrl = escapeHtml(sanitizeExternalUrl(item.url, '#'));
            if (detailEnabled) {
              return `${indent}  <div ${detailAttr} style="${cardBase} position: relative; display: block; cursor: pointer;">${inner}\n${indent}  </div>`;
            }
            return `${indent}  <a href="${safeItemUrl}" target="_blank" rel="noopener noreferrer" style="${cardBase} position: relative; display: block;">${inner}\n${indent}  </a>`;
          }

          if (layout === 'compact') {
            const thumbSize = ratio && ratio !== 'auto'
              ? `width: 56px; ${ratioCss()}`
              : 'width: 52px; height: 52px;';
            const safeItemUrl = escapeHtml(sanitizeExternalUrl(item.url, '#'));
            const primaryBtn = detailEnabled
              ? `<button type="button" ${detailAttr} style="flex:1; padding: 8px 12px; border:0; border-radius: 8px; background: ${theme.accentColor}; color: #FFFFFF; font-size: 12px; font-weight: 600; cursor: pointer;">${escapeHtml(item.ctaLabel)}</button>`
              : `<a href="${safeItemUrl}" target="_blank" rel="noopener noreferrer" style="flex:1; display: block; text-align: center; padding: 8px 12px; border-radius: 8px; background: ${theme.accentColor}; color: #FFFFFF; font-size: 12px; font-weight: 600; text-decoration: none;">${escapeHtml(item.ctaLabel)}</a>`;
            return `${indent}  <div style="${cardBase} padding: 12px;">
${indent}    <div ${detailAttr} style="display: flex; gap: 10px; align-items: center; margin-bottom: 10px; ${detailEnabled ? 'cursor: pointer;' : ''}">
${indent}      <img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.title)}" style="${thumbSize} border-radius: 10px; object-fit: ${fit}; flex-shrink: 0;" />
${indent}      <div style="min-width: 0;">
${indent}        ${badgeHtml ? `<div style="margin-bottom: 3px;">${badgeHtml}</div>` : ''}
${indent}        <div style="font-size: 13px; font-weight: 700;">${escapeHtml(item.title)}</div>
${indent}        <div style="font-size: 11px; opacity: 0.75; margin-top: 2px;">${meta}</div>
${indent}      </div>
${indent}    </div>
${indent}    <div style="display:flex; align-items:center; gap:6px;">
${indent}      ${primaryBtn}
${indent}      ${cartEnabled ? `<button type="button" ${quickBtnAttr} aria-label="Tambah ke keranjang" style="padding:${cartBtn.compactPadding}; border-radius:${cartBtn.compactRadius}px; border:1px solid ${theme.accentColor}; background:transparent; color:${theme.accentColor}; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0; cursor:pointer;">${compactCartSvg}</button>` : ''}
${indent}    </div>
${indent}  </div>`;
          }

          // default layout
          const defaultThumbSize = ratio && ratio !== 'auto'
            ? `width: 64px; ${ratioCss()}`
            : 'width: 56px; height: 56px;';
          const defaultInner = `
${indent}    <img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.title)}" style="${defaultThumbSize} border-radius: 10px; object-fit: ${fit}; flex-shrink: 0;" />
${indent}    <div style="flex: 1; min-width: 0;">
${indent}      ${badgeHtml ? `<div style="margin-bottom: 3px;">${badgeHtml}</div>` : ''}
${indent}      <div style="font-size: 13px; font-weight: 700;">${escapeHtml(item.title)}</div>
${indent}      <div style="font-size: 11px; opacity: 0.72; margin-top: 2px;">${escapeHtml(item.subtitle)}</div>
${indent}      <div style="font-size: 12px; font-weight: 600; color: ${theme.accentColor}; margin-top: 4px;">${meta}</div>
${indent}    </div>
${indent}    ${cartEnabled ? `<button type="button" ${quickBtnAttr} aria-label="Tambah ke keranjang" style="width:${cartBtn.iconBoxSize}px; height:${cartBtn.iconBoxSize}px; border:0; border-radius:${cartBtn.iconBoxRadius}px; background:${theme.accentColor}; color:#FFFFFF; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0; cursor:pointer;">${iconCartSvg}</button>` : ''}`;
          const safeItemUrl = escapeHtml(sanitizeExternalUrl(item.url, '#'));
          if (detailEnabled) {
            return `${indent}  <div ${detailAttr} style="${cardBase} display: flex; align-items: center; gap: 12px; padding: 10px 12px; cursor: pointer;">${defaultInner}\n${indent}  </div>`;
          }
          return `${indent}  <a href="${safeItemUrl}" target="_blank" rel="noopener noreferrer" style="${cardBase} display: flex; align-items: center; gap: 12px; padding: 10px 12px;">${defaultInner}\n${indent}  </a>`;
        })
        .join('\n');

      return `${indent}<div style="${wrapperStyle}">\n${itemCards}\n${indent}</div>`;
    }

    case 'social': {
      const visibleItems = (block.content.socialItems ?? []).filter((item) => item.visible);
      if (visibleItems.length === 0) return '';

      const socialStyle = block.content.socialStyle ?? 'filled';
      const socialShape = block.content.socialShape ?? 'circle';
      const { boxSize, iconSize, gap } = resolveSocialMetrics(block.content);
      const useBrand = block.content.socialUseBrandColors ?? true;
      const customColor = block.content.socialColor ?? theme.accentColor;

      const justify =
        block.style.align === 'left'
          ? 'flex-start'
          : block.style.align === 'right'
          ? 'flex-end'
          : 'center';

      const radius = socialShape === 'rounded' ? '12px' : '9999px';

      const links = visibleItems
        .map((item) => {
          const meta = SOCIAL_PLATFORMS[item.platform];
          const activeColor = useBrand ? meta.brandColor : customColor;
          const visualCss =
            socialStyle === 'filled'
              ? `background-color: ${activeColor}; color: #FFFFFF;`
              : socialStyle === 'outline'
              ? `background-color: transparent; color: ${activeColor}; border: 1.5px solid ${activeColor};`
              : `background-color: transparent; color: ${activeColor};`;
          const href = escapeHtml(sanitizeExternalUrl(item.url, '#'));
          const label = escapeHtml(meta.label);

          return `${indent}  <a href="${href}" target="_blank" rel="noopener noreferrer" aria-label="${label}" title="${label}" style="width: ${boxSize}px; height: ${boxSize}px; border-radius: ${radius}; display: inline-flex; align-items: center; justify-content: center; text-decoration: none; box-sizing: border-box; flex-shrink: 0; ${visualCss}"><svg viewBox="${meta.viewBox}" width="${iconSize}" height="${iconSize}" aria-hidden="true">${meta.svgInner}</svg></a>`;
        })
        .join('\n');

      return `${indent}<div style="${css}; display: flex; flex-wrap: wrap; align-items: center; justify-content: ${justify}; gap: ${gap}px;">\n${links}\n${indent}</div>`;
    }

    case 'social_follower': {
      const accounts = block.content.socialFollowerAccounts ?? [];
      if (accounts.length === 0) return '';

      const gap = block.content.socialFollowerGap ?? 10;
      const radius = block.style.borderRadius;
      const cardBg =
        block.style.backgroundColor && block.style.backgroundColor !== 'transparent'
          ? block.style.backgroundColor
          : theme.cardBg;
      const borderCol =
        block.style.borderWidth > 0 ? block.style.borderColor : theme.borderColor;
      const textCol = resolvedTextColor;

      const cardsHtml = accounts
        .map((acc) => {
          const meta = SOCIAL_PLATFORMS[acc.platform] ?? SOCIAL_PLATFORMS.instagram;
          const avatar = acc.avatar?.trim() ?? '';
          const accountName = acc.accountName || 'Nama Akun Sosmed';
          const handle = acc.handle || '@username';
          const accountUrl = sanitizeExternalUrl(acc.accountUrl, meta.placeholderUrl);
          const followLabel = acc.followLabel?.trim() || 'Ikuti';

          const avatarHtml = avatar
            ? `<img src="${escapeHtml(avatar)}" alt="${escapeHtml(accountName)}" referrerpolicy="no-referrer" style="width: 44px; height: 44px; border-radius: 9999px; object-fit: cover; border: 1px solid ${borderCol}; display: block;" />`
            : `<div style="width: 44px; height: 44px; border-radius: 9999px; background: ${meta.brandColor}; color: #FFFFFF; display: flex; align-items: center; justify-content: center;"><svg viewBox="${meta.viewBox}" width="20" height="20" aria-hidden="true">${meta.svgInner}</svg></div>`;

          const verifiedHtml = acc.verified
            ? `<svg viewBox="0 0 24 24" width="14" height="14" fill="#3B82F6" aria-hidden="true" style="flex-shrink: 0;"><path d="M12 2l2.39 1.66 2.86-.42.98 2.72 2.48 1.52-.64 2.82 1.24 2.61-2.06 2.04.14 2.89-2.83.62-1.68 2.38L12 20.1l-2.88.74-1.68-2.38-2.83-.62.14-2.89L2.69 12.9l1.24-2.61-.64-2.82 2.48-1.52.98-2.72 2.86.42L12 2zm-1.1 13.1l5.1-5.1-1.4-1.4-3.7 3.7-1.7-1.7-1.4 1.4 3.1 3.1z"/></svg>`
            : '';

          const bioHtml = acc.bio?.trim()
            ? `\n${indent}    <p style="margin: 0; font-size: 11px; opacity: 0.82; line-height: 1.5; white-space: pre-line;">${escapeHtml(
                acc.bio
              )}</p>`
            : '';

          const stats = [
            { label: acc.postsLabel?.trim() || 'Postingan', val: acc.postsCount?.trim() ?? '' },
            { label: acc.followersLabel?.trim() || 'Follower', val: acc.followers?.trim() ?? '' },
            { label: acc.followingLabel?.trim() || 'Mengikuti', val: acc.following?.trim() ?? '' },
          ].filter((x) => Boolean(x.val));

          const statsHtml = stats.length
            ? `\n${indent}    <div style="display: grid; grid-template-columns: repeat(${stats.length}, 1fr); gap: 4px; padding: 8px; border-radius: 12px; border: 1px solid ${borderCol}; background: rgba(148, 163, 184, 0.06); text-align: center;">\n${stats
                .map(
                  (st) =>
                    `${indent}      <div><div style="font-size: 12px; font-weight: 700;">${escapeHtml(
                      st.val
                    )}</div><div style="font-size: 10px; opacity: 0.7;">${escapeHtml(
                      st.label
                    )}</div></div>`
                )
                .join('\n')}\n${indent}    </div>`
            : '';

          return `${indent}  <div style="width: 100%; box-sizing: border-box; background: ${cardBg}; border: 1px solid ${borderCol}; border-radius: ${radius}px; color: ${textCol}; padding: 14px; box-shadow: 0 1px 2px rgba(15, 23, 42, 0.05); display: flex; flex-direction: column; gap: 10px; text-align: left;">
${indent}    <div style="display: flex; align-items: center; justify-content: space-between; gap: 10px;">
${indent}      <div style="display: flex; align-items: center; gap: 10px; min-width: 0;">
${indent}        <div style="position: relative; flex-shrink: 0;">
${indent}          ${avatarHtml}
${indent}          <span style="position: absolute; bottom: -2px; right: -2px; width: 18px; height: 18px; border-radius: 9999px; background: ${meta.brandColor}; color: #FFFFFF; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 0 2px #FFFFFF;"><svg viewBox="${meta.viewBox}" width="10" height="10" aria-hidden="true">${meta.svgInner}</svg></span>
${indent}        </div>
${indent}        <div style="min-width: 0;">
${indent}          <div style="display: flex; align-items: center; gap: 4px; font-size: 12px; font-weight: 700;"><span>${escapeHtml(
            accountName
          )}</span>${verifiedHtml}</div>
${indent}          <div style="font-size: 11px; opacity: 0.7;">${escapeHtml(handle)} · ${escapeHtml(
            meta.label
          )}</div>
${indent}        </div>
${indent}      </div>
${indent}      <a href="${escapeHtml(
            accountUrl
          )}" target="_blank" rel="noopener noreferrer" style="padding: 6px 12px; border-radius: 8px; background: ${
            meta.brandColor
          }; color: #FFFFFF; font-size: 11px; font-weight: 600; text-decoration: none; flex-shrink: 0;">${escapeHtml(
            followLabel
          )}</a>
${indent}    </div>${bioHtml}${statsHtml}
${indent}  </div>`;
        })
        .join('\n');

      return `${indent}<div style="${css}; display: flex; flex-direction: column; gap: ${gap}px; text-align: left;">\n${cardsHtml}\n${indent}</div>`;
    }

    case 'carousel': {
      const items = block.content.carouselItems ?? [];
      if (items.length === 0) return '';
      const ratio = block.content.carouselAspectRatio ?? '4/5';
      const fit = block.content.carouselObjectFit ?? 'cover';
      const radius = block.style.borderRadius;
      const align = block.style.align;

      const slidesHtml = items
        .map((item, idx) => {
          const cleanUrl = sanitizeExternalUrl(item.url, '');
          const titleHtml = item.title.trim()
            ? `<div style="font-size: 13px; font-weight: 700; line-height: 1.35;">${escapeHtml(item.title)}</div>`
            : '';
          const captionHtml = item.caption.trim()
            ? `<div style="font-size: 12px; opacity: 0.78; line-height: 1.45; margin-top: 4px; white-space: pre-line;">${escapeHtml(item.caption)}</div>`
            : '';
          const footerHtml =
            titleHtml || captionHtml
              ? `<div style="padding: 10px 14px; text-align: ${align};">${titleHtml}${captionHtml}</div>`
              : '';
          const linkBadge = cleanUrl
            ? `<span style="position: absolute; bottom: 8px; right: 8px; padding: 2px 8px; border-radius: 9999px; background: rgba(15, 23, 42, 0.7); color: #FFFFFF; font-size: 10px; font-weight: 600;">Link &#8599;</span>`
            : '';
          const cardHtml = `<div style="background: ${theme.cardBg}; border: 1px solid ${theme.borderColor}; border-radius: ${radius}px; overflow: hidden; color: ${resolvedTextColor};">
${indent}        <div style="position: relative; width: 100%; aspect-ratio: ${ratio}; background: #F1F5F9; overflow: hidden;">
${indent}          <img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.title || `Foto ${idx + 1}`)}" draggable="false" referrerpolicy="no-referrer" style="width: 100%; height: 100%; object-fit: ${fit}; display: block;" />${linkBadge}
${indent}        </div>${footerHtml}
${indent}      </div>`;

          if (cleanUrl) {
            return `${indent}    <div style="flex: 0 0 100%; scroll-snap-align: start; box-sizing: border-box;">\n${indent}      <a href="${escapeHtml(cleanUrl)}" target="_blank" rel="noopener noreferrer" draggable="false" style="display: block; text-decoration: none; color: inherit;">${cardHtml}</a>\n${indent}    </div>`;
          }
          return `${indent}    <div style="flex: 0 0 100%; scroll-snap-align: start; box-sizing: border-box;">\n${indent}      ${cardHtml}\n${indent}    </div>`;
        })
        .join('\n');

      const dotsHtml =
        items.length > 1
          ? `\n${indent}  <div style="display: flex; align-items: center; justify-content: center; gap: 6px; margin-top: 10px;">\n${items
              .map(
                (_, idx) =>
                  `${indent}    <button type="button" data-car-dot="${idx}" aria-label="Lihat foto ${idx + 1}" style="height: 6px; width: ${
                    idx === 0 ? '20px' : '6px'
                  }; border-radius: 9999px; border: none; padding: 0; background: ${
                    idx === 0 ? theme.accentColor : '#CBD5E1'
                  }; cursor: pointer; transition: all 0.2s ease;"></button>`
              )
              .join('\n')}\n${indent}  </div>`
          : '';

      const navHtml =
        items.length > 1
          ? `\n${indent}    <div data-car-counter style="position: absolute; top: 10px; right: 10px; z-index: 3; padding: 2px 8px; border-radius: 9999px; background: rgba(15, 23, 42, 0.65); color: #FFFFFF; font-size: 10px; font-weight: 600; pointer-events: none;">1 / ${items.length}</div>
${indent}    <button type="button" data-car-prev aria-label="Foto sebelumnya" style="position: absolute; left: 8px; top: 50%; transform: translateY(-50%); z-index: 3; width: 28px; height: 28px; border-radius: 9999px; border: 1px solid #E2E8F0; background: rgba(255, 255, 255, 0.92); color: #0F172A; font-size: 16px; line-height: 1; display: flex; align-items: center; justify-content: center; cursor: pointer; opacity: 0.3;">&#8249;</button>
${indent}    <button type="button" data-car-next aria-label="Foto berikutnya" style="position: absolute; right: 8px; top: 50%; transform: translateY(-50%); z-index: 3; width: 28px; height: 28px; border-radius: 9999px; border: 1px solid #E2E8F0; background: rgba(255, 255, 255, 0.92); color: #0F172A; font-size: 16px; line-height: 1; display: flex; align-items: center; justify-content: center; cursor: pointer;">&#8250;</button>`
          : '';

      return `${indent}<div data-carousel data-car-accent="${escapeHtml(theme.accentColor)}" style="${css}">
${indent}  <div style="position: relative;">
${indent}    <div data-car-track style="display: flex; overflow-x: auto; scroll-snap-type: x mandatory; scroll-behavior: smooth; border-radius: ${radius}px; -webkit-overflow-scrolling: touch; cursor: grab;">
${slidesHtml}
${indent}    </div>${navHtml}
${indent}  </div>${dotsHtml}
${indent}</div>`;
    }

    case 'social_feed': {
      const platform = block.content.socialFeedPlatform ?? 'instagram';
      const meta = SOCIAL_PLATFORMS[platform] ?? SOCIAL_PLATFORMS.instagram;
      const avatar = block.content.socialFeedAvatar?.trim() ?? '';
      const accountName = block.content.socialFeedAccountName ?? 'Studio Kreatif';
      const handle = block.content.socialFeedHandle ?? '@studiokreatif';
      const accountUrl = sanitizeExternalUrl(block.content.socialFeedAccountUrl, meta.placeholderUrl);
      const verified = block.content.socialFeedVerified ?? true;
      const followLabel = block.content.socialFeedFollowLabel ?? 'Ikuti';
      const ratio = block.content.socialFeedRatio ?? '4/5';
      const posts = block.content.socialFeedPosts ?? [];
      const mediaRadius = Math.max(8, Math.min(block.style.borderRadius, 14));

      const avatarHtml = avatar
        ? `<img src="${escapeHtml(avatar)}" alt="${escapeHtml(accountName)}" referrerpolicy="no-referrer" style="width: 44px; height: 44px; border-radius: 9999px; object-fit: cover; border: 1px solid ${theme.borderColor}; display: block;" />`
        : `<div style="width: 44px; height: 44px; border-radius: 9999px; background: ${meta.brandColor}; color: #FFFFFF; display: flex; align-items: center; justify-content: center;"><svg viewBox="${meta.viewBox}" width="20" height="20" aria-hidden="true">${meta.svgInner}</svg></div>`;

      const verifiedHtml = verified
        ? `<svg viewBox="0 0 24 24" width="14" height="14" fill="#3B82F6" aria-hidden="true" style="flex-shrink: 0;"><path d="M12 2l2.39 1.66 2.86-.42.98 2.72 2.48 1.52-.64 2.82 1.24 2.61-2.06 2.04.14 2.89-2.83.62-1.68 2.38L12 20.1l-2.88.74-1.68-2.38-2.83-.62.14-2.89L2.69 12.9l1.24-2.61-.64-2.82 2.48-1.52.98-2.72 2.86.42L12 2zm-1.1 13.1l5.1-5.1-1.4-1.4-3.7 3.7-1.7-1.7-1.4 1.4 3.1 3.1z"/></svg>`
        : '';

      const followersVal = block.content.socialFeedFollowers?.trim() ?? '';
      const followersLbl =
        block.content.socialFeedFollowersLabel?.trim() ||
        (platform === 'youtube' ? 'Subscriber' : 'Follower');
      const followerHtml = followersVal
        ? `<div style="padding: 4px 8px; border-radius: 8px; border: 1px solid ${theme.borderColor}; background: rgba(148, 163, 184, 0.06); text-align: center; line-height: 1.2; flex-shrink: 0;"><div style="font-size: 11px; font-weight: 700;">${escapeHtml(
            followersVal
          )}</div><div style="font-size: 9.5px; opacity: 0.7;">${escapeHtml(
            followersLbl
          )}</div></div>`
        : '';

      const bioHtml = block.content.socialFeedBio?.trim()
        ? `\n${indent}  <p style="margin: 0; font-size: 11px; opacity: 0.82; line-height: 1.5; white-space: pre-line;">${escapeHtml(
            block.content.socialFeedBio
          )}</p>`
        : '';

      const slidesHtml = posts
        .map((post, idx) => {
          const rawVid = post.videoUrl?.trim() ?? '';
          const ytId = rawVid ? extractYouTubeId(rawVid) : null;
          const isDirect =
            isDirectVideoUrl(rawVid) || /^data:video\//i.test(rawVid);
          const ttId = !isDirect && rawVid && isValidTikTokUrl(rawVid) ? extractTikTokId(rawVid) || rawVid : null;
          const igInfo = !isDirect && rawVid && isValidInstagramVideoUrl(rawVid) ? extractInstagramInfo(rawVid) : null;
          const fbUrl = !isDirect && rawVid && isValidFacebookVideoUrl(rawVid) ? normalizeFacebookVideoUrl(rawVid) : null;
          const vidKind = isDirect
            ? 'direct'
            : ytId
            ? 'youtube'
            : ttId
            ? 'tiktok'
            : igInfo || (rawVid && isValidInstagramVideoUrl(rawVid))
            ? 'instagram'
            : fbUrl
            ? 'facebook'
            : '';
          const vidId = isDirect
            ? rawVid
            : ytId || ttId || (igInfo ? `${igInfo.kind}/${igInfo.code}` : rawVid) || fbUrl || '';
          const poster =
            post.imageUrl?.trim() ||
            (ytId ? `https://i.ytimg.com/vi/${ytId}/hqdefault.jpg` : '');

          const mediaHtml =
            post.mediaType === 'video'
              ? `<div data-sf-video-box data-sf-kind="${escapeHtml(vidKind)}" data-sf-id="${escapeHtml(
                  vidId
                )}" data-sf-url="${escapeHtml(rawVid)}" style="position: relative; width: 100%; aspect-ratio: ${ratio}; background: #0F172A; overflow: hidden;">
${indent}          ${
                  poster
                    ? `<img src="${escapeHtml(poster)}" alt="${escapeHtml(
                        post.caption || `Video ${idx + 1}`
                      )}" draggable="false" referrerpolicy="no-referrer" style="width: 100%; height: 100%; object-fit: cover; display: block;" />`
                    : `<div style="width: 100%; height: 100%; background: linear-gradient(135deg, #1E293B, #020617);"></div>`
                }
${indent}          <div style="position: absolute; inset: 0; background: rgba(2, 6, 23, 0.25); pointer-events: none;"></div>
${indent}          <button type="button" data-sf-play aria-label="Putar video" style="position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); z-index: 3; width: 56px; height: 56px; border-radius: 9999px; border: none; background: rgba(255, 255, 255, 0.95); color: ${theme.accentColor}; box-shadow: 0 10px 25px rgba(0,0,0,0.25); display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 20px; padding-left: 4px;">&#9654;</button>
${indent}        </div>`
              : `<div style="position: relative; width: 100%; aspect-ratio: ${ratio}; background: #F1F5F9; overflow: hidden;">
${indent}          <img src="${escapeHtml(post.imageUrl)}" alt="${escapeHtml(
                  post.caption || `Postingan ${idx + 1}`
                )}" draggable="false" referrerpolicy="no-referrer" style="width: 100%; height: 100%; object-fit: cover; display: block;" />
${indent}        </div>`;

          const cleanUrl = sanitizeExternalUrl(post.url, '');
          const metaRow =
            post.likes?.trim() || post.comments?.trim() || cleanUrl
              ? `<div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; font-size: 11px; margin-bottom: 4px;">
${indent}            <div style="display: flex; align-items: center; gap: 10px; opacity: 0.82;">
${indent}              ${post.likes?.trim() ? `<span>&#10084;&#65039; <strong>${escapeHtml(post.likes)}</strong></span>` : ''}
${indent}              ${post.comments?.trim() ? `<span>&#128172; <strong>${escapeHtml(post.comments)}</strong></span>` : ''}
${indent}            </div>
${indent}            ${cleanUrl ? `<a href="${escapeHtml(cleanUrl)}" target="_blank" rel="noopener noreferrer" style="color: ${theme.accentColor}; font-weight: 600; text-decoration: none;">Lihat Post &#8599;</a>` : ''}
${indent}          </div>`
              : '';
          const captionRow = post.caption.trim()
            ? `<div style="font-size: 11px; line-height: 1.45; opacity: 0.85; white-space: pre-line;">${escapeHtml(post.caption)}</div>`
            : '';
          const footerHtml =
            metaRow || captionRow
              ? `\n${indent}        <div style="padding: 10px 12px;">${metaRow}${captionRow}</div>`
              : '';

          return `${indent}    <div style="flex: 0 0 100%; scroll-snap-align: start; box-sizing: border-box;">
${indent}      <div style="border: 1px solid ${theme.borderColor}; border-radius: ${mediaRadius}px; overflow: hidden; background: rgba(148, 163, 184, 0.05);">
${indent}        ${mediaHtml}${footerHtml}
${indent}      </div>
${indent}    </div>`;
        })
        .join('\n');

      const navHtml =
        posts.length > 1
          ? `\n${indent}    <div data-car-counter style="position: absolute; top: 10px; right: 10px; z-index: 3; padding: 2px 8px; border-radius: 9999px; background: rgba(15, 23, 42, 0.65); color: #FFFFFF; font-size: 10px; font-weight: 600; pointer-events: none;">1 / ${posts.length}</div>
${indent}    <button type="button" data-car-prev aria-label="Postingan sebelumnya" style="position: absolute; left: 8px; top: 50%; transform: translateY(-50%); z-index: 3; width: 28px; height: 28px; border-radius: 9999px; border: 1px solid #E2E8F0; background: rgba(255, 255, 255, 0.92); color: #0F172A; font-size: 16px; line-height: 1; display: flex; align-items: center; justify-content: center; cursor: pointer; opacity: 0.3;">&#8249;</button>
${indent}    <button type="button" data-car-next aria-label="Postingan berikutnya" style="position: absolute; right: 8px; top: 50%; transform: translateY(-50%); z-index: 3; width: 28px; height: 28px; border-radius: 9999px; border: 1px solid #E2E8F0; background: rgba(255, 255, 255, 0.92); color: #0F172A; font-size: 16px; line-height: 1; display: flex; align-items: center; justify-content: center; cursor: pointer;">&#8250;</button>`
          : '';

      const dotsHtml =
        posts.length > 1
          ? `\n${indent}  <div style="display: flex; align-items: center; justify-content: center; gap: 6px; margin-top: 10px;">\n${posts
              .map(
                (_, idx) =>
                  `${indent}    <button type="button" data-car-dot="${idx}" aria-label="Lihat postingan ${idx + 1}" style="height: 6px; width: ${
                    idx === 0 ? '20px' : '6px'
                  }; border-radius: 9999px; border: none; padding: 0; background: ${
                    idx === 0 ? meta.brandColor : '#CBD5E1'
                  }; cursor: pointer; transition: all 0.2s ease;"></button>`
              )
              .join('\n')}\n${indent}  </div>`
          : '';

      return `${indent}<div style="${css}; text-align: left; display: flex; flex-direction: column; gap: 12px;">
${indent}  <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px;">
${indent}    <div style="display: flex; align-items: center; gap: 10px; min-width: 0;">
${indent}      <div style="position: relative; flex-shrink: 0;">
${indent}        ${avatarHtml}
${indent}        <span style="position: absolute; bottom: -2px; right: -2px; width: 18px; height: 18px; border-radius: 9999px; background: ${meta.brandColor}; color: #FFFFFF; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 0 2px #FFFFFF;"><svg viewBox="${meta.viewBox}" width="10" height="10" aria-hidden="true">${meta.svgInner}</svg></span>
${indent}      </div>
${indent}      <div style="min-width: 0;">
${indent}        <div style="display: flex; align-items: center; gap: 4px; font-size: 13px; font-weight: 700;"><span>${escapeHtml(accountName)}</span>${verifiedHtml}</div>
${indent}        <div style="font-size: 11px; opacity: 0.7;">${escapeHtml(handle)} · ${escapeHtml(meta.label)}</div>
${indent}      </div>
${indent}    </div>
${indent}    <div style="display: flex; align-items: center; gap: 6px; flex-shrink: 0;">
${indent}      ${followerHtml}
${indent}      <a href="${escapeHtml(accountUrl)}" target="_blank" rel="noopener noreferrer" style="padding: 6px 12px; border-radius: 8px; background: ${meta.brandColor}; color: #FFFFFF; font-size: 11px; font-weight: 600; text-decoration: none; flex-shrink: 0;">${escapeHtml(followLabel)}</a>
${indent}    </div>
${indent}  </div>${bioHtml}
${indent}  <div data-carousel data-car-accent="${escapeHtml(meta.brandColor)}">
${indent}    <div style="position: relative;">
${indent}      <div data-car-track style="display: flex; overflow-x: auto; scroll-snap-type: x mandatory; scroll-behavior: smooth; border-radius: ${mediaRadius}px; -webkit-overflow-scrolling: touch; cursor: grab;">
${slidesHtml}
${indent}      </div>${navHtml}
${indent}    </div>${dotsHtml}
${indent}  </div>
${indent}</div>`;
    }

    case 'maps_place': {
      const photoUrl = block.content.mapsPhotoUrl ?? '';
      const photoBadgeLabel = (block.content.mapsPhotoBadgeLabel ?? 'Lihat foto').trim();
      const photoRatio = block.content.mapsPhotoRatio ?? '16/9';
      const title = block.content.mapsTitle ?? 'Nama Lokasi';
      const rawRating = block.content.mapsRating ?? 4.9;
      const clampedRating = Math.max(0, Math.min(5, Number.isFinite(rawRating) ? rawRating : 4.9));
      const formattedRating = clampedRating.toFixed(1).replace('.', ',');
      const reviewCount = (block.content.mapsReviewCount ?? '1.643').trim();
      const service = (block.content.mapsService ?? 'Layanan Satpam').trim();
      const accessible = block.content.mapsAccessible ?? true;
      const servicesList = (block.content.mapsServicesList ?? '')
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
      const address = (block.content.mapsAddress ?? '').trim();
      const mapsUrl = sanitizeExternalUrl(block.content.mapsUrl, '');
      const buttonLabel = (block.content.mapsButtonLabel ?? 'Buka di Google Maps').trim();
      const topRadius = Math.max(0, block.style.borderRadius - 1);
      const align = block.style.align;
      const justify = align === 'center' ? 'center' : align === 'right' ? 'flex-end' : 'flex-start';
      const safeId = block.id.replace(/[^a-zA-Z0-9_-]/g, '');

      const starsHtml = [0, 1, 2, 3, 4]
        .map((idx) => {
          const fillPercent = Math.max(0, Math.min(1, clampedRating - idx)) * 100;
          const gradId = `mstar_${safeId}_${idx}`;
          return `<svg viewBox="0 0 20 20" width="14" height="14" style="flex-shrink:0;" aria-hidden="true"><defs><linearGradient id="${gradId}" x1="0" y1="0" x2="1" y2="0"><stop offset="${fillPercent}%" stop-color="#FBBF24"/><stop offset="${fillPercent}%" stop-color="#E2E8F0"/></linearGradient></defs><path fill="url(#${gradId})" d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.967a1 1 0 00.95.69h4.17c.969 0 1.371 1.24.588 1.81l-3.374 2.45a1 1 0 00-.364 1.118l1.287 3.966c.3.922-.755 1.688-1.54 1.118l-3.374-2.45a1 1 0 00-1.176 0l-3.374 2.45c-.784.57-1.838-.196-1.539-1.118l1.287-3.966a1 1 0 00-.364-1.118L2.05 9.394c-.783-.57-.38-1.81.588-1.81h4.17a1 1 0 00.95-.69l1.29-3.967z"/></svg>`;
        })
        .join('');

      const photoBadgeHtml =
        photoBadgeLabel && photoUrl
          ? `<button type="button" data-maps-photo-open="${escapeHtml(photoUrl)}" data-maps-photo-title="${escapeHtml(
              title
            )}" style="position: absolute; bottom: 12px; left: 12px; display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 8px; border: 0; background: rgba(15, 23, 42, 0.78); color: #FFFFFF; font-size: 12px; font-weight: 500; cursor: pointer; backdrop-filter: blur(4px); box-shadow: 0 2px 6px rgba(0,0,0,0.2);"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg><span>${escapeHtml(
              photoBadgeLabel
            )}</span></button>`
          : '';

      const reviewHtml = reviewCount
        ? `<span style="opacity: 0.7; font-variant-numeric: tabular-nums;">(${escapeHtml(reviewCount)})</span>`
        : '';

      const accessibleIconSvg = `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#2563EB" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" title="Akses ramah kursi roda" aria-hidden="true"><circle cx="16" cy="4" r="1"/><path d="m18 19 1-7-6 1"/><path d="m5 8 3-3 5.5 3-2.36 3.5"/><path d="M4.24 14.5a5 5 0 0 0 6.88 6"/><path d="M13.76 17.5a5 5 0 0 0-6.88-6"/></svg>`;

      const serviceRowHtml =
        service || accessible
          ? `<div style="display: flex; flex-wrap: wrap; align-items: center; justify-content: ${justify}; gap: 6px; font-size: 12px; opacity: 0.85;">${
              service ? `<span>${escapeHtml(service)}</span>` : ''
            }${service && accessible ? '<span>·</span>' : ''}${
              accessible ? `<span style="display:inline-flex;align-items:center;">${accessibleIconSvg}</span>` : ''
            }</div>`
          : '';

      const serviceTagsHtml = servicesList.length
        ? `<div style="display: flex; flex-wrap: wrap; justify-content: ${justify}; gap: 6px; padding-top: 4px;">${servicesList
            .map(
              (tag) =>
                `<span style="padding: 2px 8px; border-radius: 6px; border: 1px solid ${theme.borderColor}; background: rgba(100,116,139,0.06); font-size: 11px; font-weight: 500; opacity: 0.9;">${escapeHtml(
                  tag
                )}</span>`
            )
            .join('')}</div>`
        : '';

      const addressHtml = address
        ? `<div style="display: flex; align-items: flex-start; justify-content: ${justify}; gap: 6px; font-size: 11px; opacity: 0.75; padding-top: 2px;"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;margin-top:1px;" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg><span>${escapeHtml(
            address
          )}</span></div>`
        : '';

      const buttonHtml =
        mapsUrl && buttonLabel
          ? `<div style="width: 100%; padding-top: 8px;"><a href="${escapeHtml(
              mapsUrl
            )}" target="_blank" rel="noopener noreferrer" style="width: 100%; box-sizing: border-box; padding: 8px 12px; border-radius: 8px; background: ${
              theme.accentColor
            }; color: #FFFFFF; font-size: 12px; font-weight: 600; text-decoration: none; display: inline-flex; align-items: center; justify-content: center; gap: 6px;"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg><span>${escapeHtml(
              buttonLabel
            )}</span></a></div>`
          : '';

      const imgHtml = photoUrl
        ? `<img src="${escapeHtml(photoUrl)}" alt="${escapeHtml(
            title
          )}" referrerpolicy="no-referrer" style="width: 100%; height: 100%; object-fit: cover; display: block;" />`
        : `<div style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; color: #94A3B8; font-size: 12px;">Foto lokasi belum tersedia</div>`;

      return `${indent}<div style="${css}; overflow: hidden;">
${indent}  <div style="position: relative; width: 100%; aspect-ratio: ${photoRatio}; background: #E2E8F0; overflow: hidden; border-top-left-radius: ${topRadius}px; border-top-right-radius: ${topRadius}px;">
${indent}    ${imgHtml}
${indent}    ${photoBadgeHtml}
${indent}  </div>
${indent}  <div style="padding: 14px 16px; display: flex; flex-direction: column; gap: 6px; text-align: ${align};">
${indent}    <div style="font-size: 16px; font-weight: 700; line-height: 1.35; letter-spacing: -0.01em;">${escapeHtml(
        title
      )}</div>
${indent}    <div style="display: flex; flex-wrap: wrap; align-items: center; justify-content: ${justify}; gap: 6px; font-size: 12px;">
${indent}      <span style="font-weight: 500; font-variant-numeric: tabular-nums; opacity: 0.85;">${escapeHtml(
        formattedRating
      )}</span>
${indent}      <span style="display: inline-flex; align-items: center; gap: 2px;">${starsHtml}</span>
${indent}      ${reviewHtml}
${indent}    </div>
${indent}    ${serviceRowHtml}
${indent}    ${serviceTagsHtml}
${indent}    ${addressHtml}
${indent}    ${buttonHtml}
${indent}  </div>
${indent}</div>`;
    }
  }
}

interface ExportedCatalogConfig {
  productType: CatalogProductType;
  detailEnabled: boolean;
  cartEnabled: boolean;
  whatsappNumber: string;
  storeName: string;
  whatsappIntro: string;
  askCustomerInfo: boolean;
  shippingEnabled: boolean;
  shippingOptions: CatalogShippingOptionConfig[];
  pickupNote: string;
  shippingNote: string;
  items: NonNullable<BuilderBlock['content']['catalogItems']>;
}

function collectCatalogData(
  blocks: BuilderBlock[],
  out: Record<string, ExportedCatalogConfig>
) {
  blocks.forEach((blk) => {
    if (blk.type === 'catalog') {
      out[blk.id] = {
        productType: blk.content.catalogProductType ?? 'physical',
        detailEnabled: blk.content.catalogDetailEnabled ?? true,
        cartEnabled: blk.content.catalogCartEnabled ?? true,
        whatsappNumber: blk.content.catalogWhatsappNumber ?? '6281234567890',
        storeName: blk.content.catalogStoreName ?? '',
        whatsappIntro:
          blk.content.catalogWhatsappIntro ?? 'Halo, saya ingin memesan produk berikut:',
        askCustomerInfo: blk.content.catalogAskCustomerInfo ?? true,
        shippingEnabled: blk.content.catalogShippingEnabled ?? true,
        shippingOptions: resolveCatalogShippingOptions(blk.content),
        pickupNote: blk.content.catalogPickupNote ?? '',
        shippingNote:
          blk.content.catalogShippingNote?.trim() ||
          'Biaya makanan / pesanan tidak termasuk biaya kirim (kurir).',
        items: blk.content.catalogItems ?? [],
      };
    }
    if (blk.children?.length) {
      collectCatalogData(blk.children, out);
    }
  });
}

export function generateProjectHtml(
  project: BuilderProject,
  exportOpts?: { projectId?: string }
): string {
  const adv = project.advanceOptions;
  const pub = resolveProjectPublishing(project);
  const ads = resolveProjectAds(project);
  const pageTitle = pub.seoTitle?.trim() || project.title || 'Halaman Usaha';
  const pageDescription =
    pub.seoDescription?.trim() || `Katalog dan layanan resmi ${project.title}.`;

  const cleanMetaPixel = ads.metaPixelId.replace(/[^0-9]/g, '');
  const cleanTiktokPixel = ads.tiktokPixelId.replace(/[^a-zA-Z0-9_-]/g, '');
  const cleanGoogleTag = ads.googleTagId.replace(/[^a-zA-Z0-9_-]/g, '');
  const cleanGoogleConvLabel = (ads.googleAdsConversionLabel ?? '').replace(/[^a-zA-Z0-9_/-]/g, '');
  const cleanGtmId = (ads.gtmContainerId ?? '').replace(/[^a-zA-Z0-9_-]/g, '');

  const metaPixelSnippet = cleanMetaPixel
    ? `
  <!-- Meta Pixel Code -->
  <script>
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
    n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
    document,'script','https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '${escapeHtml(cleanMetaPixel)}');
    fbq('track', 'PageView');
  </script>`
    : '';

  const tiktokPixelSnippet = cleanTiktokPixel
    ? `
  <!-- TikTok Pixel Code -->
  <script>
    !function(w,d,t){w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];
    ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie","holdConsent","revokeConsent","grantConsent"];
    ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};
    for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);
    ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e};
    ttq.load=function(e,n){var r="https://analytics.tiktok.com/i18n/pixel/events.js",o=n&&n.partner;
    ttq._i=ttq._i||{};ttq._i[e]=[];ttq._i[e]._u=r;ttq._t=ttq._t||{};ttq._t[e]=+new Date;
    ttq._o=ttq._o||{};ttq._o[e]=n||{};var a=document.createElement("script");a.type="text/javascript";a.async=!0;
    a.src=r+"?sdkid="+e+"&lib="+t;var s=document.getElementsByTagName("script")[0];s.parentNode.insertBefore(a,s)};
    ttq.load('${escapeHtml(cleanTiktokPixel)}');
    ttq.page();
    }(window,document,'ttq');
  </script>`
    : '';

  const googleTagSnippet = cleanGoogleTag
    ? `
  <!-- Google Tag (GA4 / Google Ads) -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=${escapeHtml(cleanGoogleTag)}"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '${escapeHtml(cleanGoogleTag)}');
  </script>`
    : '';

  const gtmSnippet = cleanGtmId
    ? `
  <!-- Google Tag Manager -->
  <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});
  var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;
  j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
  })(window,document,'script','dataLayer','${escapeHtml(cleanGtmId)}');</script>`
    : '';

  const bottomNavbar = resolveBottomNavbar(project);
  const enabledNavItems = bottomNavbar.items.filter((it) => it.enabled !== false);
  const showBottomNavbar = bottomNavbar.enabled && enabledNavItems.length > 0;

  const waAddonPhone = normalizeWhatsappNumber(ads.waAddonNumber);
  const waAddonMsg = (ads.waAddonGreeting ?? '').trim() || `Halo ${project.title}, saya tertarik dengan penawaran di halaman ini.`;
  const waAddonHref = `https://wa.me/${waAddonPhone}?text=${encodeURIComponent(waAddonMsg)}`;
  const waAddonHtml = ads.waAddonEnabled
    ? `
  <a id="lynk-wa-addon-btn" href="${escapeHtml(waAddonHref)}" target="_blank" rel="noopener noreferrer" data-lynk-wa-source="Add-On WA Meta" style="position: fixed; right: 16px; bottom: ${
        showBottomNavbar ? '88px' : '18px'
      }; z-index: 8900; display: inline-flex; align-items: center; gap: 8px; padding: 10px 16px; border-radius: 9999px; background: #059669; color: #FFFFFF; text-decoration: none; font-size: 13px; font-weight: 700; box-shadow: 0 10px 24px rgba(5, 150, 105, 0.35);">
    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
    <span>Chat WhatsApp</span>
  </a>`
    : '';

  const catalogMap: Record<string, ExportedCatalogConfig> = {};
  collectCatalogData(project.blocks, catalogMap);
  bottomNavbar.items.forEach((navItem) => {
    if (navItem.children?.length) {
      collectCatalogData(navItem.children, catalogMap);
    }
  });

  const bottomNavbarSheetsHtml = showBottomNavbar
    ? enabledNavItems
        .filter((it) => it.action === 'sheet')
        .map((it) => {
          const safeId = it.id.replace(/[^a-zA-Z0-9_-]/g, '');
          const sheetId = `sheet_nav_${safeId}`;
          const sheetTitle = it.sheetTitle?.trim() || it.label || 'Info';
          const inner = (it.children ?? [])
            .map((child) => renderBlockHtml(child, project.theme, adv, '        ', project.theme.textColor))
            .filter(Boolean)
            .join('\n');
          return `  <div id="${sheetId}" data-bottom-sheet class="lynk-sheet-backdrop" role="dialog" aria-modal="true" aria-label="${escapeHtml(
            sheetTitle
          )}">
    <div class="lynk-sheet-panel" style="background-color: ${project.theme.cardBg}; color: ${
            project.theme.textColor
          }; border-top: 1px solid ${project.theme.borderColor};">
      <div class="lynk-sheet-header" style="border-bottom: 1px solid ${project.theme.borderColor};">
        <div class="lynk-sheet-handle"></div>
        <div style="width: 100%; display: flex; align-items: center; justify-content: space-between; gap: 8px;">
          <div style="font-size: 15px; font-weight: 700; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${escapeHtml(
            sheetTitle
          )}</div>
          <button type="button" data-sheet-close aria-label="Tutup Bottom Sheet" style="width: 30px; height: 30px; border-radius: 9999px; border: 0; background: rgba(148, 163, 184, 0.16); color: inherit; font-size: 14px; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">&#10005;</button>
        </div>
      </div>
      <div class="lynk-sheet-body">
${inner || `        <div style="padding: 28px 0; text-align: center; font-size: 12px; opacity: 0.65;">Belum ada konten di dalam Bottom Sheet.</div>`}
      </div>
    </div>
  </div>`;
        })
        .join('\n')
    : '';

  const bottomNavbarHtml = showBottomNavbar
    ? `
  <nav class="lynk-bottom-nav" aria-label="Navigasi Bawah" style="background-color: ${
      bottomNavbar.barBg
    }; color: ${bottomNavbar.textColor}; border-top: 1px solid ${bottomNavbar.borderColor};">
    <div class="lynk-bottom-nav-grid" style="grid-template-columns: repeat(${
      enabledNavItems.length
    }, minmax(0, 1fr));">
${enabledNavItems
  .map((item) => {
    const safeId = item.id.replace(/[^a-zA-Z0-9_-]/g, '');
    const sheetId = `sheet_nav_${safeId}`;
    const isCenterHome =
      bottomNavbar.centerStyle === 'elevated' &&
      (item.action === 'scroll_top' || item.id === 'nav_home');
    const iconId = resolveButtonIcon(item.icon, item.label);
    const glyphId = iconId === 'none' ? 'info' : iconId;
    const iconSvg =
      renderButtonIconSvgString(glyphId, isCenterHome ? 20 : 18) ||
      '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/></svg>';
    const triggerAttr =
      item.action === 'scroll_top' ? 'data-nav-home="1"' : `data-sheet-open="${sheetId}"`;
    const iconWrapHtml = isCenterHome
      ? `<span class="lynk-bottom-nav-home-fab" style="background-color: ${bottomNavbar.accentColor}; border-color: ${bottomNavbar.barBg};">${iconSvg}</span>`
      : `<span class="lynk-bottom-nav-icon">${iconSvg}</span>`;
    const labelColorStyle = isCenterHome
      ? `style="color: ${bottomNavbar.accentColor}; font-weight: 700;"`
      : '';
    return `      <button type="button" class="lynk-bottom-nav-btn" ${triggerAttr}>
        ${iconWrapHtml}
        <span class="lynk-bottom-nav-label" ${labelColorStyle}>${escapeHtml(
      item.label || 'Menu'
    )}</span>
      </button>`;
  })
  .join('\n')}
    </div>
  </nav>`
    : '';

  const serializedStore = JSON.stringify({
    projectId: exportOpts?.projectId || '',
    projectTitle: project.title,
    slug: pub.slug,
    showUnitSold: adv.showUnitSold,
    ads: {
      metaPixelId: cleanMetaPixel,
      metaWaEvent: ads.metaWaEvent || 'Lead',
      tiktokPixelId: cleanTiktokPixel,
      googleTagId: cleanGoogleTag,
      googleAdsConversionLabel: cleanGoogleConvLabel,
      appendAdAttributionToWa: ads.appendAdAttributionToWa,
    },
    theme: {
      canvasBg: project.theme.canvasBg,
      cardBg: project.theme.cardBg,
      textColor: project.theme.textColor,
      accentColor: project.theme.accentColor,
      borderColor: project.theme.borderColor,
    },
    catalogs: catalogMap,
  }).replace(/</g, '\\u003c');

  const bodyBlocks = project.blocks
    .map((block) => {
      const rendered = renderBlockHtml(block, project.theme, adv, '      ');
      if (!rendered) return '';
      return `    <div class="${block.style.fullBleed ? 'page-full' : 'page-pad'}">\n${rendered}\n    </div>`;
    })
    .filter(Boolean)
    .join('\n');

  return `<!doctype html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${escapeHtml(pageTitle)}</title>
  <meta name="description" content="${escapeHtml(pageDescription)}" />
  <meta property="og:type" content="website" />
  <meta property="og:title" content="${escapeHtml(pageTitle)}" />
  <meta property="og:description" content="${escapeHtml(pageDescription)}" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet" />${metaPixelSnippet}${tiktokPixelSnippet}${googleTagSnippet}${gtmSnippet}
  <style>
    body {
      margin: 0;
      padding: ${
        project.advanceOptions.pageTopPadding ??
        (project.blocks[0]?.style.fullBleed ? 0 : 12)
      }px 0 ${showBottomNavbar ? '96px' : '24px'} 0;
      min-height: 100vh;
      font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
      background-color: ${project.theme.canvasBg};
      color: ${project.theme.textColor};
      box-sizing: border-box;
    }
    .page-shell {
      width: 100%;
    }
    .page-pad {
      max-width: 420px;
      margin: 0 auto;
      padding-left: 16px;
      padding-right: 16px;
      box-sizing: border-box;
    }
    .page-full {
      width: 100%;
      padding-left: 0;
      padding-right: 0;
      box-sizing: border-box;
    }
    @media (min-width: 768px) {
      .page-pad {
        max-width: 680px;
        padding-left: 24px;
        padding-right: 24px;
      }
    }
    [data-car-track] {
      scrollbar-width: none;
    }
    [data-car-track]::-webkit-scrollbar {
      display: none;
    }
    .lynk-bottom-nav {
      position: fixed;
      left: 0;
      right: 0;
      bottom: 0;
      z-index: 8800;
      padding: 6px 8px calc(8px + env(safe-area-inset-bottom, 0px)) 8px;
      box-shadow: 0 -8px 24px rgba(15, 23, 42, 0.08);
      box-sizing: border-box;
    }
    .lynk-bottom-nav-grid {
      max-width: 540px;
      margin: 0 auto;
      display: grid;
      align-items: end;
      gap: 2px;
    }
    .lynk-bottom-nav-btn {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-end;
      gap: 3px;
      padding: 2px 4px;
      border: 0;
      border-radius: 12px;
      background: transparent;
      color: inherit;
      font-family: inherit;
      cursor: pointer;
      min-width: 0;
    }
    .lynk-bottom-nav-btn:active {
      opacity: 0.78;
    }
    .lynk-bottom-nav-icon {
      width: 24px;
      height: 24px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .lynk-bottom-nav-home-fab {
      margin-top: -22px;
      width: 46px;
      height: 46px;
      border-radius: 9999px;
      border: 4px solid #FFFFFF;
      color: #FFFFFF;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 6px 18px rgba(15, 23, 42, 0.22);
      flex-shrink: 0;
    }
    .lynk-bottom-nav-label {
      font-size: 10px;
      font-weight: 600;
      line-height: 1.2;
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      opacity: 0.88;
    }
    .lynk-sheet-backdrop {
      position: fixed;
      inset: 0;
      z-index: 9600;
      display: flex;
      align-items: flex-end;
      justify-content: center;
      background: rgba(2, 6, 23, 0.56);
      backdrop-filter: blur(2px);
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.24s ease;
    }
    .lynk-sheet-backdrop.is-open {
      opacity: 1;
      pointer-events: auto;
    }
    .lynk-sheet-panel {
      width: 100%;
      max-width: 540px;
      max-height: 85vh;
      border-top-left-radius: 22px;
      border-top-right-radius: 22px;
      box-shadow: 0 -18px 48px rgba(2, 6, 23, 0.28);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      transform: translateY(100%);
      transition: transform 0.28s cubic-bezier(0.22, 1, 0.36, 1);
      box-sizing: border-box;
    }
    .lynk-sheet-backdrop.is-open .lynk-sheet-panel {
      transform: translateY(0);
    }
    .lynk-sheet-header {
      padding: 10px 16px 12px 16px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
      flex-shrink: 0;
    }
    .lynk-sheet-handle {
      width: 40px;
      height: 4px;
      border-radius: 9999px;
      background: rgba(148, 163, 184, 0.55);
    }
    .lynk-sheet-body {
      flex: 1;
      overflow-y: auto;
      padding: 16px;
      box-sizing: border-box;
    }
  </style>
</head>
<body>
  <main id="lynk-main-view" class="page-shell">
${bodyBlocks}
  </main>
  <section id="lynk-subpage-detail" class="page-pad" style="display: none; padding-bottom: 108px;"></section>
  <section id="lynk-subpage-cart" class="page-pad" style="display: none; padding-bottom: 100px;"></section>${waAddonHtml}${bottomNavbarHtml}${bottomNavbarSheetsHtml ? '\n' + bottomNavbarSheetsHtml : ''}
  <div id="lynk-cart-bar" style="display: none; position: fixed; left: 0; right: 0; bottom: ${
      showBottomNavbar ? '68px' : '0'
    }; z-index: 9000; background: #FFFFFF; border-top: 1px solid #E2E8F0; box-shadow: 0 -8px 24px rgba(15, 23, 42, 0.08);">
    <div class="page-pad" style="padding-top: 10px; padding-bottom: 10px; display: flex; align-items: center; justify-content: space-between; gap: 12px;">
      <div style="min-width: 0;">
        <div id="lynk-cart-bar-count" style="font-size: 11px; font-weight: 600; color: #64748B;">0 item di keranjang</div>
        <div id="lynk-cart-bar-total" style="font-size: 14px; font-weight: 700; color: #0F172A;">Rp 0</div>
      </div>
      <button type="button" id="lynk-open-cart-btn" style="padding: 9px 16px; border: 0; border-radius: 12px; background: #059669; color: #FFFFFF; font-size: 12px; font-weight: 700; cursor: pointer; flex-shrink: 0;">Lihat Keranjang</button>
    </div>
  </div>
  <div id="lynk-toast" style="display: none; position: fixed; bottom: ${
      showBottomNavbar ? '92px' : '76px'
    }; left: 50%; transform: translateX(-50%); z-index: 9700; background: rgba(15, 23, 42, 0.92); color: #FFFFFF; padding: 7px 14px; border-radius: 9999px; font-size: 12px; font-weight: 600; white-space: nowrap; pointer-events: none;"></div>
  <script type="application/json" id="lynk-store-data">${serializedStore}</script>
  <script>
    (function () {
      var carousels = document.querySelectorAll('[data-carousel]');
      carousels.forEach(function (car) {
        var track = car.querySelector('[data-car-track]');
        if (!track) return;
        var prev = car.querySelector('[data-car-prev]');
        var next = car.querySelector('[data-car-next]');
        var counter = car.querySelector('[data-car-counter]');
        var dots = car.querySelectorAll('[data-car-dot]');
        var accent = car.getAttribute('data-car-accent') || '#2563EB';
        var total = dots.length || track.children.length;
        var active = 0;
        var dragging = false;
        var moved = false;
        var startX = 0;
        var startLeft = 0;

        function syncUI(idx) {
          active = Math.max(0, Math.min(total - 1, idx));
          if (counter) counter.textContent = (active + 1) + ' / ' + total;
          if (prev) prev.style.opacity = active === 0 ? '0.3' : '0.95';
          if (next) next.style.opacity = active === total - 1 ? '0.3' : '0.95';
          dots.forEach(function (d, i) {
            d.style.width = i === active ? '20px' : '6px';
            d.style.background = i === active ? accent : '#CBD5E1';
          });
        }
        function goTo(idx) {
          var bounded = Math.max(0, Math.min(total - 1, idx));
          track.scrollTo({ left: bounded * track.clientWidth, behavior: 'smooth' });
          syncUI(bounded);
        }
        track.addEventListener('scroll', function () {
          if (!track.clientWidth) return;
          var idx = Math.round(track.scrollLeft / track.clientWidth);
          if (idx !== active) syncUI(idx);
        });
        if (prev) prev.addEventListener('click', function () { goTo(active - 1); });
        if (next) next.addEventListener('click', function () { goTo(active + 1); });
        dots.forEach(function (dot) {
          dot.addEventListener('click', function () {
            goTo(Number(dot.getAttribute('data-car-dot') || 0));
          });
        });
        track.addEventListener('pointerdown', function (e) {
          if (e.pointerType !== 'mouse' || e.button !== 0) return;
          dragging = true;
          moved = false;
          startX = e.clientX;
          startLeft = track.scrollLeft;
          track.style.cursor = 'grabbing';
        });
        window.addEventListener('pointermove', function (e) {
          if (!dragging) return;
          var dx = e.clientX - startX;
          if (Math.abs(dx) > 6) moved = true;
          if (moved) track.scrollLeft = startLeft - dx;
        });
        window.addEventListener('pointerup', function () {
          if (!dragging) return;
          dragging = false;
          track.style.cursor = 'grab';
          if (moved && track.clientWidth) {
            goTo(Math.round(track.scrollLeft / track.clientWidth));
          }
          setTimeout(function () { moved = false; }, 60);
        });
        track.addEventListener('click', function (e) {
          if (moved) e.preventDefault();
        }, true);
      });
      var sfPlayBtns = document.querySelectorAll('[data-sf-play]');
      sfPlayBtns.forEach(function (btn) {
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          var box = btn.closest('[data-sf-video-box]');
          if (!box) return;
          var kind = box.getAttribute('data-sf-kind');
          var id = box.getAttribute('data-sf-id') || '';
          var rawUrl = box.getAttribute('data-sf-url') || '';
          function mountDirect(src) {
            box.innerHTML = '';
            var v = document.createElement('video');
            v.src = src;
            v.controls = true;
            v.autoplay = true;
            v.playsInline = true;
            v.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block;background:#000;';
            box.appendChild(v);
            v.play().catch(function () {});
          }
          function mountIframe(src) {
            box.innerHTML = '';
            var ifr = document.createElement('iframe');
            ifr.src = src;
            ifr.setAttribute('allow', 'autoplay; encrypted-media; picture-in-picture');
            ifr.allowFullscreen = true;
            ifr.style.cssText = 'width:100%;height:100%;border:0;display:block;background:#000;';
            box.appendChild(ifr);
          }
          if (kind === 'direct' && id) {
            mountDirect(id);
          } else if (kind === 'youtube' && id) {
            mountIframe('https://www.youtube.com/embed/' + id + '?autoplay=1&rel=0&modestbranding=1&playsinline=1');
          } else if (kind && rawUrl && location.protocol.indexOf('http') === 0) {
            fetch('/api/resolve-video?platform=' + encodeURIComponent(kind) + '&url=' + encodeURIComponent(rawUrl))
              .then(function (r) { return r.ok ? r.json() : null; })
              .then(function (d) {
                if (d && d.directVideoUrl) { mountDirect(d.directVideoUrl); return; }
                var resolvedId = (d && d.videoId) || id;
                if (kind === 'tiktok') mountIframe('https://www.tiktok.com/player/v1/' + resolvedId + '?autoplay=1&rel=0');
                else if (kind === 'instagram') mountIframe('https://www.instagram.com/' + resolvedId + '/embed/?autoplay=1');
                else if (kind === 'facebook') mountIframe('https://www.facebook.com/plugins/video.php?href=' + encodeURIComponent((d && d.canonicalUrl) || rawUrl) + '&show_text=false&autoplay=true');
              })
              .catch(function () {});
          } else if (kind === 'tiktok' && id) {
            mountIframe('https://www.tiktok.com/player/v1/' + id + '?autoplay=1&rel=0');
          } else if (kind === 'instagram' && id) {
            mountIframe('https://www.instagram.com/' + id + '/embed/?autoplay=1');
          } else if (kind === 'facebook' && (id || rawUrl)) {
            mountIframe('https://www.facebook.com/plugins/video.php?href=' + encodeURIComponent(id || rawUrl) + '&show_text=false&autoplay=true');
          }
        });
      });
    })();
    (function () {
      var players = document.querySelectorAll('[data-vid-player]');
      if (!players.length) return;
      function sendCmd(wrap, cmd, val) {
        var platform = wrap.getAttribute('data-vid-platform');
        var videoEl = wrap.querySelector('video');
        if (videoEl) {
          if (cmd === 'play') {
            videoEl.play().catch(function () {
              videoEl.muted = true;
              wrap._vidMuted = true;
              syncVolumeUI(wrap, Number(wrap.getAttribute('data-vid-volume') || 75), true);
              videoEl.play().catch(function () {});
            });
          } else if (cmd === 'pause') videoEl.pause();
          else if (cmd === 'mute') videoEl.muted = true;
          else if (cmd === 'unMute') videoEl.muted = false;
          else if (cmd === 'setVolume' && val !== undefined) {
            videoEl.volume = Math.max(0, Math.min(1, val / 100));
          }
          return;
        }
        var iframe = wrap.querySelector('iframe');
        if (!iframe || !iframe.contentWindow) return;
        if (platform === 'youtube') {
          var func = cmd === 'play' ? 'playVideo' : cmd === 'pause' ? 'pauseVideo' : cmd;
          try {
            iframe.contentWindow.postMessage(JSON.stringify({ event: 'command', func: func, args: val !== undefined ? [val] : [] }), '*');
          } catch (e) {}
          return;
        }
        if (platform === 'tiktok') {
          try {
            if (cmd === 'mute') {
              iframe.contentWindow.postMessage({ 'x-tiktok-player': true, type: 'mute' }, '*');
            } else if (cmd === 'unMute') {
              iframe.contentWindow.postMessage({ 'x-tiktok-player': true, type: 'unMute' }, '*');
            } else if (cmd === 'setVolume' && val !== undefined) {
              iframe.contentWindow.postMessage({ 'x-tiktok-player': true, type: 'setVolume', value: Math.max(0, Math.min(100, Math.round(val))) }, '*');
            } else {
              iframe.contentWindow.postMessage({ 'x-tiktok-player': true, type: cmd }, '*');
            }
          } catch (e) {}
        }
      }
      function makeFallbackBox(text) {
        var box = document.createElement('div');
        box.style.cssText = 'width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#0F172A,#020617);color:#CBD5E1;font-size:12px;font-weight:500;';
        box.textContent = text;
        return box;
      }
      function makeCover(wrap) {
        var platform = wrap.getAttribute('data-vid-platform');
        var id = wrap.getAttribute('data-vid-id');
        var poster = wrap._resolvedPoster || wrap.getAttribute('data-vid-poster') || '';
        var cover = document.createElement('div');
        cover.setAttribute('data-vid-cover', '');
        cover.style.cssText = 'position:absolute;inset:0;z-index:2;transition:opacity 0.3s ease;opacity:1;';
        if (poster) {
          var pImg = document.createElement('img');
          pImg.src = poster;
          pImg.alt = 'Video preview';
          pImg.referrerPolicy = 'no-referrer';
          pImg.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block;';
          pImg.onerror = function () {
            cover.innerHTML = '';
            cover.appendChild(makeFallbackBox(wrap._vidPlaying && !wrap._vidPaused ? 'Memutar video...' : 'Video siap diputar'));
          };
          cover.appendChild(pImg);
          return cover;
        }
        if (platform === 'youtube') {
          var hq = 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg';
          var max = 'https://i.ytimg.com/vi/' + id + '/maxresdefault.jpg';
          var img = document.createElement('img');
          img.src = max;
          img.alt = 'Video preview';
          img.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block;';
          img.onerror = function () {
            if (img.src !== hq) { img.src = hq; }
            else {
              cover.innerHTML = '';
              cover.appendChild(makeFallbackBox(wrap._vidPlaying && !wrap._vidPaused ? 'Memutar video...' : 'Video siap diputar'));
            }
          };
          cover.appendChild(img);
          return cover;
        }
        cover.appendChild(makeFallbackBox(wrap._vidPlaying && !wrap._vidPaused ? 'Memutar video...' : 'Video siap diputar'));
        return cover;
      }
      function clearPlayerTimers(wrap) {
        if (wrap._vidRevealTimer) { clearTimeout(wrap._vidRevealTimer); wrap._vidRevealTimer = null; }
        if (wrap._vidFallbackTimer) { clearTimeout(wrap._vidFallbackTimer); wrap._vidFallbackTimer = null; }
        if (wrap._vidAutoCheckTimer) { clearTimeout(wrap._vidAutoCheckTimer); wrap._vidAutoCheckTimer = null; }
        wrap._vidRevealScheduled = false;
      }
      function syncVolumeUI(wrap, vol, muted) {
        var slider = wrap.querySelector('[data-vid-vol]');
        var label = wrap.querySelector('[data-vid-vol-label]');
        var muteBtn = wrap.querySelector('[data-vid-mute]');
        var shown = muted ? 0 : vol;
        if (slider) slider.value = String(shown);
        if (label) label.textContent = shown + '%';
        if (muteBtn) muteBtn.textContent = shown === 0 ? '\uD83D\uDD07' : '\uD83D\uDD0A';
      }
      function showCover(wrap) {
        wrap._vidRevealed = false;
        var cover = wrap.querySelector('[data-vid-cover]');
        if (cover) {
          cover.style.opacity = '1';
          cover.style.pointerEvents = 'auto';
        }
      }
      function revealPlayer(wrap) {
        wrap._vidRevealed = true;
        if (wrap._vidRevealTimer) { clearTimeout(wrap._vidRevealTimer); wrap._vidRevealTimer = null; }
        if (wrap._vidFallbackTimer) { clearTimeout(wrap._vidFallbackTimer); wrap._vidFallbackTimer = null; }
        var cover = wrap.querySelector('[data-vid-cover]');
        if (cover) {
          cover.style.opacity = '0';
          cover.style.pointerEvents = 'none';
        }
        var platform = wrap.getAttribute('data-vid-platform');
        if (platform === 'facebook' || platform === 'instagram') {
          var iframe = wrap.querySelector('iframe');
          if (iframe) iframe.style.pointerEvents = 'auto';
          var shield = wrap.querySelector('[data-vid-shield]');
          if (shield && shield.parentNode) shield.parentNode.removeChild(shield);
        }
      }
      function setButtonStates(wrap, playing, paused) {
        var playBtn = wrap.querySelector('[data-vid-play]');
        var pauseBtn = wrap.querySelector('[data-vid-pause]');
        var accent = wrap.getAttribute('data-vid-accent') || '#2563EB';
        var activePlay = playing && !paused;
        playBtn.disabled = activePlay;
        playBtn.style.background = activePlay ? '#0F172A' : accent;
        playBtn.style.opacity = activePlay ? '0.8' : '1';
        playBtn.style.cursor = activePlay ? 'default' : 'pointer';
        pauseBtn.disabled = !activePlay;
        pauseBtn.style.opacity = activePlay ? '1' : '0.45';
        pauseBtn.style.cursor = activePlay ? 'pointer' : 'not-allowed';
      }
      function resetPlayer(wrap) {
        clearPlayerTimers(wrap);
        wrap._vidMounted = false;
        wrap._vidPlaying = false;
        wrap._vidPaused = false;
        wrap._vidPlayedOnce = false;
        wrap._vidRevealed = false;
        var stage = wrap.querySelector('[data-vid-stage]');
        stage.innerHTML = '';
        stage.appendChild(makeCover(wrap));
        setButtonStates(wrap, false, false);
      }
      function startOrResume(wrap, isAuto) {
        clearPlayerTimers(wrap);
        var platform = wrap.getAttribute('data-vid-platform');
        var id = wrap._resolvedId || wrap.getAttribute('data-vid-id');
        var direct = wrap._resolvedDirect || wrap.getAttribute('data-vid-direct') || '';
        var vol = Number(wrap.getAttribute('data-vid-volume') || 75);
        var stage = wrap.querySelector('[data-vid-stage]');
        wrap._vidAutoMode = Boolean(isAuto);
        wrap._vidPlaying = true;
        wrap._vidPaused = false;
        setButtonStates(wrap, true, false);
        showCover(wrap);
        if (!wrap._vidMounted) {
          wrap._vidMounted = true;
          wrap._vidMuted = false;
          wrap._vidPlayedOnce = false;
          wrap._autoUnmuteAt = 0;
          if (direct) {
            stage.innerHTML = '';
            var vid = document.createElement('video');
            vid.src = direct;
            vid.playsInline = true;
            vid.preload = 'auto';
            vid.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block;';
            vid.volume = Math.max(0, Math.min(1, vol / 100));
            vid.muted = wrap._vidMuted || vol === 0;
            vid.addEventListener('playing', function () {
              wrap._vidPlayedOnce = true;
              revealPlayer(wrap);
            });
            vid.addEventListener('ended', function () {
              resetPlayer(wrap);
            });
            vid.addEventListener('error', function () {
              wrap._resolvedDirect = '';
              wrap.setAttribute('data-vid-direct', '');
              wrap._vidMounted = false;
              startOrResume(wrap, isAuto);
            });
            stage.appendChild(vid);
            stage.appendChild(makeCover(wrap));
            vid.play().catch(function () {
              vid.muted = true;
              wrap._vidMuted = true;
              syncVolumeUI(wrap, vol, true);
              vid.play().catch(function () {});
            });
            return;
          }
          var origin = location.origin && location.origin.indexOf('http') === 0 ? '&origin=' + encodeURIComponent(location.origin) : '';
          var fbHref = wrap._resolvedCanonical || id;
          var fbMute = (isAuto || wrap._vidMuted || vol === 0) ? 1 : 0;
          var src = platform === 'tiktok'
            ? 'https://www.tiktok.com/player/v1/' + id + '?autoplay=1&controls=0&progress_bar=0&play_button=0&volume_control=0&fullscreen_button=0&timestamp=0&music_info=0&description=0&rel=0&loop=0'
            : platform === 'instagram'
            ? 'https://www.instagram.com/' + id + '/embed/?autoplay=1'
            : platform === 'facebook'
            ? 'https://www.facebook.com/plugins/video.php?href=' + encodeURIComponent(fbHref) + '&show_text=false&autoplay=true&mute=' + fbMute
            : 'https://www.youtube.com/embed/' + id + '?autoplay=1&controls=0&modestbranding=1&rel=0&iv_load_policy=3&fs=0&disablekb=1&playsinline=1&enablejsapi=1' + origin;
          stage.innerHTML = '';
          var iframe = document.createElement('iframe');
          iframe.src = src;
          iframe.setAttribute('allow', 'autoplay; encrypted-media; picture-in-picture; clipboard-write');
          iframe.style.cssText = platform === 'instagram'
            ? 'position:absolute;top:-54px;left:-2px;width:calc(100% + 4px);height:calc(100% + 132px);border:0;pointer-events:none;display:block;'
            : 'width:100%;height:100%;border:0;pointer-events:none;display:block;';
          var shield = document.createElement('div');
          shield.setAttribute('data-vid-shield', '');
          shield.style.cssText = 'position:absolute;inset:0;z-index:1;';
          var cover = makeCover(wrap);
          iframe.addEventListener('load', function () {
            try {
              if (platform === 'instagram' || platform === 'facebook') {
                if (wrap._vidPlaying && !wrap._vidPaused && !wrap._vidRevealScheduled) {
                  wrap._vidRevealScheduled = true;
                  if (wrap._vidFallbackTimer) { clearTimeout(wrap._vidFallbackTimer); wrap._vidFallbackTimer = null; }
                  wrap._vidRevealTimer = setTimeout(function () { revealPlayer(wrap); }, 1500);
                }
              } else if (platform === 'youtube') {
                iframe.contentWindow.postMessage(JSON.stringify({ event: 'listening' }), '*');
                sendCmd(wrap, 'addEventListener', ['onStateChange']);
                if (!wrap._vidMuted && vol > 0) sendCmd(wrap, 'setVolume', [vol]);
              } else if (platform === 'tiktok') {
                if (!wrap._vidMuted && vol > 0) {
                  sendCmd(wrap, 'unMute');
                  sendCmd(wrap, 'setVolume', vol);
                } else {
                  sendCmd(wrap, 'mute');
                }
                sendCmd(wrap, 'play');
              }
            } catch (e) {}
          });
          stage.appendChild(iframe);
          stage.appendChild(shield);
          stage.appendChild(cover);
        } else {
          if (direct) {
            revealPlayer(wrap);
          }
          if (!wrap._vidMuted && vol > 0) {
            sendCmd(wrap, 'unMute');
            sendCmd(wrap, 'setVolume', vol);
          }
          sendCmd(wrap, 'play');
        }
        var fbDelay = platform === 'instagram' ? 2600 : platform === 'facebook' ? 2800 : 4800;
        wrap._vidFallbackTimer = setTimeout(function () { revealPlayer(wrap); }, fbDelay);
        if (platform === 'youtube' && isAuto && !wrap._vidPlayedOnce) {
          wrap._vidAutoCheckTimer = setTimeout(function () {
            if (!wrap._vidPlayedOnce) {
              wrap._vidMuted = true;
              syncVolumeUI(wrap, vol, true);
              sendCmd(wrap, 'mute');
              sendCmd(wrap, 'play');
            }
          }, 2000);
        }
      }
      players.forEach(function (wrap) {
        var platform = wrap.getAttribute('data-vid-platform');
        var rawUrl = wrap.getAttribute('data-vid-url') || '';
        var customPoster = wrap.getAttribute('data-vid-poster') || '';
        if (platform !== 'youtube' && rawUrl && location.protocol.indexOf('http') === 0) {
          fetch('/api/resolve-video?platform=' + encodeURIComponent(platform) + '&url=' + encodeURIComponent(rawUrl))
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (d) {
              if (!d) return;
              if (d.canonicalUrl) wrap._resolvedCanonical = d.canonicalUrl;
              if (d.directVideoUrl) wrap._resolvedDirect = d.directVideoUrl;
              if (d.videoId) wrap._resolvedId = d.videoId;
              if (d.posterUrl && !customPoster) {
                wrap._resolvedPoster = d.posterUrl;
                var cover = wrap.querySelector('[data-vid-cover]');
                if (cover && !wrap._vidRevealed && cover.parentNode) {
                  var nextCover = makeCover(wrap);
                  nextCover.style.opacity = cover.style.opacity || '1';
                  nextCover.style.pointerEvents = cover.style.pointerEvents || 'auto';
                  cover.parentNode.replaceChild(nextCover, cover);
                }
              }
            })
            .catch(function () {});
        }
        if (platform === 'tiktok' && rawUrl) {
          fetch('https://www.tiktok.com/oembed?url=' + encodeURIComponent(rawUrl))
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (data) {
              if (!data) return;
              if (!wrap._resolvedId && data.embed_product_id) wrap._resolvedId = data.embed_product_id;
              if (data.thumbnail_url && !customPoster && !wrap._resolvedPoster) {
                wrap._resolvedPoster = data.thumbnail_url;
                var cover = wrap.querySelector('[data-vid-cover]');
                if (cover && !wrap._vidRevealed && cover.parentNode) {
                  var nextCover = makeCover(wrap);
                  nextCover.style.opacity = cover.style.opacity || '1';
                  nextCover.style.pointerEvents = cover.style.pointerEvents || 'auto';
                  cover.parentNode.replaceChild(nextCover, cover);
                }
              }
            })
            .catch(function () {});
        }
        var playBtn = wrap.querySelector('[data-vid-play]');
        var pauseBtn = wrap.querySelector('[data-vid-pause]');
        var muteBtn = wrap.querySelector('[data-vid-mute]');
        var slider = wrap.querySelector('[data-vid-vol]');
        playBtn.addEventListener('click', function () {
          startOrResume(wrap, false);
        });
        pauseBtn.addEventListener('click', function () {
          if (!wrap._vidMounted || wrap._vidPaused) return;
          clearPlayerTimers(wrap);
          wrap._vidPaused = true;
          wrap._vidPlaying = false;
          var hasDirect = Boolean(wrap._resolvedDirect || wrap.getAttribute('data-vid-direct'));
          if (!hasDirect && (platform === 'facebook' || platform === 'instagram')) {
            wrap._vidMounted = false;
            var st = wrap.querySelector('[data-vid-stage]');
            st.innerHTML = '';
            st.appendChild(makeCover(wrap));
          } else {
            sendCmd(wrap, 'pause');
          }
          showCover(wrap);
          setButtonStates(wrap, false, true);
        });
        if (muteBtn) {
          muteBtn.addEventListener('click', function () {
            var vol = Number(wrap.getAttribute('data-vid-volume') || 75);
            var nextMuted = !wrap._vidMuted;
            wrap._vidMuted = nextMuted;
            if (nextMuted) {
              sendCmd(wrap, 'mute');
              syncVolumeUI(wrap, vol, true);
            } else {
              if (vol === 0) {
                vol = 75;
                wrap.setAttribute('data-vid-volume', '75');
              }
              sendCmd(wrap, 'unMute');
              sendCmd(wrap, 'setVolume', vol);
              syncVolumeUI(wrap, vol, false);
            }
          });
        }
        if (slider) {
          slider.addEventListener('input', function () {
            var nextVol = Number(slider.value);
            wrap.setAttribute('data-vid-volume', String(nextVol));
            wrap._vidMuted = nextVol === 0;
            if (nextVol === 0) {
              sendCmd(wrap, 'mute');
            } else {
              sendCmd(wrap, 'unMute');
              sendCmd(wrap, 'setVolume', nextVol);
            }
            syncVolumeUI(wrap, nextVol, nextVol === 0);
          });
        }
        if (wrap.getAttribute('data-vid-autoplay') === '1') {
          startOrResume(wrap, true);
        }
      });
      window.addEventListener('message', function (ev) {
        if (!ev.origin) return;
        var isYt = ev.origin.indexOf('youtube.com') !== -1 || ev.origin.indexOf('youtube-nocookie.com') !== -1;
        var isTt = ev.origin.indexOf('tiktok.com') !== -1;
        if (!isYt && !isTt) return;
        var data = ev.data;
        if (typeof data === 'string') {
          try { data = JSON.parse(data); } catch (e) { return; }
        }
        if (!data) return;
        players.forEach(function (wrap) {
          var platform = wrap.getAttribute('data-vid-platform');
          if ((platform === 'youtube' && !isYt) || (platform === 'tiktok' && !isTt)) return;
          var iframe = wrap.querySelector('iframe');
          if (!iframe || iframe.contentWindow !== ev.source) return;
          var vol = Number(wrap.getAttribute('data-vid-volume') || 75);
          var state = null;
          if (platform === 'youtube') {
            if (data.event === 'infoDelivery' && data.info && typeof data.info.playerState === 'number') state = data.info.playerState;
            else if (data.event === 'onStateChange' && typeof data.info === 'number') state = data.info;
          } else if (platform === 'tiktok') {
            if (data.type === 'onPlayerReady') {
              if (!wrap._vidMuted && vol > 0) {
                sendCmd(wrap, 'unMute');
                sendCmd(wrap, 'setVolume', vol);
              } else {
                sendCmd(wrap, 'mute');
              }
              if (wrap._vidPlaying && !wrap._vidPaused) sendCmd(wrap, 'play');
              return;
            } else if (data.type === 'onMute' && typeof data.value === 'boolean') {
              wrap._vidMuted = data.value;
              syncVolumeUI(wrap, vol, data.value);
              return;
            } else if (data.type === 'onStateChange' && typeof data.value === 'number') {
              state = data.value;
            } else if (data.type === 'onEnded') {
              state = 0;
            }
          }
          if (state === 1) {
            wrap._vidPlayedOnce = true;
            if (wrap._vidAutoCheckTimer) { clearTimeout(wrap._vidAutoCheckTimer); wrap._vidAutoCheckTimer = null; }
            if (!wrap._vidMuted && vol > 0) {
              sendCmd(wrap, 'unMute');
              sendCmd(wrap, 'setVolume', vol);
            }
            if (!wrap._vidRevealScheduled) {
              wrap._vidRevealScheduled = true;
              if (wrap._vidFallbackTimer) { clearTimeout(wrap._vidFallbackTimer); wrap._vidFallbackTimer = null; }
              var rDelay = platform === 'youtube' ? 3800 : 1800;
              wrap._vidRevealTimer = setTimeout(function () { revealPlayer(wrap); }, rDelay);
            }
          } else if (state === 0) {
            resetPlayer(wrap);
          }
        });
      });

      document.querySelectorAll('[data-maps-photo-open]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          var src = btn.getAttribute('data-maps-photo-open');
          var title = btn.getAttribute('data-maps-photo-title') || '';
          if (!src) return;
          var overlay = document.createElement('div');
          overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(2,6,23,0.82);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;padding:16px;';
          var box = document.createElement('div');
          box.style.cssText = 'position:relative;max-width:512px;width:100%;border-radius:16px;overflow:hidden;background:#0F172A;box-shadow:0 24px 48px rgba(0,0,0,0.45);';
          var closeBtn = document.createElement('button');
          closeBtn.type = 'button';
          closeBtn.textContent = '✕';
          closeBtn.setAttribute('aria-label', 'Tutup foto');
          closeBtn.style.cssText = 'position:absolute;top:12px;right:12px;z-index:10;width:32px;height:32px;border-radius:9999px;border:0;background:rgba(15,23,42,0.85);color:#FFFFFF;font-size:14px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;';
          var img = document.createElement('img');
          img.src = src;
          img.alt = title || 'Foto Lokasi';
          img.referrerPolicy = 'no-referrer';
          img.style.cssText = 'width:100%;max-height:75vh;object-fit:contain;display:block;';
          box.appendChild(closeBtn);
          box.appendChild(img);
          if (title) {
            var cap = document.createElement('div');
            cap.textContent = title;
            cap.style.cssText = 'padding:10px 16px;background:#0F172A;color:#FFFFFF;font-size:12px;font-weight:600;';
            box.appendChild(cap);
          }
          overlay.appendChild(box);
          function close() { if (overlay.parentNode) overlay.parentNode.removeChild(overlay); }
          overlay.addEventListener('click', close);
          box.addEventListener('click', function (ev) { ev.stopPropagation(); });
          closeBtn.addEventListener('click', close);
          document.body.appendChild(overlay);
        });
      });

      document.querySelectorAll('[data-toggle-box]').forEach(function (box) {
        var btn = box.querySelector('[data-toggle-btn]');
        var panel = box.querySelector('[data-toggle-panel]');
        var labelEl = box.querySelector('[data-toggle-label]');
        var chevronEl = box.querySelector('[data-toggle-chevron]');
        if (!btn || !panel) return;
        btn.addEventListener('click', function () {
          var isOpen = panel.style.display !== 'none';
          var nextOpen = !isOpen;
          panel.style.display = nextOpen ? 'block' : 'none';
          btn.setAttribute('aria-expanded', nextOpen ? 'true' : 'false');
          if (labelEl) {
            var nextText = nextOpen
              ? btn.getAttribute('data-hide-label')
              : btn.getAttribute('data-show-label');
            if (nextText) labelEl.textContent = nextText;
          }
          if (chevronEl) {
            chevronEl.style.transform = nextOpen ? 'rotate(180deg)' : 'rotate(0deg)';
          }
        });
      });

      var sheetNodes = document.querySelectorAll('[data-bottom-sheet]');
      sheetNodes.forEach(function (sheet) {
        if (sheet.parentNode !== document.body) {
          document.body.appendChild(sheet);
        }
        var panel = sheet.querySelector('.lynk-sheet-panel');
        var closeBtn = sheet.querySelector('[data-sheet-close]');
        function closeSheet() {
          sheet.classList.remove('is-open');
          if (!document.querySelector('[data-bottom-sheet].is-open')) {
            document.body.style.overflow = '';
          }
        }
        sheet.addEventListener('click', closeSheet);
        if (panel) {
          panel.addEventListener('click', function (ev) { ev.stopPropagation(); });
        }
        if (closeBtn) {
          closeBtn.addEventListener('click', closeSheet);
        }
      });
      function closeAllBottomSheets() {
        document.querySelectorAll('[data-bottom-sheet].is-open').forEach(function (openSheet) {
          openSheet.classList.remove('is-open');
        });
        document.body.style.overflow = '';
      }
      document.querySelectorAll('[data-sheet-open]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          var targetId = btn.getAttribute('data-sheet-open');
          var sheet = targetId ? document.getElementById(targetId) : null;
          if (!sheet) return;
          var wasOpen = sheet.classList.contains('is-open');
          closeAllBottomSheets();
          if (!wasOpen) {
            sheet.classList.add('is-open');
            document.body.style.overflow = 'hidden';
          }
        });
      });
      document.querySelectorAll('[data-nav-home]').forEach(function (homeBtn) {
        homeBtn.addEventListener('click', function (e) {
          e.stopPropagation();
          closeAllBottomSheets();
          if (typeof window.__lynkGoHome === 'function') {
            window.__lynkGoHome();
            return;
          }
          window.scrollTo({ top: 0, behavior: 'smooth' });
        });
      });
      document.addEventListener('keydown', function (ev) {
        if (ev.key === 'Escape') {
          closeAllBottomSheets();
        }
      });

      // Sub-Page Detail Produk & Keranjang Pesan via WhatsApp
      var storeEl = document.getElementById('lynk-store-data');
      var mainView = document.getElementById('lynk-main-view');
      var detailView = document.getElementById('lynk-subpage-detail');
      var cartView = document.getElementById('lynk-subpage-cart');
      var cartBar = document.getElementById('lynk-cart-bar');
      var cartBarCount = document.getElementById('lynk-cart-bar-count');
      var cartBarTotal = document.getElementById('lynk-cart-bar-total');
      var openCartBtn = document.getElementById('lynk-open-cart-btn');
      var toastEl = document.getElementById('lynk-toast');

      if (storeEl && mainView && detailView && cartView) {
        var storeData = null;
        try { storeData = JSON.parse(storeEl.textContent || '{}'); } catch (e) { storeData = null; }
        if (storeData && storeData.catalogs) {
          var catalogs = storeData.catalogs;
          var theme = storeData.theme || {};
          var cart = [];
          var customer = {
            name: '',
            phone: '',
            address: '',
            notes: '',
            shippingMethod: 'makan_ditempat',
            arrivalTime: '',
            guestCount: '',
            checklistConfirmed: false
          };
          var shippingOptions = [
            {
              id: 'makan_ditempat',
              enabled: true,
              label: 'Makan di tempat',
              askArrivalTime: true,
              arrivalTimeLabel: 'Waktu Kedatangan',
              arrivalTimePlaceholder: 'Contoh: 18:30 WIB',
              askGuestCount: true,
              guestCountLabel: 'Jumlah Orang',
              guestCountPlaceholder: 'Contoh: 4 orang',
              checklistEnabled: false,
              checklistText: '',
              noteTitle: 'Catatan:',
              noteText: 'Durasi masak ± 30 menit'
            },
            {
              id: 'ambil_sendiri',
              enabled: true,
              label: 'Ambil sendiri ke lokasi',
              askArrivalTime: true,
              arrivalTimeLabel: 'Diambil Jam Berapa',
              arrivalTimePlaceholder: 'Contoh: 17:00 WIB',
              askGuestCount: false,
              guestCountLabel: 'Jumlah Orang',
              guestCountPlaceholder: 'Contoh: 2 orang',
              checklistEnabled: false,
              checklistText: '',
              noteTitle: 'Catatan:',
              noteText: 'Durasi masak ± 30 menit'
            },
            {
              id: 'kurir_sendiri',
              enabled: true,
              label: 'Pesan kurir sendiri',
              askArrivalTime: false,
              arrivalTimeLabel: 'Waktu Pengiriman',
              arrivalTimePlaceholder: 'Contoh: 18:00 WIB',
              askGuestCount: false,
              guestCountLabel: 'Jumlah Orang',
              guestCountPlaceholder: 'Contoh: 1 orang',
              checklistEnabled: true,
              checklistText: 'Pesan kurir setelah pembayaran dan makanan telah siap',
              noteTitle: 'Catatan Penting:',
              noteText: 'Biaya makanan / pesanan tidak termasuk biaya kirim (kurir).'
            },
            {
              id: 'gosend_penjual',
              enabled: true,
              label: 'Dikirim Via Gosend Oleh Penjual',
              askArrivalTime: false,
              arrivalTimeLabel: 'Waktu Pengiriman',
              arrivalTimePlaceholder: 'Contoh: 18:00 WIB',
              askGuestCount: false,
              guestCountLabel: 'Jumlah Orang',
              guestCountPlaceholder: 'Contoh: 1 orang',
              checklistEnabled: true,
              checklistText: 'Penjual akan pesan kurir setelah pembayaran dan makanan telah siap dan mengirimkan tracking pengiriman via WA',
              noteTitle: 'Catatan Penting:',
              noteText: 'Biaya makanan / pesanan tidak termasuk biaya kirim (kurir).'
            }
          ];
          function getEnabledShipOptions(cfgObj) {
            var list = (cfgObj && cfgObj.shippingOptions && cfgObj.shippingOptions.length)
              ? cfgObj.shippingOptions
              : shippingOptions;
            return list.filter(function (o) { return o && o.enabled !== false; });
          }
          var activeRoute = { type: 'home', blockId: '', itemId: '' };
          var toastTimer = null;

          function resolveProductType(cfg, item) {
            if (item && (item.productType === 'physical' || item.productType === 'service')) {
              return item.productType;
            }
            return (cfg && cfg.productType === 'service') ? 'service' : 'physical';
          }
          function collectPickupNotes(items) {
            var seen = {};
            var res = [];
            function pushNote(raw) {
              var s = String(raw || '').trim();
              if (!s || seen[s]) return;
              seen[s] = true;
              res.push(s);
            }
            items.forEach(function (it) { pushNote(it.pickupNote); });
            return res;
          }
          function esc(v) {
            return String(v == null ? '' : v)
              .replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;')
              .replace(/"/g, '&quot;');
          }
          function safeHref(raw, fallback) {
            var fb = fallback || '#';
            var s = String(raw || '').trim();
            if (!s) return fb;
            var compact = s.replace(/[\u0000-\u001F\u007F\s]+/g, '');
            if (/^(javascript|vbscript|data):/i.test(compact)) return fb;
            if (/^(https?:|mailto:|tel:|sms:|whatsapp:|\/|#)/i.test(s)) return s;
            if (s.indexOf('//') === 0) return 'https:' + s;
            if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(s) && s.indexOf('.') !== -1) return 'https://' + s;
            return fb;
          }
          function parsePrice(str) {
            if (!str) return 0;
            var cleaned = String(str).trim().replace(/,\d{1,2}$/, '');
            var digits = cleaned.replace(/[^\d]/g, '');
            var num = Number(digits);
            return digits && isFinite(num) ? num : 0;
          }
          function formatRp(num) {
            return 'Rp ' + Math.max(0, Math.round(num)).toLocaleString('id-ID');
          }
          function parseVars(vStr) {
            if (!vStr) return [];
            return String(vStr).split(',').map(function (s) { return s.trim(); }).filter(Boolean);
          }
          function normalizeWa(raw) {
            var d = String(raw || '').replace(/[^\d]/g, '');
            if (!d) return '6281234567890';
            if (d.charAt(0) === '0') return '62' + d.slice(1);
            if (d.charAt(0) === '8') return '62' + d;
            return d;
          }
          function buildWaUrl(cfg, items, cust) {
            var phone = normalizeWa(cfg && cfg.whatsappNumber);
            var sName = ((cfg && cfg.storeName) || storeData.projectTitle || '').trim();
            var intro = ((cfg && cfg.whatsappIntro) || '').trim() || 'Halo, saya ingin memesan produk berikut:';
            var lines = [];
            if (sName) lines.push('*' + sName + '*');
            lines.push(intro);
            lines.push('');
            var total = 0;
            var hasNum = false;
            items.forEach(function (it, idx) {
              var vText = it.variant ? ' (' + it.variant + ')' : '';
              var sub = it.unitPrice * it.qty;
              if (it.unitPrice > 0) {
                hasNum = true;
                total += sub;
                lines.push((idx + 1) + '. ' + it.title + vText + ' x' + it.qty + ' — ' + formatRp(sub));
              } else {
                lines.push((idx + 1) + '. ' + it.title + vText + ' x' + it.qty + (it.priceText ? ' (' + it.priceText + ')' : ''));
              }
            });
            if (hasNum) {
              lines.push('');
              lines.push('*Total Pesanan: ' + formatRp(total) + '*');
            }
            var hasPhysical = items.some(function (it) { return it.productType !== 'service'; });
            if (cust) {
              var cLines = [];
              if (cust.name && cust.name.trim()) cLines.push('Nama: ' + cust.name.trim());
              if (cust.phone && cust.phone.trim()) cLines.push('No. WA: ' + cust.phone.trim());
              if (cust.address && cust.address.trim()) cLines.push('Alamat: ' + cust.address.trim());
              if (cust.notes && cust.notes.trim()) cLines.push('Catatan: ' + cust.notes.trim());
              var selectedLabel = '';
              if (hasPhysical && cust.shippingMethod) {
                var displayTitle = (cust.shippingOptionLabel && cust.shippingOptionLabel.trim()) || '';
                var displayNum = cust.shippingOptionNumber || 1;
                if (displayTitle) {
                  selectedLabel = displayNum + '. ' + displayTitle;
                  cLines.push('Pilihan: ' + selectedLabel);
                  if (cust.arrivalTime && cust.arrivalTime.trim()) {
                    cLines.push(((cust.arrivalTimeLabel && cust.arrivalTimeLabel.trim()) || 'Waktu') + ': ' + cust.arrivalTime.trim());
                  }
                  if (cust.guestCount && cust.guestCount.trim()) {
                    cLines.push(((cust.guestCountLabel && cust.guestCountLabel.trim()) || 'Jumlah Orang') + ': ' + cust.guestCount.trim());
                  }
                  if (cust.checklistConfirmed && cust.checklistText && cust.checklistText.trim()) {
                    cLines.push('Konfirmasi: [✓] ' + cust.checklistText.trim());
                  }
                  if (cust.pickupNote && cust.pickupNote.trim()) {
                    cLines.push('Info Produk: ' + cust.pickupNote.trim());
                  }
                  if (cust.shippingNote && cust.shippingNote.trim()) {
                    var nHead = ((cust.shippingNoteTitle && cust.shippingNoteTitle.trim()) || 'Catatan:').replace(/:+$/, '');
                    cLines.push(nHead + ': ' + cust.shippingNote.trim());
                  }
                }
              }
              if (cLines.length) {
                lines.push('');
                lines.push(selectedLabel ? '*Data Pemesan & Pilihan:*' : '*Data Pemesan:*');
                cLines.forEach(function (cl) { lines.push(cl); });
              }
            }
            return 'https://wa.me/' + phone + '?text=' + encodeURIComponent(lines.join('\n'));
          }
          function showToast(msg) {
            if (!toastEl) return;
            toastEl.textContent = msg;
            toastEl.style.display = 'block';
            if (toastTimer) clearTimeout(toastTimer);
            toastTimer = setTimeout(function () { toastEl.style.display = 'none'; }, 1800);
          }
          function getCartTotals() {
            var count = 0;
            var sum = 0;
            cart.forEach(function (c) {
              count += c.qty;
              sum += c.unitPrice * c.qty;
            });
            return { count: count, sum: sum };
          }
          function syncCartBar() {
            if (!cartBar) return;
            var totals = getCartTotals();
            var showBar = totals.count > 0 && activeRoute.type !== 'cart';
            cartBar.style.display = showBar ? 'block' : 'none';
            if (cartBarCount) cartBarCount.textContent = totals.count + ' item di keranjang';
            if (cartBarTotal) cartBarTotal.textContent = totals.sum > 0 ? formatRp(totals.sum) : 'Siap pesan via WA';
            document.body.style.paddingBottom = showBar ? '84px' : '24px';
            var waFloatBtn = document.getElementById('lynk-wa-addon-btn');
            if (waFloatBtn) waFloatBtn.style.bottom = showBar ? '76px' : '18px';
          }
          function addCartItem(blockId, item, variant, qty) {
            var cfg = catalogs[blockId];
            var v = variant || '';
            var key = blockId + '::' + item.id + '::' + v;
            var q = Math.max(1, qty || 1);
            var existing = null;
            for (var i = 0; i < cart.length; i++) {
              if (cart[i].key === key) { existing = cart[i]; break; }
            }
            if (existing) {
              existing.qty += q;
            } else {
              cart.push({
                key: key,
                blockId: blockId,
                itemId: item.id,
                title: item.title,
                priceText: item.price,
                unitPrice: parsePrice(item.price),
                image: item.image,
                variant: v,
                qty: q,
                productType: resolveProductType(cfg, item),
                pickupNote: (item && item.pickupNote ? String(item.pickupNote).trim() : '')
              });
            }
            syncCartBar();
            showToast('"' + item.title + '" masuk ke keranjang');
          }
          function findItem(blockId, itemId) {
            var cfg = catalogs[blockId];
            if (!cfg || !cfg.items) return null;
            for (var i = 0; i < cfg.items.length; i++) {
              if (cfg.items[i].id === itemId) return { cfg: cfg, item: cfg.items[i] };
            }
            return null;
          }
          function getFirstCatalogCfg() {
            if (cart.length && catalogs[cart[0].blockId]) return catalogs[cart[0].blockId];
            var keys = Object.keys(catalogs);
            return keys.length ? catalogs[keys[0]] : null;
          }
          function renderDetailPage(blockId, itemId) {
            var found = findItem(blockId, itemId);
            if (!found) { goHome(); return; }
            var cfg = found.cfg;
            var item = found.item;
            var variants = parseVars(item.variants);
            var selectedVar = variants.length ? variants[0] : '';
            var qty = 1;
            var photos = [item.image].concat(Array.isArray(item.gallery) ? item.gallery : []).filter(Boolean);
            var activePhoto = 0;
            var totals = getCartTotals();

            var thumbsHtml = photos.length > 1
              ? '<div style="padding:10px; display:flex; gap:8px; overflow-x:auto; border-top:1px solid ' + esc(theme.borderColor) + ';">' +
                  photos.map(function (src, idx) {
                    return '<button type="button" data-det-thumb="' + idx + '" style="width:54px; height:54px; padding:0; border-radius:8px; overflow:hidden; border:2px solid ' + (idx === 0 ? esc(theme.accentColor) : esc(theme.borderColor)) + '; cursor:pointer; flex-shrink:0;"><img src="' + esc(src) + '" alt="" style="width:100%; height:100%; object-fit:cover; display:block;" /></button>';
                  }).join('') +
                '</div>'
              : '';

            var varsHtml = variants.length
              ? '<div style="padding-top:12px; border-top:1px solid ' + esc(theme.borderColor) + ';"><div style="font-size:12px; font-weight:600; opacity:0.8; margin-bottom:8px;">Pilih Varian:</div><div style="display:flex; flex-wrap:wrap; gap:6px;">' +
                  variants.map(function (v, idx) {
                    var on = idx === 0;
                    return '<button type="button" data-det-var="' + esc(v) + '" style="padding:6px 12px; border-radius:8px; font-size:12px; font-weight:600; cursor:pointer; border:1px solid ' + (on ? esc(theme.accentColor) : esc(theme.borderColor)) + '; background:' + (on ? esc(theme.accentColor) : 'transparent') + '; color:' + (on ? '#FFFFFF' : esc(theme.textColor)) + ';">' + esc(v) + '</button>';
                  }).join('') +
                '</div></div>'
              : '';

            var safeItemUrl = safeHref(item.url, '');
            var hasCustomUrl = Boolean(safeItemUrl) && item.url.indexOf('https://example.com') !== 0;
            var soldHtml = storeData.showUnitSold ? '<span style="font-size:12px; opacity:0.65;"> · ' + esc(item.unitSold) + ' terjual</span>' : '';

            detailView.innerHTML =
              '<div style="display:flex; flex-direction:column; gap:14px;">' +
                '<div style="display:flex; align-items:center; justify-content:space-between; gap:8px;">' +
                  '<button type="button" data-nav-home style="padding:7px 12px; border-radius:12px; border:1px solid ' + esc(theme.borderColor) + '; background:' + esc(theme.cardBg) + '; color:' + esc(theme.textColor) + '; font-size:12px; font-weight:600; cursor:pointer;">&larr; Kembali</button>' +
                  (cfg.cartEnabled ? '<button type="button" data-nav-cart style="padding:7px 12px; border-radius:12px; border:1px solid ' + esc(theme.borderColor) + '; background:' + esc(theme.cardBg) + '; color:' + esc(theme.textColor) + '; font-size:12px; font-weight:600; cursor:pointer;">Keranjang (<span id="lynk-det-cart-count">' + totals.count + '</span>)</button>' : '') +
                '</div>' +
                '<div style="background:' + esc(theme.cardBg) + '; border:1px solid ' + esc(theme.borderColor) + '; border-radius:16px; overflow:hidden;">' +
                  '<div style="position:relative; background:#F1F5F9;">' +
                    (item.badge && item.badge.trim() ? '<span style="position:absolute; top:12px; left:12px; z-index:2; padding:4px 10px; border-radius:8px; font-size:11px; font-weight:700; color:#FFFFFF; background:' + esc(theme.accentColor) + ';">' + esc(item.badge.trim()) + '</span>' : '') +
                    '<img id="lynk-det-main-img" src="' + esc(photos[0] || item.image) + '" alt="' + esc(item.title) + '" style="width:100%; aspect-ratio:4/3; object-fit:cover; display:block;" />' +
                  '</div>' +
                  thumbsHtml +
                '</div>' +
                '<div style="background:' + esc(theme.cardBg) + '; border:1px solid ' + esc(theme.borderColor) + '; border-radius:16px; padding:16px; display:flex; flex-direction:column; gap:12px;">' +
                  '<div>' +
                    '<h1 style="margin:0; font-size:18px; font-weight:700; line-height:1.35;">' + esc(item.title) + '</h1>' +
                    (item.subtitle ? '<p style="margin:4px 0 0; font-size:12px; opacity:0.75;">' + esc(item.subtitle) + '</p>' : '') +
                    '<div style="margin-top:8px; display:flex; align-items:baseline; gap:8px;">' +
                      '<span style="font-size:18px; font-weight:700; color:' + esc(theme.accentColor) + ';">' + esc(item.price) + '</span>' +
                      soldHtml +
                    '</div>' +
                  '</div>' +
                  varsHtml +
                  (cfg.cartEnabled
                    ? '<div style="display:flex; align-items:center; justify-content:space-between; padding-top:12px; border-top:1px solid ' + esc(theme.borderColor) + ';">' +
                        '<span style="font-size:12px; font-weight:600; opacity:0.8;">Jumlah</span>' +
                        '<div style="display:inline-flex; align-items:center; gap:8px;">' +
                          '<button type="button" id="lynk-det-minus" style="width:32px; height:32px; border-radius:8px; border:1px solid ' + esc(theme.borderColor) + '; background:transparent; color:' + esc(theme.textColor) + '; font-size:14px; font-weight:700; cursor:pointer;">-</button>' +
                          '<span id="lynk-det-qty" style="min-width:24px; text-align:center; font-size:14px; font-weight:700;">1</span>' +
                          '<button type="button" id="lynk-det-plus" style="width:32px; height:32px; border-radius:8px; border:1px solid ' + esc(theme.borderColor) + '; background:transparent; color:' + esc(theme.textColor) + '; font-size:14px; font-weight:700; cursor:pointer;">+</button>' +
                        '</div>' +
                      '</div>'
                    : '') +
                  (item.description && item.description.trim()
                    ? '<div style="padding-top:12px; border-top:1px solid ' + esc(theme.borderColor) + ';"><div style="font-size:12px; font-weight:600; opacity:0.8; margin-bottom:4px;">Deskripsi Produk</div><div style="font-size:13px; line-height:1.6; opacity:0.9; white-space:pre-line;">' + esc(item.description) + '</div></div>'
                    : '') +
                  '<div style="padding-top:8px; display:flex; flex-direction:column; gap:8px;">' +
                    (cfg.cartEnabled
                      ? '<button type="button" id="lynk-det-add" style="width:100%; padding:11px 16px; border:0; border-radius:12px; background:' + esc(theme.accentColor) + '; color:#FFFFFF; font-size:13px; font-weight:700; cursor:pointer;">Tambah ke Keranjang</button>' +
                        '<a id="lynk-det-wa" href="#" target="_blank" rel="noopener noreferrer" style="width:100%; box-sizing:border-box; padding:11px 16px; border-radius:12px; background:#059669; color:#FFFFFF; font-size:13px; font-weight:700; text-align:center; text-decoration:none;">Pesan Langsung via WhatsApp</a>'
                      : '') +
                    (hasCustomUrl
                      ? '<a href="' + esc(safeItemUrl) + '" target="_blank" rel="noopener noreferrer" style="width:100%; box-sizing:border-box; padding:10px 16px; border-radius:12px; border:1px solid ' + esc(theme.borderColor) + '; color:' + esc(theme.textColor) + '; font-size:12px; font-weight:600; text-align:center; text-decoration:none;">' + esc(cfg.cartEnabled ? 'Kunjungi Tautan Produk' : (item.ctaLabel || 'Buka Tautan')) + '</a>'
                      : '') +
                  '</div>' +
                '</div>' +
              '</div>';

            function syncDirectWa() {
              var waLink = document.getElementById('lynk-det-wa');
              if (!waLink) return;
              waLink.href = buildWaUrl(cfg, [{
                title: item.title,
                priceText: item.price,
                unitPrice: parsePrice(item.price),
                variant: selectedVar,
                qty: qty,
                productType: resolveProductType(cfg, item)
              }], null);
            }
            syncDirectWa();

            detailView.querySelector('[data-nav-home]').addEventListener('click', goHome);
            var navCart = detailView.querySelector('[data-nav-cart]');
            if (navCart) navCart.addEventListener('click', openCart);

            detailView.querySelectorAll('[data-det-thumb]').forEach(function (tBtn) {
              tBtn.addEventListener('click', function () {
                activePhoto = Number(tBtn.getAttribute('data-det-thumb') || 0);
                var mainImg = document.getElementById('lynk-det-main-img');
                if (mainImg && photos[activePhoto]) mainImg.src = photos[activePhoto];
                detailView.querySelectorAll('[data-det-thumb]').forEach(function (b, idx) {
                  b.style.borderColor = idx === activePhoto ? (theme.accentColor || '#2563EB') : (theme.borderColor || '#E2E8F0');
                });
              });
            });

            detailView.querySelectorAll('[data-det-var]').forEach(function (vBtn) {
              vBtn.addEventListener('click', function () {
                selectedVar = vBtn.getAttribute('data-det-var') || '';
                detailView.querySelectorAll('[data-det-var]').forEach(function (b) {
                  var on = (b.getAttribute('data-det-var') || '') === selectedVar;
                  b.style.background = on ? (theme.accentColor || '#2563EB') : 'transparent';
                  b.style.borderColor = on ? (theme.accentColor || '#2563EB') : (theme.borderColor || '#E2E8F0');
                  b.style.color = on ? '#FFFFFF' : (theme.textColor || '#0F172A');
                });
                syncDirectWa();
              });
            });

            var minusBtn = document.getElementById('lynk-det-minus');
            var plusBtn = document.getElementById('lynk-det-plus');
            var qtyEl = document.getElementById('lynk-det-qty');
            if (minusBtn && qtyEl) {
              minusBtn.addEventListener('click', function () {
                qty = Math.max(1, qty - 1);
                qtyEl.textContent = String(qty);
                syncDirectWa();
              });
            }
            if (plusBtn && qtyEl) {
              plusBtn.addEventListener('click', function () {
                qty += 1;
                qtyEl.textContent = String(qty);
                syncDirectWa();
              });
            }
            var addBtn = document.getElementById('lynk-det-add');
            if (addBtn) {
              addBtn.addEventListener('click', function () {
                addCartItem(blockId, item, selectedVar, qty);
                var cBadge = document.getElementById('lynk-det-cart-count');
                if (cBadge) cBadge.textContent = String(getCartTotals().count);
              });
            }
          }

          function renderCartPage() {
            var cfg = getFirstCatalogCfg() || { whatsappNumber: '6281234567890', storeName: storeData.projectTitle, whatsappIntro: '', askCustomerInfo: true };
            var totals = getCartTotals();

            if (!cart.length) {
              cartView.innerHTML =
                '<div style="display:flex; flex-direction:column; gap:14px;">' +
                  '<div><button type="button" data-nav-home style="padding:7px 12px; border-radius:12px; border:1px solid ' + esc(theme.borderColor) + '; background:' + esc(theme.cardBg) + '; color:' + esc(theme.textColor) + '; font-size:12px; font-weight:600; cursor:pointer;">&larr; Kembali</button></div>' +
                  '<div style="background:' + esc(theme.cardBg) + '; border:1px solid ' + esc(theme.borderColor) + '; border-radius:16px; padding:32px 20px; text-align:center;">' +
                    '<div style="font-size:15px; font-weight:700; margin-bottom:6px;">Keranjang masih kosong</div>' +
                    '<p style="margin:0 0 16px; font-size:12px; opacity:0.7;">Pilih produk dari katalog terlebih dahulu untuk memesan via WhatsApp.</p>' +
                    '<button type="button" data-nav-home style="padding:9px 16px; border:0; border-radius:12px; background:' + esc(theme.accentColor) + '; color:#FFFFFF; font-size:12px; font-weight:600; cursor:pointer;">Lihat Katalog Produk</button>' +
                  '</div>' +
                '</div>';
              cartView.querySelectorAll('[data-nav-home]').forEach(function (b) { b.addEventListener('click', goHome); });
              return;
            }

            var itemsHtml = cart.map(function (entry) {
              var linePrice = entry.unitPrice > 0 ? formatRp(entry.unitPrice * entry.qty) : entry.priceText;
              return (
                '<div style="padding:12px; display:flex; align-items:flex-start; gap:12px; border-bottom:1px solid ' + esc(theme.borderColor) + ';">' +
                  '<img src="' + esc(entry.image) + '" alt="' + esc(entry.title) + '" style="width:56px; height:56px; border-radius:12px; object-fit:cover; background:#F1F5F9; flex-shrink:0;" />' +
                  '<div style="min-width:0; flex:1;">' +
                    '<div style="display:flex; justify-content:space-between; align-items:flex-start; gap:8px;">' +
                      '<div style="min-width:0;">' +
                        '<div style="font-size:13px; font-weight:700;">' + esc(entry.title) + '</div>' +
                        (entry.variant ? '<div style="font-size:11px; opacity:0.7;">Varian: ' + esc(entry.variant) + '</div>' : '') +
                      '</div>' +
                      '<button type="button" data-cart-del="' + esc(entry.key) + '" aria-label="Hapus item" style="border:0; background:transparent; color:#94A3B8; font-size:14px; font-weight:700; cursor:pointer; padding:2px 6px;">✕</button>' +
                    '</div>' +
                    '<div style="display:flex; justify-content:space-between; align-items:center; gap:8px; margin-top:8px;">' +
                      '<div style="font-size:13px; font-weight:700; color:' + esc(theme.accentColor) + ';">' + esc(linePrice) + '</div>' +
                      '<div style="display:inline-flex; align-items:center; gap:6px;">' +
                        '<button type="button" data-cart-dec="' + esc(entry.key) + '" style="width:26px; height:26px; border-radius:6px; border:1px solid ' + esc(theme.borderColor) + '; background:transparent; color:' + esc(theme.textColor) + '; font-weight:700; cursor:pointer;">-</button>' +
                        '<span style="min-width:20px; text-align:center; font-size:12px; font-weight:700;">' + entry.qty + '</span>' +
                        '<button type="button" data-cart-inc="' + esc(entry.key) + '" style="width:26px; height:26px; border-radius:6px; border:1px solid ' + esc(theme.borderColor) + '; background:transparent; color:' + esc(theme.textColor) + '; font-weight:700; cursor:pointer;">+</button>' +
                      '</div>' +
                    '</div>' +
                  '</div>' +
                '</div>'
              );
            }).join('');

            var hasPhysical = cart.some(function (c) { return c.productType !== 'service'; });
            var enabledOpts = getEnabledShipOptions(cfg);
            var showChoices = cfg.shippingEnabled !== false && hasPhysical && enabledOpts.length > 0;
            var selIdx = -1;
            for (var ei = 0; ei < enabledOpts.length; ei++) {
              if (enabledOpts[ei].id === (customer.shippingMethod || 'makan_ditempat')) { selIdx = ei; break; }
            }
            if (selIdx < 0) selIdx = 0;
            var activeOpt = enabledOpts[selIdx] || null;
            var pickupNoteText = collectPickupNotes(cart).join('; ');

            var inputStyle = 'width:100%; box-sizing:border-box; padding:9px 12px; border-radius:12px; border:1px solid ' + esc(theme.borderColor) + '; background:transparent; color:' + esc(theme.textColor) + '; font-size:12px; font-family:inherit; outline:none;';
            var addrPlaceholder = !hasPhysical
              ? 'Alamat / Lokasi'
              : (showChoices && (customer.shippingMethod === 'makan_ditempat' || customer.shippingMethod === 'ambil_sendiri')
                  ? 'Alamat (opsional)'
                  : 'Alamat lengkap pengiriman / patokan lokasi');
            var customerFormHtml = cfg.askCustomerInfo !== false
              ? '<div style="background:' + esc(theme.cardBg) + '; border:1px solid ' + esc(theme.borderColor) + '; border-radius:16px; padding:16px; display:flex; flex-direction:column; gap:10px;">' +
                  '<div style="font-size:13px; font-weight:700;">Data Pemesan</div>' +
                  '<input id="lynk-cust-name" type="text" placeholder="Nama lengkap" value="' + esc(customer.name) + '" style="' + inputStyle + '" />' +
                  '<input id="lynk-cust-phone" type="tel" placeholder="No. HP / WhatsApp (opsional)" value="' + esc(customer.phone) + '" style="' + inputStyle + '" />' +
                  '<textarea id="lynk-cust-addr" rows="2" placeholder="' + addrPlaceholder + '" style="' + inputStyle + ' resize:vertical;">' + esc(customer.address) + '</textarea>' +
                  '<input id="lynk-cust-notes" type="text" placeholder="Catatan pesanan (opsional)" value="' + esc(customer.notes) + '" style="' + inputStyle + '" />' +
                '</div>'
              : '';

            var fieldInputStyle = 'width:100%; box-sizing:border-box; padding:7px 10px; border-radius:8px; border:1px solid ' + esc(theme.borderColor) + '; background:' + esc(theme.cardBg) + '; color:' + esc(theme.textColor) + '; font-size:12px; font-family:inherit; outline:none;';
            var shipCardsHtml = enabledOpts.map(function (opt, idx) {
              var on = activeOpt && activeOpt.id === opt.id;
              var subFieldsHtml = '';
              if (on) {
                var inputsParts = [];
                if (opt.askArrivalTime) {
                  inputsParts.push(
                    '<div style="flex:1; min-width:0;">' +
                      '<label style="display:block; font-size:11px; font-weight:600; opacity:0.8; margin-bottom:4px;">' + esc(opt.arrivalTimeLabel || 'Waktu') + '</label>' +
                      '<input id="lynk-ship-time" type="text" value="' + esc(customer.arrivalTime) + '" placeholder="' + esc(opt.arrivalTimePlaceholder || 'Contoh: 18:30 WIB') + '" style="' + fieldInputStyle + '" />' +
                    '</div>'
                  );
                }
                if (opt.askGuestCount) {
                  inputsParts.push(
                    '<div style="flex:1; min-width:0;">' +
                      '<label style="display:block; font-size:11px; font-weight:600; opacity:0.8; margin-bottom:4px;">' + esc(opt.guestCountLabel || 'Jumlah Orang') + '</label>' +
                      '<input id="lynk-ship-guests" type="text" value="' + esc(customer.guestCount) + '" placeholder="' + esc(opt.guestCountPlaceholder || 'Contoh: 4 orang') + '" style="' + fieldInputStyle + '" />' +
                    '</div>'
                  );
                }
                var gridInputsHtml = inputsParts.length
                  ? '<div style="display:flex; gap:8px;">' + inputsParts.join('') + '</div>'
                  : '';
                var checkHtml = (opt.checklistEnabled && opt.checklistText && opt.checklistText.trim())
                  ? '<label style="display:flex; align-items:flex-start; gap:8px; padding:8px 10px; border-radius:8px; border:1px solid ' + (customer.checklistConfirmed ? '#10B981' : esc(theme.borderColor)) + '; background:' + esc(theme.cardBg) + '; cursor:pointer;">' +
                      '<input id="lynk-ship-check" type="checkbox" ' + (customer.checklistConfirmed ? 'checked' : '') + ' style="margin-top:2px; cursor:pointer; accent-color:#059669;" />' +
                      '<span style="font-size:11px; font-weight:500; line-height:1.45;">' + esc(opt.checklistText.trim()) + '</span>' +
                    '</label>'
                  : '';
                var pickupItemHtml = (opt.id === 'ambil_sendiri' && pickupNoteText)
                  ? '<div style="font-size:11px; font-weight:600; color:#78350F; background:#FFFBEB; border:1px solid #FDE68A; border-radius:8px; padding:6px 10px; line-height:1.4;">Info Produk: ' + esc(pickupNoteText) + '</div>'
                  : '';
                if (gridInputsHtml || checkHtml || pickupItemHtml) {
                  subFieldsHtml = '<div style="padding:0 12px 12px 12px; display:flex; flex-direction:column; gap:8px;">' + gridInputsHtml + checkHtml + pickupItemHtml + '</div>';
                }
              }
              return (
                '<div style="border-radius:12px; border:1px solid ' + (on ? esc(theme.accentColor) : esc(theme.borderColor)) + '; background:' + (on ? esc(theme.accentColor) + '14' : 'transparent') + '; overflow:hidden;">' +
                  '<label data-ship-opt="' + esc(opt.id) + '" style="display:flex; align-items:flex-start; gap:10px; padding:10px 12px; cursor:pointer;">' +
                    '<input type="radio" name="lynk_ship" ' + (on ? 'checked' : '') + ' style="margin-top:2px; cursor:pointer;" />' +
                    '<div style="min-width:0; flex:1; font-size:12px; font-weight:600; line-height:1.35;">' + (idx + 1) + '. ' + esc(opt.label) + '</div>' +
                  '</label>' +
                  subFieldsHtml +
                '</div>'
              );
            }).join('');

            var activeNoteBoxHtml = (activeOpt && activeOpt.noteText && activeOpt.noteText.trim())
              ? '<div style="border-radius:12px; background:#FFFBEB; border:2px solid #FCD34D; padding:12px 14px; color:#451A03;">' +
                  '<div style="font-size:12px; font-weight:700; margin-bottom:4px; color:#78350F;">' + esc((activeOpt.noteTitle && activeOpt.noteTitle.trim()) || 'Catatan:') + '</div>' +
                  '<div style="font-size:12px; font-weight:700; line-height:1.5; color:#451A03; white-space:pre-line;">' + esc(activeOpt.noteText.trim()) + '</div>' +
                '</div>'
              : '';

            var shippingSectionHtml = showChoices
              ? '<div style="background:' + esc(theme.cardBg) + '; border:1px solid ' + esc(theme.borderColor) + '; border-radius:16px; padding:16px; display:flex; flex-direction:column; gap:10px;">' +
                  '<div style="font-size:13px; font-weight:700;">Pilihan</div>' +
                  '<div style="display:flex; flex-direction:column; gap:8px;">' + shipCardsHtml + '</div>' +
                  activeNoteBoxHtml +
                '</div>'
              : '';

            function getStoreGroups() {
              var map = {};
              var list = [];
              cart.forEach(function (entry) {
                var cCfg = catalogs[entry.blockId] || cfg;
                var norm = normalizeWa(cCfg && cCfg.whatsappNumber);
                if (!map[norm]) {
                  map[norm] = {
                    phone: norm,
                    cfg: cCfg,
                    storeName: ((cCfg && cCfg.storeName) || storeData.projectTitle || 'Toko').trim(),
                    entries: []
                  };
                  list.push(map[norm]);
                }
                map[norm].entries.push(entry);
              });
              return list;
            }

            var storeGroups = getStoreGroups();
            var waSectionHtml = storeGroups.length <= 1
              ? '<a id="lynk-cart-wa-btn" href="#" target="_blank" rel="noopener noreferrer" style="width:100%; box-sizing:border-box; padding:12px 16px; border-radius:12px; background:#059669; color:#FFFFFF; font-size:13px; font-weight:700; text-align:center; text-decoration:none;">Kirim Pesanan via WhatsApp</a>'
              : '<div style="display:flex; flex-direction:column; gap:8px; padding-top:4px;">' +
                  '<div style="font-size:11px; font-weight:600; color:#92400E; background:#FFFBEB; border:1px solid #FDE68A; border-radius:8px; padding:8px 10px; line-height:1.4;">Keranjang berisi produk dari ' + storeGroups.length + ' nomor WhatsApp berbeda. Kirim pesanan per toko di bawah ini:</div>' +
                  storeGroups.map(function (grp, gi) {
                    var cnt = grp.entries.reduce(function (s, e) { return s + e.qty; }, 0);
                    return '<a data-cart-wa-grp="' + gi + '" href="#" target="_blank" rel="noopener noreferrer" style="width:100%; box-sizing:border-box; padding:10px 16px; border-radius:12px; background:#059669; color:#FFFFFF; font-size:12px; font-weight:700; text-align:center; text-decoration:none;">Kirim ke ' + esc(grp.storeName) + ' (' + cnt + ' item)</a>';
                  }).join('') +
                '</div>';

            cartView.innerHTML =
              '<div style="display:flex; flex-direction:column; gap:14px;">' +
                '<div style="display:flex; align-items:center; justify-content:space-between; gap:8px;">' +
                  '<button type="button" data-nav-home style="padding:7px 12px; border-radius:12px; border:1px solid ' + esc(theme.borderColor) + '; background:' + esc(theme.cardBg) + '; color:' + esc(theme.textColor) + '; font-size:12px; font-weight:600; cursor:pointer;">&larr; Kembali</button>' +
                  '<button type="button" id="lynk-cart-clear" style="padding:7px 10px; border:0; border-radius:10px; background:transparent; color:#DC2626; font-size:12px; font-weight:600; cursor:pointer;">Kosongkan</button>' +
                '</div>' +
                '<div style="background:' + esc(theme.cardBg) + '; border:1px solid ' + esc(theme.borderColor) + '; border-radius:16px; overflow:hidden;">' +
                  itemsHtml +
                '</div>' +
                customerFormHtml +
                shippingSectionHtml +
                '<div style="background:' + esc(theme.cardBg) + '; border:1px solid ' + esc(theme.borderColor) + '; border-radius:16px; padding:16px; display:flex; flex-direction:column; gap:10px;">' +
                  '<div style="display:flex; justify-content:space-between; font-size:12px; opacity:0.75;"><span>Total Item</span><span style="font-weight:600;">' + totals.count + ' produk</span></div>' +
                  '<div style="display:flex; justify-content:space-between; align-items:center;"><span style="font-size:13px; font-weight:700;">Total Estimasi</span><span style="font-size:16px; font-weight:700; color:' + esc(theme.accentColor) + ';">' + (totals.sum > 0 ? formatRp(totals.sum) : 'Sesuai konfirmasi WA') + '</span></div>' +
                  waSectionHtml +
                '</div>' +
              '</div>';

            function buildGroupPayload(gCfg, gItems) {
              var gHasPhysical = gItems.some(function (it) { return it.productType !== 'service'; });
              var gOpts = getEnabledShipOptions(gCfg);
              var gShowChoices = gCfg.shippingEnabled !== false && gHasPhysical && gOpts.length > 0;
              var gSelIdx = -1;
              for (var gi = 0; gi < gOpts.length; gi++) {
                if (gOpts[gi].id === (customer.shippingMethod || 'makan_ditempat')) { gSelIdx = gi; break; }
              }
              if (gSelIdx < 0) gSelIdx = 0;
              var gSelOpt = gOpts[gSelIdx] || null;
              var gPickupNote = collectPickupNotes(gItems).join('; ');
              if (gCfg.askCustomerInfo === false && !gShowChoices) return null;
              return {
                name: gCfg.askCustomerInfo !== false ? customer.name : '',
                phone: gCfg.askCustomerInfo !== false ? customer.phone : '',
                address: gCfg.askCustomerInfo !== false ? customer.address : '',
                notes: gCfg.askCustomerInfo !== false ? customer.notes : '',
                shippingMethod: gShowChoices && gSelOpt ? gSelOpt.id : '',
                shippingOptionNumber: gShowChoices && gSelOpt ? (gSelIdx + 1) : 1,
                shippingOptionLabel: gShowChoices && gSelOpt ? gSelOpt.label : '',
                arrivalTimeLabel: gShowChoices && gSelOpt && gSelOpt.askArrivalTime ? (gSelOpt.arrivalTimeLabel || 'Waktu') : '',
                arrivalTime: gShowChoices && gSelOpt && gSelOpt.askArrivalTime ? customer.arrivalTime : '',
                guestCountLabel: gShowChoices && gSelOpt && gSelOpt.askGuestCount ? (gSelOpt.guestCountLabel || 'Jumlah Orang') : '',
                guestCount: gShowChoices && gSelOpt && gSelOpt.askGuestCount ? customer.guestCount : '',
                checklistConfirmed: gShowChoices && gSelOpt && gSelOpt.checklistEnabled ? Boolean(customer.checklistConfirmed) : false,
                checklistText: gShowChoices && gSelOpt && gSelOpt.checklistEnabled ? (gSelOpt.checklistText || '') : '',
                pickupNote: gShowChoices && gSelOpt && gSelOpt.id === 'ambil_sendiri' ? gPickupNote : '',
                shippingNoteTitle: gShowChoices && gSelOpt ? (gSelOpt.noteTitle || 'Catatan:') : '',
                shippingNote: gShowChoices && gSelOpt && gSelOpt.noteText ? gSelOpt.noteText.trim() : ''
              };
            }

            function syncCartWa() {
              var groups = getStoreGroups();
              var singleBtn = document.getElementById('lynk-cart-wa-btn');
              if (singleBtn && groups.length > 0) {
                singleBtn.href = buildWaUrl(groups[0].cfg, groups[0].entries, buildGroupPayload(groups[0].cfg, groups[0].entries));
              }
              cartView.querySelectorAll('[data-cart-wa-grp]').forEach(function (btn) {
                var gi = Number(btn.getAttribute('data-cart-wa-grp'));
                var grp = groups[gi];
                if (grp) {
                  btn.href = buildWaUrl(grp.cfg, grp.entries, buildGroupPayload(grp.cfg, grp.entries));
                }
              });
            }
            syncCartWa();

            cartView.querySelectorAll('[data-nav-home]').forEach(function (b) { b.addEventListener('click', goHome); });
            var clearBtn = document.getElementById('lynk-cart-clear');
            if (clearBtn) clearBtn.addEventListener('click', function () { cart = []; syncCartBar(); renderCartPage(); });

            cartView.querySelectorAll('[data-cart-del]').forEach(function (b) {
              b.addEventListener('click', function () {
                var k = b.getAttribute('data-cart-del');
                cart = cart.filter(function (c) { return c.key !== k; });
                syncCartBar();
                renderCartPage();
              });
            });
            cartView.querySelectorAll('[data-cart-inc]').forEach(function (b) {
              b.addEventListener('click', function () {
                var k = b.getAttribute('data-cart-inc');
                cart.forEach(function (c) { if (c.key === k) c.qty += 1; });
                syncCartBar();
                renderCartPage();
              });
            });
            cartView.querySelectorAll('[data-cart-dec]').forEach(function (b) {
              b.addEventListener('click', function () {
                var k = b.getAttribute('data-cart-dec');
                cart = cart.map(function (c) { return c.key === k ? Object.assign({}, c, { qty: c.qty - 1 }) : c; }).filter(function (c) { return c.qty > 0; });
                syncCartBar();
                renderCartPage();
              });
            });

            cartView.querySelectorAll('[data-ship-opt]').forEach(function (lbl) {
              lbl.addEventListener('click', function () {
                var nextMethod = lbl.getAttribute('data-ship-opt') || 'makan_ditempat';
                if (customer.shippingMethod !== nextMethod) {
                  customer.shippingMethod = nextMethod;
                  customer.checklistConfirmed = false;
                  renderCartPage();
                }
              });
            });

            var sTime = document.getElementById('lynk-ship-time');
            var sGuests = document.getElementById('lynk-ship-guests');
            var sCheck = document.getElementById('lynk-ship-check');
            if (sTime) sTime.addEventListener('input', function () { customer.arrivalTime = sTime.value; syncCartWa(); });
            if (sGuests) sGuests.addEventListener('input', function () { customer.guestCount = sGuests.value; syncCartWa(); });
            if (sCheck) sCheck.addEventListener('change', function () {
              customer.checklistConfirmed = sCheck.checked;
              if (sCheck.parentElement) {
                sCheck.parentElement.style.borderColor = sCheck.checked ? '#10B981' : (theme.borderColor || '#E2E8F0');
              }
              syncCartWa();
            });

            var fName = document.getElementById('lynk-cust-name');
            var fPhone = document.getElementById('lynk-cust-phone');
            var fAddr = document.getElementById('lynk-cust-addr');
            var fNotes = document.getElementById('lynk-cust-notes');
            if (fName) fName.addEventListener('input', function () { customer.name = fName.value; syncCartWa(); });
            if (fPhone) fPhone.addEventListener('input', function () { customer.phone = fPhone.value; syncCartWa(); });
            if (fAddr) fAddr.addEventListener('input', function () { customer.address = fAddr.value; syncCartWa(); });
            if (fNotes) fNotes.addEventListener('input', function () { customer.notes = fNotes.value; syncCartWa(); });
          }

          function applyView(route, pushHash) {
            activeRoute = route;
            if (typeof closeAllBottomSheets === 'function') closeAllBottomSheets();
            if (route.type === 'detail') {
              mainView.style.display = 'none';
              cartView.style.display = 'none';
              detailView.style.display = 'block';
              renderDetailPage(route.blockId, route.itemId);
              if (pushHash) location.hash = '#produk-' + encodeURIComponent(route.blockId) + '--' + encodeURIComponent(route.itemId);
            } else if (route.type === 'cart') {
              mainView.style.display = 'none';
              detailView.style.display = 'none';
              cartView.style.display = 'block';
              renderCartPage();
              if (pushHash) location.hash = '#keranjang';
            } else {
              detailView.style.display = 'none';
              cartView.style.display = 'none';
              mainView.style.display = 'block';
              if (pushHash && location.hash) history.replaceState(null, '', location.pathname + location.search);
            }
            syncCartBar();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }
          function goHome() {
            applyView({ type: 'home', blockId: '', itemId: '' }, true);
          }
          window.__lynkGoHome = goHome;
          function openCart() {
            applyView({ type: 'cart', blockId: '', itemId: '' }, true);
          }
          function syncFromHash() {
            var h = location.hash || '';
            if (h === '#keranjang') {
              applyView({ type: 'cart', blockId: '', itemId: '' }, false);
            } else if (h.indexOf('#produk-') === 0) {
              var raw = h.slice('#produk-'.length);
              var sep = raw.indexOf('--');
              if (sep > 0) {
                var bId = decodeURIComponent(raw.slice(0, sep));
                var iId = decodeURIComponent(raw.slice(sep + 2));
                if (findItem(bId, iId)) {
                  applyView({ type: 'detail', blockId: bId, itemId: iId }, false);
                  return;
                }
              }
              applyView({ type: 'home', blockId: '', itemId: '' }, false);
            } else {
              applyView({ type: 'home', blockId: '', itemId: '' }, false);
            }
          }

          document.querySelectorAll('[data-quick-add]').forEach(function (btn) {
            btn.addEventListener('click', function (e) {
              e.preventDefault();
              e.stopPropagation();
              var parts = (btn.getAttribute('data-quick-add') || '').split('::');
              if (parts.length !== 2) return;
              var found = findItem(parts[0], parts[1]);
              if (!found) return;
              var vars = parseVars(found.item.variants);
              addCartItem(parts[0], found.item, vars.length ? vars[0] : '', 1);
            });
          });

          document.querySelectorAll('[data-open-detail]').forEach(function (card) {
            card.addEventListener('click', function (e) {
              if (e.target && e.target.closest && e.target.closest('[data-quick-add]')) return;
              var parts = (card.getAttribute('data-open-detail') || '').split('::');
              if (parts.length !== 2) return;
              applyView({ type: 'detail', blockId: parts[0], itemId: parts[1] }, true);
            });
            card.addEventListener('keydown', function (e) {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                var parts = (card.getAttribute('data-open-detail') || '').split('::');
                if (parts.length !== 2) return;
                applyView({ type: 'detail', blockId: parts[0], itemId: parts[1] }, true);
              }
            });
          });

          if (openCartBtn) openCartBtn.addEventListener('click', openCart);
          window.addEventListener('hashchange', syncFromHash);
          if (location.hash) syncFromHash();
        }
      }

      // Ad Attribution, Meta/TikTok/Google Pixel & WA Click Tracker
      (function () {
        var sEl = document.getElementById('lynk-store-data');
        if (!sEl) return;
        var sData = {};
        try { sData = JSON.parse(sEl.textContent || '{}'); } catch (e) { return; }
        var adsCfg = sData.ads || {};

        function detectAttribution() {
          var key = 'lynk_attr_' + (sData.slug || 'default');
          var stored = null;
          try { stored = JSON.parse(sessionStorage.getItem(key) || 'null'); } catch (e) {}
          var sp = new URLSearchParams(location.search || '');
          var utmSource = sp.get('utm_source') || '';
          var utmMedium = sp.get('utm_medium') || '';
          var utmCampaign = sp.get('utm_campaign') || '';
          var utmContent = sp.get('utm_content') || '';
          var fbclid = sp.get('fbclid') || '';
          var ctwaClid = sp.get('ctwa_clid') || '';
          var ttclid = sp.get('ttclid') || '';
          var gclid = sp.get('gclid') || sp.get('gbraid') || sp.get('wbraid') || '';

          var hasNew = Boolean(utmSource || utmMedium || utmCampaign || fbclid || ctwaClid || ttclid || gclid);
          if (!hasNew && stored) return stored;

          var us = utmSource.toLowerCase();
          var um = utmMedium.toLowerCase();
          var channel = 'organic';
          var clickIdType = '';
          if (ctwaClid || um.indexOf('ctwa') !== -1 || um.indexOf('click_to_wa') !== -1 || us === 'meta_wa') {
            channel = 'meta_wa_addon';
            if (ctwaClid) clickIdType = 'ctwa_clid';
            else if (fbclid) clickIdType = 'fbclid';
          } else if (fbclid || us === 'meta' || us === 'fb' || us === 'facebook' || us === 'ig' || us === 'instagram') {
            channel = 'meta';
            if (fbclid) clickIdType = 'fbclid';
          } else if (ttclid || us === 'tiktok' || us === 'tt') {
            channel = 'tiktok';
            if (ttclid) clickIdType = 'ttclid';
          } else if (gclid || us === 'google' || us === 'adwords' || us === 'gads') {
            channel = 'google';
            if (gclid) clickIdType = 'gclid';
          }

          var res = {
            channel: channel,
            utmSource: utmSource,
            utmMedium: utmMedium,
            utmCampaign: utmCampaign,
            utmContent: utmContent,
            clickIdType: clickIdType
          };
          try { sessionStorage.setItem(key, JSON.stringify(res)); } catch (e) {}
          return res;
        }

        var attr = detectAttribution();
        var channelLabels = {
          meta: 'Meta Ads',
          meta_wa_addon: 'Meta WA Add-On',
          tiktok: 'TikTok Ads',
          google: 'Google Ads',
          organic: 'Organik'
        };

        function sendServerEvent(eventType, extra) {
          if (location.protocol.indexOf('http') !== 0 || !sData.projectId) return;
          var payload = {
            projectId: sData.projectId,
            projectTitle: sData.projectTitle || '',
            slug: sData.slug || '',
            eventType: eventType,
            channel: attr.channel || 'organic',
            sourceLabel: channelLabels[attr.channel] || 'Organik',
            utmSource: attr.utmSource || undefined,
            utmMedium: attr.utmMedium || undefined,
            utmCampaign: attr.utmCampaign || undefined,
            utmContent: attr.utmContent || undefined,
            clickIdType: attr.clickIdType || undefined,
            deviceType: window.innerWidth < 768 ? 'mobile' : 'desktop',
            createdAt: Date.now()
          };
          if (extra) {
            for (var k in extra) {
              if (Object.prototype.hasOwnProperty.call(extra, k)) payload[k] = extra[k];
            }
          }
          try {
            var body = JSON.stringify(payload);
            if (navigator.sendBeacon) {
              navigator.sendBeacon('/api/track/event', new Blob([body], { type: 'application/json' }));
            } else {
              fetch('/api/track/event', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: body,
                keepalive: true
              }).catch(function () {});
            }
          } catch (e) {}
        }

        sendServerEvent('page_view');

        document.addEventListener('click', function (e) {
          var t = e.target;
          if (!t || !t.closest) return;

          var addBtn = t.closest('[data-quick-add], #lynk-det-add');
          if (addBtn) {
            if (typeof window.fbq === 'function') window.fbq('track', 'AddToCart');
            if (typeof window.ttq === 'object' && window.ttq.track) window.ttq.track('AddToCart');
            if (typeof window.gtag === 'function') window.gtag('event', 'add_to_cart');
            return;
          }

          var detailCard = t.closest('[data-open-detail]');
          if (detailCard) {
            if (typeof window.fbq === 'function') window.fbq('track', 'ViewContent');
            if (typeof window.ttq === 'object' && window.ttq.track) window.ttq.track('ViewContent');
            if (typeof window.gtag === 'function') window.gtag('event', 'view_item');
            return;
          }

          var anchor = t.closest('a[href]');
          if (!anchor) return;
          var href = anchor.getAttribute('href') || '';
          var low = href.toLowerCase();
          var isWa = low.indexOf('wa.me/') !== -1 || low.indexOf('api.whatsapp.com') !== -1 || low.indexOf('whatsapp://') === 0;
          if (!isWa) return;

          if (adsCfg.appendAdAttributionToWa && attr.channel !== 'organic' && href.indexOf('text=') !== -1) {
            try {
              var urlObj = new URL(href);
              var curText = urlObj.searchParams.get('text') || '';
              var tagLine = '[Sumber: ' + (channelLabels[attr.channel] || attr.channel) + (attr.utmCampaign ? ' · ' + attr.utmCampaign : '') + ']';
              if (curText.indexOf('[Sumber:') === -1) {
                urlObj.searchParams.set('text', (curText ? curText + '\n\n' : '') + tagLine);
                anchor.setAttribute('href', urlObj.toString());
              }
            } catch (err) {}
          }

          var phoneMatch = href.match(/wa\.me\/(\d+)|[?&]phone=(\d+)/i);
          var waPhone = phoneMatch ? (phoneMatch[1] || phoneMatch[2]) : '';
          var ctaLabel = anchor.getAttribute('data-lynk-wa-source') || (anchor.textContent || '').trim().slice(0, 60) || 'Tombol WhatsApp';

          var metaEvent = adsCfg.metaWaEvent || 'Lead';
          if (typeof window.fbq === 'function') {
            window.fbq('track', metaEvent, { content_name: ctaLabel, content_category: attr.channel });
          }
          if (typeof window.ttq === 'object' && window.ttq.track) {
            window.ttq.track('Contact', { description: ctaLabel });
          }
          if (typeof window.gtag === 'function') {
            window.gtag('event', 'generate_lead', { event_category: 'WhatsApp', event_label: ctaLabel });
            if (adsCfg.googleTagId && adsCfg.googleAdsConversionLabel) {
              window.gtag('event', 'conversion', { send_to: adsCfg.googleTagId + '/' + adsCfg.googleAdsConversionLabel });
            }
          }

          sendServerEvent('wa_click', { ctaLabel: ctaLabel, waPhone: waPhone });
        }, true);

        document.addEventListener('submit', function (e) {
          var form = e.target;
          if (!form || form.tagName !== 'FORM') return;
          if (typeof window.fbq === 'function') window.fbq('track', 'Lead');
          if (typeof window.ttq === 'object' && window.ttq.track) window.ttq.track('SubmitForm');
          if (typeof window.gtag === 'function') window.gtag('event', 'generate_lead', { event_category: 'Form' });
          sendServerEvent('form_submit', { ctaLabel: 'Form Isian' });
        }, true);
      })();
    })();
  </script>
</body>
</html>`;
}
