import { ButtonIconId } from '../types/builder';

export interface ButtonIconMeta {
  id: ButtonIconId;
  label: string;
  svgInner: string;
}

export const BUTTON_ICON_LIST: ButtonIconMeta[] = [
  { id: 'none', label: 'Tanpa', svgInner: '' },
  {
    id: 'home',
    label: 'Home',
    svgInner:
      '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
  },
  {
    id: 'map-pin',
    label: 'Lokasi',
    svgInner:
      '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
  },
  {
    id: 'navigation',
    label: 'Rute',
    svgInner: '<polygon points="3 11 22 2 13 21 11 13 3 11"/>',
  },
  {
    id: 'eye',
    label: 'Lihat',
    svgInner:
      '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
  },
  {
    id: 'phone',
    label: 'Kontak',
    svgInner:
      '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
  },
  {
    id: 'shopping-bag',
    label: 'Belanja',
    svgInner:
      '<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/>',
  },
  {
    id: 'globe',
    label: 'Web',
    svgInner:
      '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
  },
  {
    id: 'info',
    label: 'Info',
    svgInner:
      '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
  },
  {
    id: 'star',
    label: 'Favorit',
    svgInner:
      '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
  },
  {
    id: 'image',
    label: 'Foto',
    svgInner:
      '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
  },
  {
    id: 'play',
    label: 'Video',
    svgInner:
      '<circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/>',
  },
  {
    id: 'download',
    label: 'Unduh',
    svgInner:
      '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
  },
];

export const BUTTON_ICONS_MAP: Record<ButtonIconId, ButtonIconMeta> = BUTTON_ICON_LIST.reduce(
  (acc, item) => {
    acc[item.id] = item;
    return acc;
  },
  {} as Record<ButtonIconId, ButtonIconMeta>
);

export function resolveButtonIcon(explicitIcon?: ButtonIconId, label?: string): ButtonIconId {
  if (explicitIcon) return explicitIcon;
  if (label && /lokasi|maps|alamat|tempat|rute/i.test(label)) {
    return 'map-pin';
  }
  return 'none';
}

export function renderButtonIconSvgString(iconId: ButtonIconId, size = 16): string {
  if (!iconId || iconId === 'none') return '';
  const meta = BUTTON_ICONS_MAP[iconId];
  if (!meta || !meta.svgInner) return '';
  return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0;" aria-hidden="true">${meta.svgInner}</svg>`;
}
