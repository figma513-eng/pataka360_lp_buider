export type BlockType =
  | 'row'
  | 'container'
  | 'toggle_container'
  | 'text'
  | 'image'
  | 'button'
  | 'form'
  | 'divider'
  | 'youtube'
  | 'facebook_video'
  | 'tiktok_video'
  | 'instagram_video'
  | 'catalog'
  | 'social'
  | 'social_follower'
  | 'carousel'
  | 'social_feed'
  | 'maps_place'
  | 'bottom_sheet';

export type CarouselAspectRatio = '1/1' | '4/5' | '9/16' | '16/9';

export interface CarouselItem {
  id: string;
  image: string;
  title: string;
  caption: string;
  url?: string;
}

export interface SocialPostItem {
  id: string;
  mediaType: 'image' | 'video';
  imageUrl: string;
  videoUrl?: string;
  caption: string;
  likes?: string;
  comments?: string;
  url?: string;
}

export type SocialPlatform =
  | 'facebook'
  | 'instagram'
  | 'tiktok'
  | 'youtube'
  | 'whatsapp'
  | 'threads'
  | 'twitter'
  | 'telegram'
  | 'linkedin'
  | 'pinterest'
  | 'discord'
  | 'twitch'
  | 'spotify'
  | 'snapchat'
  | 'line';

export interface SocialLinkItem {
  id: string;
  platform: SocialPlatform;
  url: string;
  visible: boolean;
}

export interface SocialFollowerAccount {
  id: string;
  platform: SocialPlatform;
  avatar?: string;
  accountName: string;
  handle: string;
  accountUrl?: string;
  verified?: boolean;
  postsCount?: string;
  postsLabel?: string;
  followers?: string;
  followersLabel?: string;
  following?: string;
  followingLabel?: string;
  bio?: string;
  followLabel?: string;
}

export type TextAlign = 'left' | 'center' | 'right';
export type ShadowPreset = 'none' | 'sm' | 'md' | 'lg';
export type BlockLayoutMode = 'default' | 'grid' | 'large-image' | 'compact';
export type ButtonIconId =
  | 'none'
  | 'home'
  | 'map-pin'
  | 'navigation'
  | 'eye'
  | 'phone'
  | 'shopping-bag'
  | 'globe'
  | 'info'
  | 'star'
  | 'image'
  | 'play'
  | 'download';

export type CatalogProductType = 'physical' | 'service';
export type CatalogCartButtonSize = 'sm' | 'md' | 'lg';
export type BottomSheetTriggerStyle = 'icon' | 'pill' | 'button';

export type ShippingMethodId =
  | 'makan_ditempat'
  | 'ambil_sendiri'
  | 'kurir_sendiri'
  | 'gosend_penjual';

export interface CatalogShippingOptionConfig {
  id: ShippingMethodId;
  enabled: boolean;
  label: string;
  askArrivalTime?: boolean;
  arrivalTimeLabel?: string;
  arrivalTimePlaceholder?: string;
  askGuestCount?: boolean;
  guestCountLabel?: string;
  guestCountPlaceholder?: string;
  checklistEnabled?: boolean;
  checklistText?: string;
  noteTitle?: string;
  noteText?: string;
}

export interface CatalogItem {
  id: string;
  title: string;
  subtitle: string;
  description?: string;
  badge?: string;
  variants?: string;
  gallery?: string[];
  productType?: 'inherit' | CatalogProductType;
  pickupNote?: string;
  price: string;
  ctaLabel: string;
  url: string;
  image: string;
  imageAspectRatio?: 'auto' | '16/9' | '4/3' | '1/1';
  imageObjectFit?: 'cover' | 'contain';
  unitSold: number;
}

export interface AdvanceOptions {
  showUnitSold: boolean;
  blockLayout: BlockLayoutMode;
  pageTopPadding?: number;
}

export type BottomNavbarItemAction = 'sheet' | 'scroll_top';

export interface BottomNavbarItem {
  id: string;
  label: string;
  icon: ButtonIconId;
  enabled: boolean;
  action: BottomNavbarItemAction;
  sheetTitle: string;
  children: BuilderBlock[];
}

export interface BottomNavbarConfig {
  enabled: boolean;
  barBg: string;
  textColor: string;
  accentColor: string;
  borderColor: string;
  centerStyle: 'elevated' | 'inline';
  items: BottomNavbarItem[];
}

export interface BlockStyle {
  blur: number;
  align: TextAlign;
  widthPercent: number;
  minHeight: number;
  borderRadius: number;
  shadow: ShadowPreset;
  shadowColor?: string;
  borderWidth: number;
  borderColor: string;
  backgroundColor: string;
  textColor: string;
  useThemeTextColor?: boolean;
  padding: number;
  paddingTop?: number;
  paddingBottom?: number;
  paddingX?: number;
  fullBleed?: boolean;
  marginBottom: number;
}

export interface BlockContent {
  // Text
  text?: string;
  variant?: 'h1' | 'h2' | 'body';
  fontWeight?: 'normal' | 'semibold' | 'bold';
  // Image
  src?: string;
  alt?: string;
  aspectRatio?: 'auto' | '16/9' | '4/3' | '1/1';
  objectFit?: 'cover' | 'contain';
  imageShape?: 'rect' | 'circle';
  circleSize?: number;
  imageZoom?: number;
  // Button
  label?: string;
  url?: string;
  buttonBg?: string;
  buttonText?: string;
  buttonIcon?: ButtonIconId;
  // Form
  formTitle?: string;
  namePlaceholder?: string;
  emailPlaceholder?: string;
  submitLabel?: string;
  successMessage?: string;
  buttonColor?: string;
  // Video Embeds (YouTube, Facebook, TikTok)
  youtubeUrl?: string;
  youtubeAspectRatio?: '16/9' | '1/1' | '4/5' | '9/16';
  youtubeAutoplay?: boolean;
  youtubeVolume?: number;
  videoUrl?: string;
  videoPoster?: string;
  videoAspectRatio?: '16/9' | '1/1' | '4/5' | '9/16';
  videoAutoplay?: boolean;
  videoVolume?: number;
  // Divider
  lineColor?: string;
  thickness?: number;
  lineStyle?: 'solid' | 'dashed' | 'dotted';
  // Catalog
  catalogItems?: CatalogItem[];
  catalogProductType?: CatalogProductType;
  catalogDetailEnabled?: boolean;
  catalogCartEnabled?: boolean;
  catalogCartButtonSize?: CatalogCartButtonSize;
  catalogWhatsappNumber?: string;
  catalogStoreName?: string;
  catalogWhatsappIntro?: string;
  catalogAskCustomerInfo?: boolean;
  catalogShippingEnabled?: boolean;
  catalogPickupNote?: string;
  catalogShippingNote?: string;
  catalogShippingOptions?: CatalogShippingOptionConfig[];
  // Photo Carousel
  carouselItems?: CarouselItem[];
  carouselAspectRatio?: CarouselAspectRatio;
  carouselObjectFit?: 'cover' | 'contain';
  // Social Profile & Postings Carousel
  socialFeedPlatform?: SocialPlatform;
  socialFeedAvatar?: string;
  socialFeedAccountName?: string;
  socialFeedHandle?: string;
  socialFeedAccountUrl?: string;
  socialFeedVerified?: boolean;
  socialFeedPostsCount?: string;
  socialFeedFollowers?: string;
  socialFeedFollowersLabel?: string;
  socialFeedFollowing?: string;
  socialFeedBio?: string;
  socialFeedFollowLabel?: string;
  socialFeedRatio?: CarouselAspectRatio;
  socialFeedPosts?: SocialPostItem[];
  // Maps Place Card
  mapsPhotoUrl?: string;
  mapsPhotoBadgeLabel?: string;
  mapsPhotoRatio?: '16/9' | '4/3' | '4/5' | '1/1';
  mapsTitle?: string;
  mapsRating?: number;
  mapsReviewCount?: string;
  mapsService?: string;
  mapsAccessible?: boolean;
  mapsServicesList?: string;
  mapsAddress?: string;
  mapsUrl?: string;
  mapsButtonLabel?: string;
  // Social Media Icons
  socialItems?: SocialLinkItem[];
  socialStyle?: 'filled' | 'outline' | 'minimal';
  socialShape?: 'circle' | 'rounded';
  socialSize?: 'sm' | 'md' | 'lg';
  socialIconSize?: number;
  socialGap?: number;
  socialUseBrandColors?: boolean;
  socialColor?: string;
  // Social Media + Follower Cards
  socialFollowerAccounts?: SocialFollowerAccount[];
  socialFollowerGap?: number;
  // Toggle Container (Show / Hide)
  toggleShowLabel?: string;
  toggleHideLabel?: string;
  toggleDefaultOpen?: boolean;
  toggleButtonBg?: string;
  toggleButtonText?: string;
  toggleButtonStyle?: 'solid' | 'outline';
  toggleButtonIcon?: ButtonIconId;
  // Bottom Sheet
  sheetTitle?: string;
  sheetTriggerStyle?: BottomSheetTriggerStyle;
  sheetTriggerLabel?: string;
  sheetTriggerSublabel?: string;
  sheetTriggerIcon?: ButtonIconId;
  sheetTriggerBg?: string;
  sheetTriggerText?: string;
  sheetIconSize?: number;
}

export interface BuilderBlock {
  id: string;
  type: BlockType;
  label: string;
  style: BlockStyle;
  content: BlockContent;
  children?: BuilderBlock[];
}

export interface PageTheme {
  id: string;
  name: string;
  category?: 'brand' | 'basic' | 'aesthetic';
  brandSource?: string;
  canvasBg: string;
  cardBg: string;
  textColor: string;
  accentColor: string;
  borderColor: string;
}

export type AdChannel = 'meta' | 'meta_wa_addon' | 'tiktok' | 'google' | 'organic';

export type MetaWaEventName = 'Lead' | 'Contact' | 'InitiateCheckout' | 'Purchase';

export interface ProjectPublishingConfig {
  slug: string;
  customDomain: string;
  useCustomDomain: boolean;
  isPublished: boolean;
  publishedAt?: number;
  seoTitle?: string;
  seoDescription?: string;
}

export interface ProjectAdsConfig {
  metaPixelId: string;
  metaTestEventCode?: string;
  metaWaEvent: MetaWaEventName;
  metaCapiForwarding: boolean;
  tiktokPixelId: string;
  googleTagId: string;
  googleAdsConversionLabel?: string;
  gtmContainerId?: string;
  waAddonEnabled: boolean;
  waAddonNumber: string;
  waAddonGreeting?: string;
  appendAdAttributionToWa: boolean;
}

export interface AnalyticsEventRecord {
  id: string;
  projectId: string;
  projectTitle: string;
  slug: string;
  eventType: 'page_view' | 'wa_click' | 'form_submit';
  channel: AdChannel;
  sourceLabel: string;
  ctaLabel?: string;
  waPhone?: string;
  orderValue?: number;
  utmSource?: string;
  utmMedium?: string;
  utmCampaign?: string;
  utmContent?: string;
  clickIdType?: 'fbclid' | 'ctwa_clid' | 'ttclid' | 'gclid';
  deviceType: 'mobile' | 'desktop';
  isTest?: boolean;
  createdAt: number;
}

export interface BuilderProject {
  title: string;
  theme: PageTheme;
  blocks: BuilderBlock[];
  advanceOptions: AdvanceOptions;
  bottomNavbar?: BottomNavbarConfig;
  publishing?: ProjectPublishingConfig;
  adsConfig?: ProjectAdsConfig;
}

export interface ProjectRecord {
  id: string;
  project: BuilderProject;
  updatedAt: number;
  lastSavedAt?: number;
}

export interface WorkspaceBundle {
  version: 1;
  activeProjectId: string;
  projects: ProjectRecord[];
}

export type AccessRole = 'super_admin' | 'admin' | 'editor' | 'viewer';

export type FeaturePermissionKey =
  | 'editor'
  | 'projects'
  | 'publishing'
  | 'ads_wa'
  | 'analytics'
  | 'export_backup'
  | 'access_control';

export type FeaturePermissionsMap = Record<FeaturePermissionKey, boolean>;

export interface AccessMemberRecord {
  id: string;
  name: string;
  email: string;
  role: AccessRole;
  isActive: boolean;
  unitScope: 'all' | string[];
  permissions: FeaturePermissionsMap;
  createdAt: number;
}

export interface AccessSettingsConfig {
  allUsersSuperAdmin: boolean;
  autoGrantSuperAdminOnJoin: boolean;
  defaultRole: AccessRole;
  activeMemberId: string;
  members: AccessMemberRecord[];
  updatedAt: number;
}

