import {
  AdvanceOptions,
  BlockStyle,
  BlockType,
  BottomNavbarConfig,
  BottomNavbarItem,
  BuilderBlock,
  BuilderProject,
  CarouselItem,
  CatalogItem,
  PageTheme,
  SocialFollowerAccount,
  SocialLinkItem,
  SocialPostItem,
} from '../types/builder';

let idCounter = 100;
export function createId(prefix = 'blk'): string {
  idCounter += 1;
  return `${prefix}_${Date.now().toString(36)}_${idCounter}`;
}

export const STARTER_ILLUSTRATION_SVG =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 220" fill="none">
    <rect width="320" height="220" rx="20" fill="#F8FAFC"/>
    <circle cx="160" cy="96" r="52" fill="#E0E7FF"/>
    <rect x="118" y="64" width="84" height="64" rx="14" fill="#2563EB"/>
    <rect x="130" y="76" width="60" height="10" rx="5" fill="#93C5FD"/>
    <rect x="130" y="94" width="42" height="8" rx="4" fill="#DBEAFE"/>
    <rect x="130" y="108" width="28" height="8" rx="4" fill="#EFF6FF"/>
    <circle cx="212" cy="64" r="14" fill="#F59E0B"/>
    <path d="M207 64L211 68L218 60" stroke="#FFFFFF" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
    <text x="160" y="182" text-anchor="middle" font-family="sans-serif" font-size="16" font-weight="700" fill="#0F172A">Katalog Digital</text>
  </svg>`);

export const PRODUCT_CARD_SVG =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 180" fill="none">
    <rect width="320" height="180" rx="14" fill="#EFF6FF"/>
    <rect x="44" y="34" width="232" height="112" rx="12" fill="#FFFFFF" stroke="#BFDBFE" stroke-width="2"/>
    <rect x="64" y="54" width="76" height="72" rx="8" fill="#2563EB"/>
    <rect x="156" y="58" width="96" height="12" rx="6" fill="#1E293B"/>
    <rect x="156" y="80" width="74" height="8" rx="4" fill="#94A3B8"/>
    <rect x="156" y="102" width="60" height="22" rx="6" fill="#2563EB"/>
  </svg>`);

export const CAROUSEL_SAMPLE_1_SVG =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" fill="none">
    <defs>
      <linearGradient id="g1" x1="0" y1="0" x2="400" y2="400" gradientUnits="userSpaceOnUse">
        <stop stop-color="#1D4ED8"/>
        <stop offset="1" stop-color="#0F172A"/>
      </linearGradient>
    </defs>
    <rect width="400" height="400" fill="url(#g1)"/>
    <circle cx="315" cy="95" r="78" fill="#3B82F6" fill-opacity="0.35"/>
    <rect x="64" y="116" width="272" height="168" rx="22" fill="#FFFFFF" fill-opacity="0.14" stroke="#93C5FD" stroke-opacity="0.45" stroke-width="2"/>
    <circle cx="144" cy="186" r="24" fill="#FDE047"/>
    <path d="M92 260L164 196L220 242L264 206L308 260H92Z" fill="#DBEAFE" fill-opacity="0.9"/>
  </svg>`);

export const CAROUSEL_SAMPLE_2_SVG =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" fill="none">
    <defs>
      <linearGradient id="g2" x1="0" y1="0" x2="400" y2="400" gradientUnits="userSpaceOnUse">
        <stop stop-color="#059669"/>
        <stop offset="1" stop-color="#064E3B"/>
      </linearGradient>
    </defs>
    <rect width="400" height="400" fill="url(#g2)"/>
    <circle cx="96" cy="310" r="88" fill="#34D399" fill-opacity="0.28"/>
    <rect x="76" y="100" width="248" height="200" rx="24" fill="#FFFFFF" fill-opacity="0.16" stroke="#A7F3D0" stroke-opacity="0.5" stroke-width="2"/>
    <rect x="112" y="138" width="176" height="22" rx="11" fill="#ECFDF5"/>
    <rect x="112" y="176" width="132" height="14" rx="7" fill="#A7F3D0" fill-opacity="0.85"/>
    <rect x="112" y="216" width="110" height="40" rx="12" fill="#10B981"/>
  </svg>`);

export const CAROUSEL_SAMPLE_3_SVG =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" fill="none">
    <defs>
      <linearGradient id="g3" x1="0" y1="0" x2="400" y2="400" gradientUnits="userSpaceOnUse">
        <stop stop-color="#D97706"/>
        <stop offset="1" stop-color="#7C2D12"/>
      </linearGradient>
    </defs>
    <rect width="400" height="400" fill="url(#g3)"/>
    <circle cx="290" cy="110" r="90" fill="#FBBF24" fill-opacity="0.3"/>
    <rect x="82" y="112" width="236" height="176" rx="22" fill="#FFFFFF" fill-opacity="0.15" stroke="#FDE68A" stroke-opacity="0.5" stroke-width="2"/>
    <circle cx="200" cy="186" r="38" fill="#FEF3C7"/>
    <path d="M188 172L218 186L188 200V172Z" fill="#B45309"/>
    <rect x="130" y="242" width="140" height="12" rx="6" fill="#FEF3C7" fill-opacity="0.85"/>
  </svg>`);

export const MAPS_LOCATION_SVG =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 480 270" fill="none">
    <defs>
      <linearGradient id="sky" x1="0" y1="0" x2="0" y2="160" gradientUnits="userSpaceOnUse">
        <stop stop-color="#CBD5E1"/>
        <stop offset="1" stop-color="#E2E8F0"/>
      </linearGradient>
    </defs>
    <rect width="480" height="270" fill="url(#sky)"/>
    <path d="M0 175 L480 175 L480 270 L0 270 Z" fill="#94A3B8"/>
    <path d="M35 270 L175 165 L305 165 L445 270 Z" fill="#CBD5E1"/>
    <rect x="172" y="34" width="136" height="128" rx="6" fill="#16A34A" stroke="#15803D" stroke-width="3"/>
    <rect x="70" y="92" width="102" height="70" rx="4" fill="#22C55E" stroke="#15803D" stroke-width="2"/>
    <rect x="86" y="108" width="70" height="44" rx="2" fill="#1E293B"/>
    <rect x="190" y="52" width="26" height="22" rx="2" fill="#E2E8F0"/>
    <rect x="227" y="52" width="26" height="22" rx="2" fill="#E2E8F0"/>
    <rect x="264" y="52" width="26" height="22" rx="2" fill="#E2E8F0"/>
    <rect x="190" y="88" width="100" height="20" rx="3" fill="#FFFFFF"/>
    <rect x="198" y="94" width="84" height="8" rx="2" fill="#2563EB"/>
    <rect x="202" y="122" width="76" height="40" rx="2" fill="#0F172A" fill-opacity="0.7"/>
    <rect x="278" y="142" width="24" height="16" rx="4" fill="#FFFFFF" stroke="#64748B" stroke-width="1.5"/>
    <circle cx="388" cy="116" r="32" fill="#15803D"/>
    <circle cx="388" cy="88" r="24" fill="#16A34A"/>
    <rect x="384" y="142" width="8" height="26" fill="#78350F"/>
    <path d="M225 220 L235 215 L230 225 Z" fill="#FFFFFF"/>
    <path d="M255 220 L245 215 L250 225 Z" fill="#FFFFFF"/>
  </svg>`);

export const THEMES: PageTheme[] = [
  // Inspirasi Brand Populer
  {
    id: 'lynk-emerald',
    name: 'Lynk.id Emerald',
    category: 'brand',
    brandSource: 'lynk.id',
    canvasBg: '#F4FBF8',
    cardBg: '#FFFFFF',
    textColor: '#0F172A',
    accentColor: '#10B981',
    borderColor: '#D1FAE5',
  },
  {
    id: 'lynk-dark',
    name: 'Lynk.id Dark Mint',
    category: 'brand',
    brandSource: 'lynk.id',
    canvasBg: '#091511',
    cardBg: '#11241E',
    textColor: '#ECFDF5',
    accentColor: '#10B981',
    borderColor: '#1E3F35',
  },
  {
    id: 'shopee-orange',
    name: 'Shopee Oranye',
    category: 'brand',
    brandSource: 'shopee.co.id',
    canvasBg: '#FFF7F5',
    cardBg: '#FFFFFF',
    textColor: '#222222',
    accentColor: '#EE4D2D',
    borderColor: '#FCDAD2',
  },
  {
    id: 'shopee-flash',
    name: 'Shopee Coral Bold',
    category: 'brand',
    brandSource: 'shopee.co.id',
    canvasBg: '#FFECE8',
    cardBg: '#FFFFFF',
    textColor: '#2B1410',
    accentColor: '#D73211',
    borderColor: '#F8C4B8',
  },
  {
    id: 'tiket-blue',
    name: 'tiket.com Biru',
    category: 'brand',
    brandSource: 'tiket.com',
    canvasBg: '#F2F6FF',
    cardBg: '#FFFFFF',
    textColor: '#111827',
    accentColor: '#0064D2',
    borderColor: '#D6E4FF',
  },
  {
    id: 'tiket-night',
    name: 'tiket.com Navy',
    category: 'brand',
    brandSource: 'tiket.com',
    canvasBg: '#081833',
    cardBg: '#10274D',
    textColor: '#F8FAFC',
    accentColor: '#2E86FF',
    borderColor: '#1E3B6E',
  },
  {
    id: 'traveloka-sky',
    name: 'Traveloka Biru Langit',
    category: 'brand',
    brandSource: 'traveloka.com',
    canvasBg: '#EDF7FE',
    cardBg: '#FFFFFF',
    textColor: '#03121A',
    accentColor: '#0194F3',
    borderColor: '#C5E4FA',
  },
  {
    id: 'traveloka-deep',
    name: 'Traveloka Samudra',
    category: 'brand',
    brandSource: 'traveloka.com',
    canvasBg: '#052642',
    cardBg: '#0B365C',
    textColor: '#F0F9FF',
    accentColor: '#1BA0E2',
    borderColor: '#184F7D',
  },
  // Tema Dasar & Minimalis
  {
    id: 'minimal-light',
    name: 'Putih Minimalis',
    category: 'basic',
    canvasBg: '#F8FAFC',
    cardBg: '#FFFFFF',
    textColor: '#0F172A',
    accentColor: '#2563EB',
    borderColor: '#E2E8F0',
  },
  {
    id: 'soft-lavender',
    name: 'Lavender Lembut',
    category: 'basic',
    canvasBg: '#F5F3FF',
    cardBg: '#FFFFFF',
    textColor: '#1E1B4B',
    accentColor: '#4F46E5',
    borderColor: '#E0E7FF',
  },
  {
    id: 'warm-sand',
    name: 'Krem Hangat',
    category: 'basic',
    canvasBg: '#FAF7F2',
    cardBg: '#FFFFFF',
    textColor: '#292524',
    accentColor: '#D97706',
    borderColor: '#E7E5E4',
  },
  {
    id: 'mint-fresh',
    name: 'Hijau Segar',
    category: 'basic',
    canvasBg: '#F0FDF4',
    cardBg: '#FFFFFF',
    textColor: '#064E3B',
    accentColor: '#059669',
    borderColor: '#D1FAE5',
  },
  {
    id: 'midnight-slate',
    name: 'Gelap Elegan',
    category: 'basic',
    canvasBg: '#0F172A',
    cardBg: '#1E293B',
    textColor: '#F8FAFC',
    accentColor: '#3B82F6',
    borderColor: '#334155',
  },
  // Tema Tambahan & Estetik
  {
    id: 'tokopedia-green',
    name: 'Hijau Marketplace',
    category: 'aesthetic',
    canvasBg: '#F2FAF4',
    cardBg: '#FFFFFF',
    textColor: '#14261C',
    accentColor: '#00AA5B',
    borderColor: '#C8EBD2',
  },
  {
    id: 'rose-blush',
    name: 'Rose Pastel',
    category: 'aesthetic',
    canvasBg: '#FFF5F7',
    cardBg: '#FFFFFF',
    textColor: '#3B0D1C',
    accentColor: '#E11D48',
    borderColor: '#FECDD3',
  },
  {
    id: 'sunset-coral',
    name: 'Senja Tropis',
    category: 'aesthetic',
    canvasBg: '#FFF8F1',
    cardBg: '#FFFFFF',
    textColor: '#2E1A11',
    accentColor: '#F97316',
    borderColor: '#FED7AA',
  },
  {
    id: 'teal-modern',
    name: 'Toska Modern',
    category: 'aesthetic',
    canvasBg: '#F0FDFA',
    cardBg: '#FFFFFF',
    textColor: '#0F2E2B',
    accentColor: '#0D9488',
    borderColor: '#CCFBF1',
  },
  {
    id: 'espresso-mocha',
    name: 'Kopi & Krem',
    category: 'aesthetic',
    canvasBg: '#F7F0E9',
    cardBg: '#FFFDFB',
    textColor: '#2C1D14',
    accentColor: '#9A4D1E',
    borderColor: '#E6D4C3',
  },
  {
    id: 'royal-gold',
    name: 'Hitam & Emas Mewah',
    category: 'aesthetic',
    canvasBg: '#12110E',
    cardBg: '#1E1B16',
    textColor: '#FAF6ED',
    accentColor: '#D4AF37',
    borderColor: '#3A3222',
  },
];

export const DEFAULT_STYLE: BlockStyle = {
  blur: 0,
  align: 'center',
  widthPercent: 100,
  minHeight: 40,
  borderRadius: 14,
  shadow: 'none',
  borderWidth: 0,
  borderColor: '#E2E8F0',
  backgroundColor: 'transparent',
  textColor: '#0F172A',
  useThemeTextColor: true,
  padding: 12,
  fullBleed: false,
  marginBottom: 12,
};

export const DEFAULT_ADVANCE_OPTIONS: AdvanceOptions = {
  showUnitSold: false,
  blockLayout: 'default',
};

export const DEFAULT_CATALOG_ITEMS: CatalogItem[] = [
  {
    id: 'cat_1',
    title: 'Paket Template Presentasi Lengkap',
    subtitle: '80+ slide siap pakai untuk pitching & laporan',
    badge: 'Terlaris',
    variants: 'Edisi Canva, Edisi PowerPoint, Paket Lengkap',
    description:
      'Koleksi 80+ template slide profesional yang mudah diubah warna, tipografi, dan grafiknya. Cocok untuk proposal klien, laporan bulanan, hingga presentasi produk.\n\nTermasuk:\n• 80+ layout slide modern\n• Panduan edit cepat\n• Akses update gratis selamanya',
    price: 'Rp 99.000',
    ctaLabel: 'Lihat Detail',
    url: 'https://example.com/produk-1',
    image: PRODUCT_CARD_SVG,
    unitSold: 142,
  },
  {
    id: 'cat_2',
    title: 'E-Book Panduan Konten Kreator',
    subtitle: 'Strategi monetisasi produk digital dari nol',
    badge: 'Best Value',
    variants: 'E-Book PDF, E-Book + Worksheet',
    description:
      'Panduan praktis langkah demi langkah membangun audiens organik dan mengubah konten menjadi sumber pemasukan rutin.\n\nCocok untuk pemula maupun kreator yang ingin merapikan alur penjualan.',
    price: 'Rp 65.000',
    ctaLabel: 'Lihat Detail',
    url: 'https://example.com/produk-2',
    image: STARTER_ILLUSTRATION_SVG,
    unitSold: 87,
  },
  {
    id: 'cat_3',
    title: 'Kit Desain Feed Sosial Media',
    subtitle: 'Format Figma & Canva siap edit cepat',
    badge: 'Baru',
    variants: 'Canva Only, Figma + Canva',
    description:
      'Lebih dari 50 template feed dan story Instagram yang konsisten untuk branding bisnis dan UMKM.\n\nTinggal ganti foto, teks, dan warna sesuai identitas usaha Anda.',
    price: 'Rp 129.000',
    ctaLabel: 'Lihat Detail',
    url: 'https://example.com/produk-3',
    image: PRODUCT_CARD_SVG,
    unitSold: 64,
  },
  {
    id: 'cat_4',
    title: 'Template Notion Finance Tracker',
    subtitle: 'Kelola arus kas & target tabungan bulanan',
    variants: 'Personal, Bisnis UMKM',
    description:
      'Dashboard Notion siap duplikasi untuk mencatat pemasukan, pengeluaran, piutang usaha, dan laporan laba rugi sederhana secara otomatis.',
    price: 'Rp 49.000',
    ctaLabel: 'Lihat Detail',
    url: 'https://example.com/produk-4',
    image: STARTER_ILLUSTRATION_SVG,
    unitSold: 215,
  },
];

export const DEFAULT_SOCIAL_ITEMS: SocialLinkItem[] = [
  { id: 'soc_ig', platform: 'instagram', url: 'https://instagram.com/studiokreatif', visible: true },
  { id: 'soc_tt', platform: 'tiktok', url: 'https://tiktok.com/@studiokreatif', visible: true },
  { id: 'soc_fb', platform: 'facebook', url: 'https://facebook.com/studiokreatif', visible: true },
  { id: 'soc_yt', platform: 'youtube', url: 'https://youtube.com/@studiokreatif', visible: true },
  { id: 'soc_wa', platform: 'whatsapp', url: 'https://wa.me/6281234567890', visible: true },
  { id: 'soc_th', platform: 'threads', url: 'https://threads.net/@studiokreatif', visible: true },
  { id: 'soc_tw', platform: 'twitter', url: 'https://x.com/studiokreatif', visible: true },
];

export const DEFAULT_CAROUSEL_ITEMS: CarouselItem[] = [
  {
    id: 'car_1',
    image: CAROUSEL_SAMPLE_1_SVG,
    title: 'Koleksi Foto Utama',
    caption: 'Geser ke samping untuk melihat detail produk dan dokumentasi terbaru.',
    url: '',
  },
  {
    id: 'car_2',
    image: CAROUSEL_SAMPLE_2_SVG,
    title: 'Detail Material & Warna',
    caption: 'Tampilan jernih dengan rasio fleksibel 1:1, 4:5, 9:16, hingga 16:9.',
    url: '',
  },
  {
    id: 'car_3',
    image: CAROUSEL_SAMPLE_3_SVG,
    title: 'Promo Spesial Minggu Ini',
    caption: 'Tambahkan tautan pada foto agar pengunjung bisa langsung menuju halaman promo.',
    url: '',
  },
];

export const DEFAULT_SOCIAL_FEED_POSTS: SocialPostItem[] = [
  {
    id: 'sf_post_1',
    mediaType: 'image',
    imageUrl: CAROUSEL_SAMPLE_1_SVG,
    videoUrl: '',
    caption: 'Rilis koleksi terbaru minggu ini! Geser ke samping untuk melihat postingan video & foto lainnya.',
    likes: '1,4 rb',
    comments: '68',
    url: '',
  },
  {
    id: 'sf_post_2',
    mediaType: 'video',
    imageUrl: CAROUSEL_SAMPLE_3_SVG,
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    caption: 'Cuplikan video behind-the-scenes proses pembuatan konten kreatif.',
    likes: '3,2 rb',
    comments: '142',
    url: '',
  },
  {
    id: 'sf_post_3',
    mediaType: 'image',
    imageUrl: CAROUSEL_SAMPLE_2_SVG,
    videoUrl: '',
    caption: 'Tips & panduan lengkap untuk meningkatkan engagement akun sosial media Anda.',
    likes: '980',
    comments: '41',
    url: '',
  },
];

export const DEFAULT_SOCIAL_FOLLOWER_ACCOUNTS: SocialFollowerAccount[] = [
  {
    id: 'sfa_default_1',
    platform: 'instagram',
    avatar: '',
    accountName: 'Studio Kreatif Nusantara',
    handle: '@studiokreatif',
    accountUrl: 'https://instagram.com/studiokreatif',
    verified: true,
    postsCount: '128',
    postsLabel: 'Postingan',
    followers: '45,8 rb',
    followersLabel: 'Follower',
    following: '312',
    followingLabel: 'Mengikuti',
    bio: '',
    followLabel: 'Ikuti',
  },
];

export const BLOCK_TYPE_NAMES: Record<BlockType, string> = {
  row: '2 Kolom',
  container: 'Wadah',
  toggle_container: 'Wadah Show/Hide',
  text: 'Teks Biasa',
  image: 'Gambar',
  button: 'Tombol Link',
  form: 'Form Isian',
  divider: 'Garis Pembatas',
  youtube: 'Video YouTube',
  facebook_video: 'Video Facebook',
  tiktok_video: 'Video TikTok',
  instagram_video: 'Video Instagram',
  catalog: 'Katalog Produk',
  social: 'Sosial Media',
  social_follower: 'Sosial Media + Follower',
  carousel: 'Foto Carousel',
  social_feed: 'Sosmed & Postingan',
  maps_place: 'Lokasi Maps',
  bottom_sheet: 'Bottom Sheet',
};

export function createBlock(type: BlockType, theme: PageTheme = THEMES[0]): BuilderBlock {
  const baseStyle: BlockStyle = {
    ...DEFAULT_STYLE,
    textColor: theme.textColor,
    borderColor: theme.borderColor,
  };

  switch (type) {
    case 'container':
      return {
        id: createId('cnt'),
        type: 'container',
        label: 'Kotak / Wadah',
        style: {
          ...baseStyle,
          minHeight: 80,
          borderRadius: 16,
          backgroundColor: theme.cardBg,
          borderWidth: 1,
          padding: 16,
          shadow: 'sm',
        },
        content: {},
        children: [
          {
            id: createId('txt'),
            type: 'text',
            label: 'Teks Biasa',
            style: {
              ...baseStyle,
              minHeight: 24,
              padding: 4,
              marginBottom: 4,
            },
            content: {
              text: 'Isi konten di dalam wadah ini',
              variant: 'body',
              fontWeight: 'normal',
            },
          },
        ],
      };

    case 'toggle_container':
      return {
        id: createId('tgl'),
        type: 'toggle_container',
        label: 'Wadah Show / Hide',
        style: {
          ...baseStyle,
          minHeight: 56,
          borderRadius: 16,
          backgroundColor: theme.cardBg,
          borderWidth: 1,
          padding: 14,
          shadow: 'sm',
        },
        content: {
          toggleShowLabel: 'Tampilkan Konten',
          toggleHideLabel: 'Sembunyikan Konten',
          toggleDefaultOpen: false,
          toggleButtonBg: theme.accentColor,
          toggleButtonText: '#FFFFFF',
          toggleButtonStyle: 'solid',
        },
        children: [
          {
            id: createId('txt'),
            type: 'text',
            label: 'Teks Isi Wadah',
            style: {
              ...baseStyle,
              minHeight: 24,
              padding: 4,
              marginBottom: 4,
            },
            content: {
              text: 'Konten tersembunyi — bisa diisi teks, gambar, tombol, video, atau elemen lain.',
              variant: 'body',
              fontWeight: 'normal',
            },
          },
        ],
      };

    case 'row':
      return {
        id: createId('row'),
        type: 'row',
        label: '2 Kolom',
        style: {
          ...baseStyle,
          minHeight: 60,
          padding: 4,
        },
        content: {},
        children: [
          {
            id: createId('btn'),
            type: 'button',
            label: 'Tombol Kiri',
            style: { ...baseStyle, minHeight: 44, padding: 0, marginBottom: 0 },
            content: {
              label: 'Portofolio',
              url: 'https://example.com',
              buttonBg: theme.accentColor,
              buttonText: '#FFFFFF',
            },
          },
          {
            id: createId('btn'),
            type: 'button',
            label: 'Tombol Kanan',
            style: { ...baseStyle, minHeight: 44, padding: 0, marginBottom: 0 },
            content: {
              label: 'Hubungi Kami',
              url: 'https://example.com',
              buttonBg: '#0F172A',
              buttonText: '#FFFFFF',
            },
          },
        ],
      };

    case 'text':
      return {
        id: createId('txt'),
        type: 'text',
        label: 'Teks Biasa',
        style: {
          ...baseStyle,
          minHeight: 28,
          padding: 6,
        },
        content: {
          text: 'Judul atau deskripsi singkat halaman Anda',
          variant: 'h2',
          fontWeight: 'bold',
        },
      };

    case 'image':
      return {
        id: createId('img'),
        type: 'image',
        label: 'Gambar',
        style: {
          ...baseStyle,
          minHeight: 120,
          padding: 0,
          borderRadius: 16,
        },
        content: {
          src: PRODUCT_CARD_SVG,
          alt: 'Ilustrasi produk digital',
          aspectRatio: '16/9',
          objectFit: 'cover',
        },
      };

    case 'button':
      return {
        id: createId('btn'),
        type: 'button',
        label: 'Tombol Link',
        style: {
          ...baseStyle,
          minHeight: 46,
          padding: 0,
          borderRadius: 12,
        },
        content: {
          label: 'Buka Tautan Sekarang',
          url: 'https://example.com',
          buttonBg: theme.accentColor,
          buttonText: '#FFFFFF',
        },
      };

    case 'form':
      return {
        id: createId('frm'),
        type: 'form',
        label: 'Form Isian',
        style: {
          ...baseStyle,
          minHeight: 140,
          backgroundColor: theme.cardBg,
          borderWidth: 1,
          borderRadius: 16,
          padding: 16,
          shadow: 'sm',
          align: 'left',
        },
        content: {
          formTitle: 'Dapatkan Update Terbaru',
          namePlaceholder: 'Nama Lengkap',
          emailPlaceholder: 'Alamat Email / WhatsApp',
          submitLabel: 'Kirim Data',
          successMessage: 'Terima kasih! Data Anda telah terkirim.',
          buttonColor: theme.accentColor,
        },
      };

    case 'divider':
      return {
        id: createId('div'),
        type: 'divider',
        label: 'Garis Pembatas',
        style: {
          ...baseStyle,
          minHeight: 16,
          padding: 8,
        },
        content: {
          lineColor: theme.borderColor,
          thickness: 1,
          lineStyle: 'solid',
        },
      };

    case 'youtube':
      return {
        id: createId('ytb'),
        type: 'youtube',
        label: 'Video YouTube',
        style: {
          ...baseStyle,
          minHeight: 160,
          padding: 0,
          borderRadius: 16,
        },
        content: {
          youtubeUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
          youtubeAspectRatio: '16/9',
          youtubeAutoplay: true,
          youtubeVolume: 75,
        },
      };

    case 'facebook_video':
      return {
        id: createId('fbv'),
        type: 'facebook_video',
        label: 'Video Facebook',
        style: {
          ...baseStyle,
          minHeight: 160,
          padding: 0,
          borderRadius: 16,
        },
        content: {
          videoUrl: 'https://www.facebook.com/facebook/videos/10153231379946729/',
          videoAspectRatio: '16/9',
          videoAutoplay: true,
          videoVolume: 75,
        },
      };

    case 'tiktok_video':
      return {
        id: createId('ttv'),
        type: 'tiktok_video',
        label: 'Video TikTok',
        style: {
          ...baseStyle,
          minHeight: 220,
          padding: 0,
          borderRadius: 16,
        },
        content: {
          videoUrl: 'https://www.tiktok.com/@tiktok/video/7106594312292453675',
          videoAspectRatio: '9/16',
          videoAutoplay: true,
          videoVolume: 75,
        },
      };

    case 'instagram_video':
      return {
        id: createId('igv'),
        type: 'instagram_video',
        label: 'Video Instagram',
        style: {
          ...baseStyle,
          minHeight: 220,
          padding: 0,
          borderRadius: 16,
        },
        content: {
          videoUrl: 'https://www.instagram.com/reel/C5vQ8qKvP2x/',
          videoAspectRatio: '9/16',
          videoAutoplay: true,
          videoVolume: 75,
        },
      };

    case 'catalog':
      return {
        id: createId('cat'),
        type: 'catalog',
        label: 'Katalog Produk',
        style: {
          ...baseStyle,
          minHeight: 120,
          padding: 0,
          backgroundColor: 'transparent',
        },
        content: {
          catalogItems: DEFAULT_CATALOG_ITEMS.map((item) => ({
            ...item,
            id: createId('item'),
            gallery: item.gallery ? [...item.gallery] : undefined,
          })),
          catalogProductType: 'physical',
          catalogDetailEnabled: true,
          catalogCartEnabled: true,
          catalogWhatsappNumber: '6281234567890',
          catalogWhatsappIntro: 'Halo, saya ingin memesan produk berikut:',
          catalogAskCustomerInfo: true,
          catalogShippingEnabled: true,
        },
      };

    case 'social':
      return {
        id: createId('soc'),
        type: 'social',
        label: 'Ikon Sosial Media',
        style: {
          ...baseStyle,
          minHeight: 48,
          padding: 8,
          marginBottom: 14,
          backgroundColor: 'transparent',
        },
        content: {
          socialItems: DEFAULT_SOCIAL_ITEMS.map((item) => ({ ...item, id: createId('s') })),
          socialStyle: 'filled',
          socialShape: 'circle',
          socialSize: 'md',
          socialIconSize: 40,
          socialGap: 10,
          socialUseBrandColors: true,
          socialColor: theme.accentColor,
        },
      };

    case 'social_follower':
      return {
        id: createId('sfol'),
        type: 'social_follower',
        label: 'Sosial Media + Follower',
        style: {
          ...baseStyle,
          minHeight: 110,
          padding: 0,
          borderRadius: 18,
          backgroundColor: 'transparent',
          borderWidth: 0,
          shadow: 'none',
          align: 'left',
        },
        content: {
          socialFollowerGap: 10,
          socialFollowerAccounts: DEFAULT_SOCIAL_FOLLOWER_ACCOUNTS.map((acc) => ({
            ...acc,
            id: createId('sfa'),
          })),
        },
      };

    case 'carousel':
      return {
        id: createId('car'),
        type: 'carousel',
        label: 'Galeri Foto Carousel',
        style: {
          ...baseStyle,
          minHeight: 180,
          padding: 0,
          borderRadius: 16,
          align: 'left',
          backgroundColor: 'transparent',
        },
        content: {
          carouselAspectRatio: '4/5',
          carouselObjectFit: 'cover',
          carouselItems: DEFAULT_CAROUSEL_ITEMS.map((item) => ({
            ...item,
            id: createId('slide'),
          })),
        },
      };

    case 'social_feed':
      return {
        id: createId('sfd'),
        type: 'social_feed',
        label: 'Sosmed & Postingan',
        style: {
          ...baseStyle,
          minHeight: 240,
          padding: 14,
          borderRadius: 18,
          backgroundColor: theme.cardBg,
          borderWidth: 1,
          shadow: 'sm',
          align: 'left',
        },
        content: {
          socialFeedPlatform: 'instagram',
          socialFeedAvatar: '',
          socialFeedAccountName: 'Studio Kreatif Nusantara',
          socialFeedHandle: '@studiokreatif',
          socialFeedAccountUrl: 'https://instagram.com/studiokreatif',
          socialFeedVerified: true,
          socialFeedFollowers: '45,8 rb',
          socialFeedFollowersLabel: 'Follower',
          socialFeedBio: '',
          socialFeedFollowLabel: 'Ikuti',
          socialFeedRatio: '4/5',
          socialFeedPosts: DEFAULT_SOCIAL_FEED_POSTS.map((post) => ({
            ...post,
            id: createId('sfp'),
          })),
        },
      };

    case 'maps_place':
      return {
        id: createId('map'),
        type: 'maps_place',
        label: 'Lokasi Maps',
        style: {
          ...baseStyle,
          minHeight: 200,
          padding: 0,
          borderRadius: 16,
          backgroundColor: theme.cardBg,
          borderWidth: 1,
          shadow: 'sm',
          align: 'left',
        },
        content: {
          mapsPhotoUrl: MAPS_LOCATION_SVG,
          mapsPhotoBadgeLabel: 'Lihat foto',
          mapsPhotoRatio: '16/9',
          mapsTitle: 'Diksar Satpam',
          mapsRating: 4.9,
          mapsReviewCount: '1.643',
          mapsService: 'Layanan Satpam',
          mapsAccessible: true,
          mapsServicesList: 'Pelatihan Keamanan, Sertifikasi Resmi, Penyaluran Kerja',
          mapsAddress: 'Buka setiap hari · 08.00 – 17.00 WIB',
          mapsUrl: 'https://maps.google.com',
          mapsButtonLabel: 'Buka di Google Maps',
        },
      };

    case 'bottom_sheet': {
      const mapsChild = createBlock('maps_place', theme);
      return {
        id: createId('bsh'),
        type: 'bottom_sheet',
        label: 'Bottom Sheet Maps',
        style: {
          ...baseStyle,
          minHeight: 56,
          padding: 4,
          backgroundColor: 'transparent',
          borderWidth: 0,
          shadow: 'none',
          align: 'center',
        },
        content: {
          sheetTitle: 'Lokasi & Ulasan',
          sheetTriggerStyle: 'icon',
          sheetTriggerIcon: 'map-pin',
          sheetTriggerLabel: 'Lokasi Maps',
          sheetTriggerSublabel: 'Lihat lokasi & ulasan',
          sheetTriggerBg: theme.accentColor,
          sheetTriggerText: '#FFFFFF',
          sheetIconSize: 52,
        },
        children: [
          {
            ...mapsChild,
            style: {
              ...mapsChild.style,
              marginBottom: 0,
            },
          },
        ],
      };
    }
  }
}

export function createDefaultBottomNavbar(
  theme: PageTheme = THEMES[0],
  enabled = false
): BottomNavbarConfig {
  const galeriCarousel = createBlock('carousel', theme);
  const belanjaCatalog = createBlock('catalog', theme);
  const kontakText = createBlock('text', theme);
  const kontakWa = createBlock('button', theme);
  const kontakSocial = createBlock('social', theme);
  const alamatMaps = createBlock('maps_place', theme);

  const items: BottomNavbarItem[] = [
    {
      id: 'nav_galeri',
      label: 'Galeri',
      icon: 'image',
      enabled: true,
      action: 'sheet',
      sheetTitle: 'Galeri Foto & Karya',
      children: [{ ...galeriCarousel, style: { ...galeriCarousel.style, marginBottom: 0 } }],
    },
    {
      id: 'nav_belanja',
      label: 'Belanja',
      icon: 'shopping-bag',
      enabled: true,
      action: 'sheet',
      sheetTitle: 'Belanja & Produk',
      children: [{ ...belanjaCatalog, style: { ...belanjaCatalog.style, marginBottom: 0 } }],
    },
    {
      id: 'nav_home',
      label: 'Home',
      icon: 'home',
      enabled: true,
      action: 'scroll_top',
      sheetTitle: 'Beranda',
      children: [],
    },
    {
      id: 'nav_kontak',
      label: 'Kontak',
      icon: 'phone',
      enabled: true,
      action: 'sheet',
      sheetTitle: 'Hubungi Kami',
      children: [
        {
          ...kontakText,
          label: 'Info Kontak',
          style: { ...kontakText.style, align: 'left', marginBottom: 10 },
          content: {
            text: 'Pilih saluran tercepat untuk terhubung langsung dengan tim kami.',
            variant: 'body',
            fontWeight: 'normal',
          },
        },
        {
          ...kontakWa,
          label: 'Tombol WhatsApp',
          style: { ...kontakWa.style, marginBottom: 12 },
          content: {
            label: 'Chat via WhatsApp',
            url: 'https://wa.me/6281234567890',
            buttonBg: '#059669',
            buttonText: '#FFFFFF',
            buttonIcon: 'phone',
          },
        },
        {
          ...kontakSocial,
          style: { ...kontakSocial.style, marginBottom: 0 },
        },
      ],
    },
    {
      id: 'nav_alamat',
      label: 'Alamat',
      icon: 'map-pin',
      enabled: true,
      action: 'sheet',
      sheetTitle: 'Alamat & Lokasi Maps',
      children: [{ ...alamatMaps, style: { ...alamatMaps.style, marginBottom: 0 } }],
    },
  ];

  return {
    enabled,
    barBg: theme.cardBg,
    textColor: theme.textColor,
    accentColor: theme.accentColor,
    borderColor: theme.borderColor,
    centerStyle: 'elevated',
    items,
  };
}

export function resolveBottomNavbar(project: BuilderProject): BottomNavbarConfig {
  const existing = project.bottomNavbar;
  if (!existing || !Array.isArray(existing.items) || existing.items.length === 0) {
    return createDefaultBottomNavbar(project.theme, Boolean(existing?.enabled));
  }
  return {
    enabled: Boolean(existing.enabled),
    barBg: existing.barBg || project.theme.cardBg,
    textColor: existing.textColor || project.theme.textColor,
    accentColor: existing.accentColor || project.theme.accentColor,
    borderColor: existing.borderColor || project.theme.borderColor,
    centerStyle: existing.centerStyle === 'inline' ? 'inline' : 'elevated',
    items: existing.items.map((it) => ({
      id: it.id || createId('nav'),
      label: typeof it.label === 'string' ? it.label : 'Menu',
      icon: it.icon || 'info',
      enabled: it.enabled !== false,
      action: it.action === 'scroll_top' ? 'scroll_top' : 'sheet',
      sheetTitle: typeof it.sheetTitle === 'string' ? it.sheetTitle : it.label || 'Info',
      children: Array.isArray(it.children) ? it.children : [],
    })),
  };
}

export interface PrebuiltSection {
  id: string;
  title: string;
  description: string;
  createBlocks: (theme: PageTheme) => BuilderBlock[];
}

export const PREBUILT_SECTIONS: PrebuiltSection[] = [
  {
    id: 'bottom-sheet-maps',
    title: 'Icon Maps → Bottom Sheet',
    description: 'Klik ikon Maps untuk buka Bottom Sheet lokasi & ulasan',
    createBlocks: (theme) => [createBlock('bottom_sheet', theme)],
  },
  {
    id: 'lokasi-maps',
    title: 'Lokasi Maps & Ulasan',
    description: 'Kartu foto lokasi, rating bintang & Google Maps',
    createBlocks: (theme) => [createBlock('maps_place', theme)],
  },
  {
    id: 'sosmed-postingan',
    title: 'Sosmed & Postingan Carousel',
    description: 'Profil akun sosmed & slide postingan foto/video',
    createBlocks: (theme) => [createBlock('social_feed', theme)],
  },
  {
    id: 'foto-carousel',
    title: 'Galeri Foto Carousel',
    description: 'Slide galeri foto geser dengan keterangan',
    createBlocks: (theme) => [createBlock('carousel', theme)],
  },
  {
    id: 'katalog-produk',
    title: 'Katalog Produk',
    description: 'Etalase produk dengan harga & keranjang WA',
    createBlocks: (theme) => [createBlock('catalog', theme)],
  },
  {
    id: 'hero-profile',
    title: 'Hero Profil Kreator',
    description: 'Kartu pembuka dengan logo, judul & bio',
    createBlocks: (theme) => [
      {
        id: createId('cnt'),
        type: 'container',
        label: 'Kartu Profil',
        style: {
          ...DEFAULT_STYLE,
          backgroundColor: theme.cardBg,
          borderColor: theme.borderColor,
          textColor: theme.textColor,
          borderWidth: 1,
          borderRadius: 18,
          padding: 20,
          shadow: 'sm',
          minHeight: 120,
        },
        content: {},
        children: [
          {
            id: createId('img'),
            type: 'image',
            label: 'Foto Profil',
            style: {
              ...DEFAULT_STYLE,
              align: 'center',
              padding: 0,
              borderRadius: 9999,
              borderWidth: 4,
              borderColor: '#FFFFFF',
              shadow: 'md',
              minHeight: 0,
              marginBottom: 14,
            },
            content: {
              src: STARTER_ILLUSTRATION_SVG,
              alt: 'Foto Profil',
              aspectRatio: '1/1',
              objectFit: 'cover',
              imageShape: 'circle',
              circleSize: 112,
              imageZoom: 100,
            },
          },
          {
            id: createId('txt'),
            type: 'text',
            label: 'Nama Brand',
            style: {
              ...DEFAULT_STYLE,
              textColor: theme.textColor,
              useThemeTextColor: true,
              padding: 2,
              minHeight: 24,
              marginBottom: 6,
            },
            content: { text: 'Studio Kreatif Nusantara', variant: 'h1', fontWeight: 'bold' },
          },
          {
            id: createId('txt'),
            type: 'text',
            label: 'Bio Singkat',
            style: {
              ...DEFAULT_STYLE,
              textColor: theme.textColor,
              useThemeTextColor: true,
              padding: 2,
              minHeight: 24,
              marginBottom: 0,
            },
            content: {
              text: 'Template presentasi, aset desain, dan panduan bisnis digital siap pakai.',
              variant: 'body',
              fontWeight: 'normal',
            },
          },
        ],
      },
    ],
  },
  {
    id: 'link-stack',
    title: 'Daftar Tautan Utama',
    description: '3 tombol tautan utama bertumpuk',
    createBlocks: (theme) => [
      {
        ...createBlock('button', theme),
        label: 'Link Toko Utama',
        content: {
          label: 'Katalog Produk Digital',
          url: 'https://example.com/katalog',
          buttonBg: theme.accentColor,
          buttonText: '#FFFFFF',
        },
      },
      {
        ...createBlock('button', theme),
        label: 'Link WhatsApp',
        content: {
          label: 'Konsultasi via WhatsApp',
          url: 'https://wa.me/628123456789',
          buttonBg: '#0F172A',
          buttonText: '#FFFFFF',
        },
      },
      {
        ...createBlock('button', theme),
        label: 'Link Kelas Online',
        content: {
          label: 'Daftar Kelas Desain Mingguan',
          url: 'https://example.com/kelas',
          buttonBg: '#334155',
          buttonText: '#FFFFFF',
        },
      },
    ],
  },
  {
    id: 'digital-product',
    title: 'Kartu Produk Unggulan',
    description: 'Kartu promo satu produk & tombol beli',
    createBlocks: (theme) => [
      {
        id: createId('cnt'),
        type: 'container',
        label: 'Kartu Produk',
        style: {
          ...DEFAULT_STYLE,
          backgroundColor: theme.cardBg,
          borderColor: theme.borderColor,
          textColor: theme.textColor,
          borderWidth: 1,
          borderRadius: 16,
          padding: 16,
          shadow: 'sm',
          align: 'left',
        },
        content: {},
        children: [
          {
            id: createId('img'),
            type: 'image',
            label: 'Banner Produk',
            style: { ...DEFAULT_STYLE, padding: 0, borderRadius: 12, marginBottom: 12, minHeight: 100 },
            content: { src: PRODUCT_CARD_SVG, alt: 'Paket Template UI', aspectRatio: '16/9', objectFit: 'cover' },
          },
          {
            id: createId('txt'),
            type: 'text',
            label: 'Judul Produk',
            style: { ...DEFAULT_STYLE, align: 'left', textColor: theme.textColor, padding: 2, marginBottom: 4, minHeight: 24 },
            content: { text: 'Paket 50+ Template Landing Page', variant: 'h2', fontWeight: 'bold' },
          },
          {
            id: createId('txt'),
            type: 'text',
            label: 'Harga Produk',
            style: { ...DEFAULT_STYLE, align: 'left', textColor: theme.accentColor, padding: 2, marginBottom: 12, minHeight: 20 },
            content: { text: 'Rp 149.000 · Akses Seumur Hidup', variant: 'body', fontWeight: 'semibold' },
          },
          {
            id: createId('btn'),
            type: 'button',
            label: 'Tombol Beli',
            style: { ...DEFAULT_STYLE, padding: 0, marginBottom: 0, borderRadius: 10, minHeight: 44 },
            content: { label: 'Beli Sekarang', url: 'https://example.com/checkout', buttonBg: theme.accentColor, buttonText: '#FFFFFF' },
          },
        ],
      },
    ],
  },
  {
    id: 'contact-lead',
    title: 'Formulir Kontak & Newsletter',
    description: 'Form pengumpulan nama, email & WhatsApp',
    createBlocks: (theme) => [createBlock('form', theme)],
  },
];

export const INITIAL_PROJECT: BuilderProject = {
  title: 'Halaman Kreator Saya',
  theme: THEMES[0],
  advanceOptions: DEFAULT_ADVANCE_OPTIONS,
  blocks: [
    {
      id: 'init_hero_container',
      type: 'container',
      label: 'Kartu Header',
      style: {
        ...DEFAULT_STYLE,
        backgroundColor: '#FFFFFF',
        borderColor: '#E2E8F0',
        borderWidth: 1,
        borderRadius: 18,
        padding: 20,
        marginBottom: 16,
        shadow: 'sm',
        minHeight: 80,
      },
      content: {},
      children: [
        {
          id: 'init_hero_image',
          type: 'image',
          label: 'Gambar Utama',
          style: {
            ...DEFAULT_STYLE,
            padding: 0,
            borderRadius: 14,
            marginBottom: 14,
            minHeight: 140,
          },
          content: {
            src: STARTER_ILLUSTRATION_SVG,
            alt: 'Katalog Produk Digital',
            aspectRatio: '16/9',
            objectFit: 'contain',
          },
        },
        {
          id: 'init_hero_title',
          type: 'text',
          label: 'Judul Utama',
          style: {
            ...DEFAULT_STYLE,
            padding: 4,
            marginBottom: 6,
            minHeight: 28,
            textColor: '#0F172A',
          },
          content: {
            text: 'Studio Kreatif — Katalog Digital',
            variant: 'h1',
            fontWeight: 'bold',
          },
        },
        {
          id: 'init_hero_desc',
          type: 'text',
          label: 'Deskripsi Singkat',
          style: {
            ...DEFAULT_STYLE,
            padding: 4,
            marginBottom: 0,
            minHeight: 24,
            textColor: '#475569',
          },
          content: {
            text: 'Kumpulan template, e-book, dan tautan penting dalam satu halaman mobile yang rapi.',
            variant: 'body',
            fontWeight: 'normal',
          },
        },
      ],
    },
    {
      id: 'init_social_block',
      type: 'social',
      label: 'Ikon Sosial Media',
      style: {
        ...DEFAULT_STYLE,
        padding: 6,
        marginBottom: 16,
        minHeight: 44,
        backgroundColor: 'transparent',
      },
      content: {
        socialItems: DEFAULT_SOCIAL_ITEMS,
        socialStyle: 'filled',
        socialShape: 'circle',
        socialSize: 'md',
        socialIconSize: 40,
        socialGap: 10,
        socialUseBrandColors: true,
        socialColor: '#2563EB',
      },
    },
    {
      id: 'init_catalog_block',
      type: 'catalog',
      label: 'Katalog Produk Digital',
      style: {
        ...DEFAULT_STYLE,
        padding: 0,
        marginBottom: 16,
        minHeight: 100,
      },
      content: {
        catalogItems: DEFAULT_CATALOG_ITEMS,
        catalogProductType: 'physical',
        catalogDetailEnabled: true,
        catalogCartEnabled: true,
        catalogWhatsappNumber: '6281234567890',
        catalogWhatsappIntro: 'Halo, saya ingin memesan produk berikut:',
        catalogAskCustomerInfo: true,
        catalogShippingEnabled: true,
      },
    },
    {
      id: 'init_row_actions',
      type: 'row',
      label: '2 Kolom Tautan',
      style: {
        ...DEFAULT_STYLE,
        padding: 0,
        marginBottom: 16,
        minHeight: 46,
      },
      content: {},
      children: [
        {
          id: 'init_row_btn_1',
          type: 'button',
          label: 'Portofolio',
          style: { ...DEFAULT_STYLE, padding: 0, marginBottom: 0, borderRadius: 12, minHeight: 44 },
          content: {
            label: 'Portofolio',
            url: 'https://example.com/portfolio',
            buttonBg: '#FFFFFF',
            buttonText: '#0F172A',
          },
        },
        {
          id: 'init_row_btn_2',
          type: 'button',
          label: 'Hubungi Kami',
          style: { ...DEFAULT_STYLE, padding: 0, marginBottom: 0, borderRadius: 12, minHeight: 44 },
          content: {
            label: 'WhatsApp',
            url: 'https://wa.me/628123456789',
            buttonBg: '#0F172A',
            buttonText: '#FFFFFF',
          },
        },
      ],
    },
    {
      id: 'init_form_lead',
      type: 'form',
      label: 'Form Newsletter',
      style: {
        ...DEFAULT_STYLE,
        backgroundColor: '#FFFFFF',
        borderColor: '#E2E8F0',
        borderWidth: 1,
        borderRadius: 16,
        padding: 16,
        marginBottom: 8,
        shadow: 'sm',
        align: 'left',
        minHeight: 140,
      },
      content: {
        formTitle: 'Dapatkan E-Book Gratis via Email',
        namePlaceholder: 'Nama Anda',
        emailPlaceholder: 'email@domain.com',
        submitLabel: 'Kirim E-Book',
        successMessage: 'Terima kasih! Tautan unduhan telah dikirim.',
        buttonColor: '#2563EB',
      },
    },
  ],
};
