import {
  BarChart3,
  Code2,
  Copy,
  Download,
  FolderKanban,
  Globe,
  ShieldCheck,
  Smartphone,
  Upload,
} from 'lucide-react';

interface TopBarProps {
  projectTitle: string;
  projectSlug: string;
  isPublished: boolean;
  projectCount: number;
  onChangeTitle: (title: string) => void;
  onOpenProjects: () => void;
  onOpenDomainAndAds: () => void;
  onOpenDashboard: () => void;
  onOpenAccessSettings: () => void;
  isAllSuperAdmin: boolean;
  onOpenImport: () => void;
  onBackup: () => void;
  onCopyHtml: () => void;
  onOpenCode: () => void;
  copied: boolean;
}

export function TopBar({
  projectTitle,
  projectSlug,
  isPublished,
  projectCount,
  onChangeTitle,
  onOpenProjects,
  onOpenDomainAndAds,
  onOpenDashboard,
  onOpenAccessSettings,
  isAllSuperAdmin,
  onOpenImport,
  onBackup,
  onCopyHtml,
  onOpenCode,
  copied,
}: TopBarProps) {
  return (
    <header className="h-14 bg-white border-b border-slate-100 px-3 sm:px-4 flex items-center justify-between gap-2 sm:gap-3 shrink-0 z-20">
      {/* Left: Brand + Unit Usaha */}
      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
        <div className="flex items-center gap-2 shrink-0">
          <div className="w-8 h-8 rounded-xl bg-emerald-500 text-white flex items-center justify-center shadow-xs">
            <Smartphone className="w-4 h-4" />
          </div>
          <span className="font-bold text-slate-800 tracking-tight text-[15px] whitespace-nowrap">
            Lynk Builder
          </span>
        </div>

        <div className="h-5 w-px bg-slate-200/80 hidden sm:block" />

        <div className="flex items-center gap-1.5 min-w-0">
          <button
            type="button"
            onClick={onOpenProjects}
            title="Kelola Daftar Usaha / Proyek"
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-emerald-200/80 bg-[#EFF7F4] hover:bg-emerald-100/70 text-emerald-700 text-[13px] font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <FolderKanban className="w-3.5 h-3.5 text-emerald-600" />
            <span>Usaha ({projectCount})</span>
          </button>

          <input
            type="text"
            value={projectTitle}
            onChange={(e) => onChangeTitle(e.target.value)}
            aria-label="Judul Halaman"
            className="hidden lg:block text-[13px] font-medium text-slate-700 bg-slate-50/80 hover:bg-[#EFF7F4]/60 focus:bg-white border border-transparent focus:border-emerald-300 rounded-xl px-2.5 py-1.5 w-36 xl:w-44 truncate transition-colors outline-none"
          />
        </div>
      </div>

      {/* Right: Dashboard, Domain & Ads, Akses, Import/Backup, Copy HTML */}
      <div className="flex items-center gap-1.5 shrink-0">
        <button
          type="button"
          onClick={onOpenDashboard}
          title="Dashboard Trafik Klik WA & Sumber Iklan"
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-slate-200/90 bg-white text-slate-700 hover:bg-[#EFF7F4] hover:text-emerald-700 hover:border-emerald-200 text-[13px] font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <BarChart3 className="w-3.5 h-3.5 text-emerald-600" />
          <span className="hidden sm:inline">Dashboard WA</span>
        </button>

        <button
          type="button"
          onClick={onOpenDomainAndAds}
          title={`Atur Domain, Slug (/p/${projectSlug}) & Pixel Iklan (${isPublished ? 'Tayang' : 'Draft'})`}
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-slate-200/90 bg-white text-slate-700 hover:bg-[#EFF7F4] hover:text-emerald-700 hover:border-emerald-200 text-[13px] font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Globe className="w-3.5 h-3.5 text-emerald-600" />
          <span className="hidden md:inline">Domain & Iklan</span>
        </button>

        <button
          type="button"
          onClick={onOpenAccessSettings}
          title={
            isAllSuperAdmin
              ? 'Setting Akses: Semua Super Admin (Full Fitur)'
              : 'Setting Akses & Hak Fitur'
          }
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-slate-200/90 bg-white text-slate-700 hover:bg-[#EFF7F4] hover:text-emerald-700 hover:border-emerald-200 text-[13px] font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span className="hidden lg:inline">Akses</span>
        </button>

        <button
          type="button"
          onClick={onOpenImport}
          title="Import Backup .json"
          className="hidden xl:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-slate-200/90 bg-white text-slate-600 hover:bg-[#EFF7F4] hover:text-emerald-700 hover:border-emerald-200 text-[13px] font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Upload className="w-3.5 h-3.5 text-emerald-600" />
          <span>Import</span>
        </button>

        <button
          type="button"
          onClick={onBackup}
          title="Unduh Backup .json"
          className="hidden xl:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-slate-200/90 bg-white text-slate-600 hover:bg-[#EFF7F4] hover:text-emerald-700 hover:border-emerald-200 text-[13px] font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-emerald-600" />
          <span>Backup</span>
        </button>

        <div className="inline-flex items-center rounded-xl overflow-hidden shadow-xs shrink-0">
          <button
            type="button"
            onClick={onCopyHtml}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white text-[13px] font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>{copied ? 'Tersalin!' : 'Copy HTML'}</span>
          </button>
          <button
            type="button"
            onClick={onOpenCode}
            title="Lihat Kode HTML"
            aria-label="Lihat Kode HTML"
            className="px-2 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white border-l border-emerald-400/40 transition-colors cursor-pointer"
          >
            <Code2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
}

