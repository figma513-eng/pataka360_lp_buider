import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  BarChart3,
  Check,
  ChevronDown,
  Copy,
  Download,
  ExternalLink,
  FilePlus2,
  FileUp,
  FolderKanban,
  Globe,
  HardDrive,
  MessageCircle,
  Minus,
  PanelBottomOpen,
  Plus,
  ShoppingBag,
  ShoppingCart,
  Trash2,
  X,
} from 'lucide-react';
import {
  BottomNavbarItem,
  BuilderBlock,
  BuilderProject,
  CatalogItem,
  ProjectRecord,
  WorkspaceBundle,
} from '../types/builder';
import { resolveBottomNavbar } from '../data/presets';
import { generateProjectHtml, resolveBlockTextColor, shadowToCss } from '../utils/htmlExporter';
import { SOCIAL_PLATFORMS, resolveSocialMetrics } from '../utils/socialIcons';
import { resolveButtonIcon } from '../utils/buttonIcons';
import {
  CartEntry,
  CatalogShippingOptionConfig,
  CustomerOrderInfo,
  DEFAULT_SHIPPING_NOTE,
  ShippingMethodId,
  buildWhatsappOrderUrl,
  collectCartPickupNotes,
  createCartEntry,
  formatRupiah,
  normalizeWhatsappNumber,
  parseVariants,
  resolveCartButtonMetrics,
  resolveCatalogShippingOptions,
} from '../utils/cartHelpers';
import { sanitizeExternalUrl } from '../utils/urlHelpers';
import { copyTextToClipboard } from '../utils/clipboardHelpers';
import { DevicePreset } from '../utils/devicePresets';
import { trackAnalyticsEvent } from '../utils/analyticsClient';
import {
  extractWhatsappPhoneFromUrl,
  isWhatsappHref,
  resolveProjectAds,
  resolveProjectPublishing,
} from '../utils/publishingHelpers';
import { ButtonGlyph } from './ButtonIcon';
import { CleanVideoEmbed } from './CleanVideoEmbed';
import { DeviceViewportSelector } from './DeviceViewportSelector';
import { MapsPlaceCard } from './MapsPlaceCard';
import { PhotoCarousel } from './PhotoCarousel';
import { SocialFeedCard } from './SocialFeedCard';
import { SocialFollowerList } from './SocialFollowerList';
import { SocialGlyph } from './SocialIcon';

type PreviewSubPage =
  | { type: 'home' }
  | { type: 'detail'; blockId: string; itemId: string }
  | { type: 'cart'; blockId?: string };

function findBlockById(
  blocks: BuilderBlock[],
  id: string,
  navItems?: BottomNavbarItem[]
): BuilderBlock | null {
  for (const blk of blocks) {
    if (blk.id === id) return blk;
    if (blk.children?.length) {
      const found = findBlockById(blk.children, id);
      if (found) return found;
    }
  }
  if (navItems?.length) {
    for (const item of navItems) {
      const found = findBlockById(item.children, id);
      if (found) return found;
    }
  }
  return null;
}

function findFirstCatalogBlock(
  blocks: BuilderBlock[],
  navItems?: BottomNavbarItem[]
): BuilderBlock | null {
  for (const blk of blocks) {
    if (blk.type === 'catalog') return blk;
    if (blk.children?.length) {
      const found = findFirstCatalogBlock(blk.children);
      if (found) return found;
    }
  }
  if (navItems?.length) {
    for (const item of navItems) {
      const found = findFirstCatalogBlock(item.children);
      if (found) return found;
    }
  }
  return null;
}

export function PreviewModal({
  projectId,
  project,
  onClose,
}: {
  projectId: string;
  project: BuilderProject;
  onClose: () => void;
}) {
  const [submittedForms, setSubmittedForms] = useState<Record<string, boolean>>({});
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>('iphone-16');
  const [previewSize, setPreviewSize] = useState<{ width: number; height: number }>({
    width: 393,
    height: 852,
  });
  const [rotated, setRotated] = useState(false);
  const [customDevices, setCustomDevices] = useState<DevicePreset[]>([]);
  const [openToggles, setOpenToggles] = useState<Record<string, boolean>>({});
  const [activeSheetBlockId, setActiveSheetBlockId] = useState<string | null>(null);
  const [activeNavSheetId, setActiveNavSheetId] = useState<string | null>(null);
  const [sheetEntered, setSheetEntered] = useState(false);
  const [subPage, setSubPage] = useState<PreviewSubPage>({ type: 'home' });
  const [cart, setCart] = useState<CartEntry[]>([]);
  const [detailVariant, setDetailVariant] = useState('');
  const [detailQty, setDetailQty] = useState(1);
  const [detailPhotoIdx, setDetailPhotoIdx] = useState(0);
  const [toastText, setToastText] = useState<string | null>(null);
  const [customer, setCustomer] = useState<CustomerOrderInfo>({
    name: '',
    phone: '',
    address: '',
    notes: '',
    shippingMethod: 'makan_ditempat',
    arrivalTime: '',
    guestCount: '',
    checklistConfirmed: false,
  });
  const scrollBodyRef = useRef<HTMLDivElement>(null);
  const pub = useMemo(() => resolveProjectPublishing(project), [project]);
  const ads = useMemo(() => resolveProjectAds(project), [project]);
  const bottomNavbar = useMemo(() => resolveBottomNavbar(project), [project]);
  const enabledNavItems = useMemo(
    () => bottomNavbar.items.filter((it) => it.enabled !== false),
    [bottomNavbar.items]
  );

  useEffect(() => {
    void trackAnalyticsEvent({
      projectId,
      projectTitle: project.title,
      slug: pub.slug,
      eventType: 'page_view',
      channel: 'organic',
      isTest: true,
    });
  }, [projectId, project.title, pub.slug]);

  useEffect(() => {
    if (!activeSheetBlockId && !activeNavSheetId) {
      setSheetEntered(false);
      return;
    }
    const raf = requestAnimationFrame(() => setSheetEntered(true));
    return () => cancelAnimationFrame(raf);
  }, [activeSheetBlockId, activeNavSheetId]);

  const activeSheetBlock = useMemo(
    () =>
      activeSheetBlockId
        ? findBlockById(project.blocks, activeSheetBlockId, bottomNavbar.items)
        : null,
    [activeSheetBlockId, project.blocks, bottomNavbar.items]
  );

  const activeNavSheetItem = useMemo(
    () =>
      activeNavSheetId
        ? bottomNavbar.items.find((it) => it.id === activeNavSheetId) ?? null
        : null,
    [activeNavSheetId, bottomNavbar.items]
  );

  const activeSheetContent = activeSheetBlock
    ? {
        title: activeSheetBlock.content.sheetTitle?.trim() || 'Bottom Sheet',
        children: activeSheetBlock.children ?? [],
      }
    : activeNavSheetItem
    ? {
        title:
          activeNavSheetItem.sheetTitle?.trim() || activeNavSheetItem.label || 'Menu',
        children: activeNavSheetItem.children,
      }
    : null;

  const openBottomSheet = (blockId: string) => {
    setSheetEntered(false);
    setActiveNavSheetId(null);
    setActiveSheetBlockId(blockId);
  };

  const openNavBottomSheet = (navItemId: string) => {
    setSheetEntered(false);
    setActiveSheetBlockId(null);
    setActiveNavSheetId(navItemId);
  };

  const closeBottomSheet = () => {
    setSheetEntered(false);
    setTimeout(() => {
      setActiveSheetBlockId(null);
      setActiveNavSheetId(null);
    }, 200);
  };

  const scrollToTop = () => {
    scrollBodyRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const showToast = (msg: string) => {
    setToastText(msg);
    setTimeout(() => {
      setToastText((prev) => (prev === msg ? null : prev));
    }, 1800);
  };

  const recordPreviewWaClick = (ctaLabel: string, href: string, orderValue?: number) => {
    void trackAnalyticsEvent({
      projectId,
      projectTitle: project.title,
      slug: pub.slug,
      eventType: 'wa_click',
      channel: ads.waAddonEnabled && ctaLabel.includes('Add-On') ? 'meta_wa_addon' : 'organic',
      ctaLabel,
      waPhone: extractWhatsappPhoneFromUrl(href),
      orderValue,
      isTest: true,
    });
    showToast('Klik WA tercatat di Dashboard (Uji Preview)');
  };

  const openProductDetail = (block: BuilderBlock, item: CatalogItem) => {
    const variants = parseVariants(item.variants);
    setDetailVariant(variants[0] ?? '');
    setDetailQty(1);
    setDetailPhotoIdx(0);
    setSheetEntered(false);
    setActiveSheetBlockId(null);
    setActiveNavSheetId(null);
    setSubPage({ type: 'detail', blockId: block.id, itemId: item.id });
    scrollToTop();
  };

  const openCartPage = (blockId?: string) => {
    setSheetEntered(false);
    setActiveSheetBlockId(null);
    setActiveNavSheetId(null);
    setSubPage({ type: 'cart', blockId });
    scrollToTop();
  };

  const addToCart = (blockId: string, item: CatalogItem, variant: string, qty: number) => {
    const blk = findBlockById(project.blocks, blockId, bottomNavbar.items);
    const blockProductType = blk?.content.catalogProductType ?? 'physical';
    const entry = createCartEntry(blockId, item, variant, qty, blockProductType);
    setCart((prev) => {
      const idx = prev.findIndex((c) => c.key === entry.key);
      if (idx === -1) return [...prev, entry];
      return prev.map((c, i) => (i === idx ? { ...c, qty: c.qty + entry.qty } : c));
    });
    showToast(`"${item.title}" masuk ke keranjang`);
  };

  const updateCartQty = (key: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((c) => (c.key === key ? { ...c, qty: c.qty + delta } : c))
        .filter((c) => c.qty > 0)
    );
  };

  const removeFromCart = (key: string) => {
    setCart((prev) => prev.filter((c) => c.key !== key));
  };

  const totalCartCount = useMemo(
    () => cart.reduce((sum, entry) => sum + entry.qty, 0),
    [cart]
  );

  const totalCartAmount = useMemo(
    () => cart.reduce((sum, entry) => sum + entry.unitPrice * entry.qty, 0),
    [cart]
  );

  const firstCatalog = useMemo(
    () => findFirstCatalogBlock(project.blocks, bottomNavbar.items),
    [project.blocks, bottomNavbar.items]
  );
  const hasCartFeature = Boolean(
    firstCatalog && (firstCatalog.content.catalogCartEnabled ?? true)
  );

  const renderPreviewBlock = (
    block: BuilderBlock,
    depth = 0,
    inheritedTextColor?: string
  ): React.ReactNode => {
    const s = block.style;
    const padX = s.paddingX ?? s.padding;
    const padTop = s.paddingTop ?? s.padding;
    const padBottom = s.paddingBottom ?? s.padding;
    const isCircleImage = block.type === 'image' && block.content.imageShape === 'circle';
    const resolvedTextColor = resolveBlockTextColor(s, project.theme, inheritedTextColor);
    const nextInheritedTextColor =
      s.useThemeTextColor === false
        ? s.textColor
        : s.useThemeTextColor === undefined &&
          s.textColor &&
          s.textColor.trim().toLowerCase() !== project.theme.textColor.trim().toLowerCase()
        ? s.textColor
        : inheritedTextColor;
    const style: React.CSSProperties = {
      width: `${s.widthPercent}%`,
      minHeight: isCircleImage ? '0px' : `${s.minHeight}px`,
      borderRadius: `${s.borderRadius}px`,
      padding: `${padTop}px ${padX}px ${padBottom}px ${padX}px`,
      marginBottom: `${s.marginBottom}px`,
      textAlign: s.align,
      backgroundColor: isCircleImage ? 'transparent' : s.backgroundColor,
      color: resolvedTextColor,
      borderWidth: isCircleImage ? '0px' : `${s.borderWidth}px`,
      borderStyle: !isCircleImage && s.borderWidth > 0 ? 'solid' : 'none',
      borderColor: s.borderColor,
      boxShadow: isCircleImage ? 'none' : shadowToCss(s.shadow, s.shadowColor),
      backdropFilter: !isCircleImage && s.blur > 0 ? `blur(${s.blur}px)` : undefined,
      boxSizing: 'border-box',
      marginLeft: 'auto',
      marginRight: 'auto',
    };

    if (block.type === 'container') {
      return (
        <div key={block.id} style={style}>
          {(block.children ?? []).map((child) =>
            renderPreviewBlock(child, depth + 1, nextInheritedTextColor)
          )}
        </div>
      );
    }

    if (block.type === 'toggle_container') {
      const defaultOpen = Boolean(block.content.toggleDefaultOpen);
      const isOpen = openToggles[block.id] ?? defaultOpen;
      const showLabel = block.content.toggleShowLabel || 'Tampilkan Konten';
      const hideLabel = block.content.toggleHideLabel || showLabel;
      const btnBg = block.content.toggleButtonBg || project.theme.accentColor;
      const btnText = block.content.toggleButtonText || '#FFFFFF';
      const btnStyle = block.content.toggleButtonStyle ?? 'solid';
      const leftIcon = resolveButtonIcon(block.content.toggleButtonIcon, showLabel);

      return (
        <div key={block.id} style={style}>
          <button
            type="button"
            aria-expanded={isOpen}
            onClick={() => setOpenToggles((prev) => ({ ...prev, [block.id]: !isOpen }))}
            style={
              btnStyle === 'outline'
                ? {
                    backgroundColor: 'transparent',
                    color: btnBg,
                    border: `1.5px solid ${btnBg}`,
                    borderRadius: `${Math.min(s.borderRadius, 12)}px`,
                  }
                : {
                    backgroundColor: btnBg,
                    color: btnText,
                    borderRadius: `${Math.min(s.borderRadius, 12)}px`,
                  }
            }
            className="w-full py-2.5 px-3.5 text-sm font-semibold flex items-center justify-between gap-2 cursor-pointer transition-opacity hover:opacity-95"
          >
            <span className="inline-flex items-center gap-2 min-w-0">
              {leftIcon !== 'none' && <ButtonGlyph icon={leftIcon} className="w-4 h-4 shrink-0" />}
              <span className="truncate">{isOpen ? hideLabel : showLabel}</span>
            </span>
            <ChevronDown
              className={`w-4 h-4 shrink-0 transition-transform duration-200 ${
                isOpen ? 'rotate-180' : ''
              }`}
            />
          </button>
          {isOpen && (
            <div className="mt-3">
              {(block.children ?? []).map((child) =>
                renderPreviewBlock(child, depth + 1, nextInheritedTextColor)
              )}
            </div>
          )}
        </div>
      );
    }

    if (block.type === 'bottom_sheet') {
      const triggerStyle = block.content.sheetTriggerStyle ?? 'icon';
      const triggerLabel = block.content.sheetTriggerLabel ?? 'Lokasi Maps';
      const triggerSublabel = block.content.sheetTriggerSublabel ?? '';
      const triggerBg = block.content.sheetTriggerBg || project.theme.accentColor;
      const triggerText = block.content.sheetTriggerText || '#FFFFFF';
      const iconSize = Math.max(36, Math.min(72, block.content.sheetIconSize ?? 52));
      const glyphSize = Math.round(iconSize * 0.44);
      const triggerIcon = resolveButtonIcon(
        block.content.sheetTriggerIcon ?? 'map-pin',
        triggerLabel
      );
      const justifyClass =
        s.align === 'left'
          ? 'justify-start'
          : s.align === 'right'
          ? 'justify-end'
          : 'justify-center';

      return (
        <div key={block.id} style={style} className={`flex ${justifyClass}`}>
          {triggerStyle === 'icon' && (
            <button
              type="button"
              onClick={() => openBottomSheet(block.id)}
              className="inline-flex flex-col items-center gap-1.5 cursor-pointer group"
            >
              <span
                style={{
                  width: `${iconSize}px`,
                  height: `${iconSize}px`,
                  backgroundColor: triggerBg,
                  color: triggerText,
                }}
                className="rounded-full flex items-center justify-center shadow-md transition-transform group-hover:scale-105"
              >
                {triggerIcon !== 'none' ? (
                  <ButtonGlyph
                    icon={triggerIcon}
                    style={{ width: `${glyphSize}px`, height: `${glyphSize}px` }}
                  />
                ) : (
                  <PanelBottomOpen
                    style={{ width: `${glyphSize}px`, height: `${glyphSize}px` }}
                  />
                )}
              </span>
              {triggerLabel.trim() && (
                <span className="text-xs font-semibold leading-tight">{triggerLabel}</span>
              )}
              {triggerSublabel.trim() && (
                <span className="text-[11px] opacity-70 leading-tight">{triggerSublabel}</span>
              )}
            </button>
          )}

          {triggerStyle === 'pill' && (
            <button
              type="button"
              onClick={() => openBottomSheet(block.id)}
              style={{
                backgroundColor: triggerBg,
                color: triggerText,
              }}
              className="inline-flex items-center gap-2.5 px-4 py-2.5 rounded-full shadow-sm cursor-pointer transition-opacity hover:opacity-95"
            >
              {triggerIcon !== 'none' && (
                <ButtonGlyph icon={triggerIcon} className="w-4 h-4 shrink-0" />
              )}
              <span className="text-left min-w-0">
                <span className="block text-xs font-bold leading-tight truncate">
                  {triggerLabel || 'Buka Panel'}
                </span>
                {triggerSublabel.trim() && (
                  <span className="block text-[10px] opacity-85 leading-tight truncate mt-0.5">
                    {triggerSublabel}
                  </span>
                )}
              </span>
            </button>
          )}

          {triggerStyle === 'button' && (
            <button
              type="button"
              onClick={() => openBottomSheet(block.id)}
              style={{
                backgroundColor: triggerBg,
                color: triggerText,
                borderRadius: `${Math.min(s.borderRadius, 14)}px`,
              }}
              className="w-full py-2.5 px-4 text-sm font-semibold flex items-center justify-center gap-2 shadow-sm cursor-pointer transition-opacity hover:opacity-95"
            >
              {triggerIcon !== 'none' && (
                <ButtonGlyph icon={triggerIcon} className="w-4 h-4 shrink-0" />
              )}
              <span className="truncate">{triggerLabel || 'Buka Bottom Sheet'}</span>
            </button>
          )}
        </div>
      );
    }

    if (block.type === 'row') {
      return (
        <div key={block.id} style={style} className="grid grid-cols-2 gap-3 items-stretch">
          {(block.children ?? []).map((child) => (
            <div key={child.id} className="min-w-0">
              {renderPreviewBlock(child, depth + 1, nextInheritedTextColor)}
            </div>
          ))}
        </div>
      );
    }

    if (block.type === 'text') {
      if (!(block.content.text ?? '').trim()) return null;
      return (
        <div
          key={block.id}
          style={style}
          className={`leading-relaxed break-words whitespace-pre-line ${
            block.content.variant === 'h1'
              ? 'text-xl'
              : block.content.variant === 'h2'
              ? 'text-base'
              : 'text-sm'
          } ${
            block.content.fontWeight === 'bold'
              ? 'font-bold'
              : block.content.fontWeight === 'semibold'
              ? 'font-semibold'
              : 'font-normal'
          }`}
        >
          {block.content.text}
        </div>
      );
    }

    if (block.type === 'image') {
      if (block.content.imageShape === 'circle') {
        const circleSize = Math.max(40, Math.min(280, block.content.circleSize ?? 112));
        const imageZoom = Math.max(40, Math.min(250, block.content.imageZoom ?? 100));
        const justifyClass =
          s.align === 'left'
            ? 'justify-start'
            : s.align === 'right'
            ? 'justify-end'
            : 'justify-center';
        return (
          <div key={block.id} style={style} className={`flex ${justifyClass}`}>
            <div
              className="overflow-hidden flex items-center justify-center shrink-0"
              style={{
                width: `${circleSize}px`,
                height: `${circleSize}px`,
                borderRadius: '9999px',
                backgroundColor:
                  s.backgroundColor && s.backgroundColor !== 'transparent'
                    ? s.backgroundColor
                    : '#F1F5F9',
                borderWidth: s.borderWidth > 0 ? `${s.borderWidth}px` : undefined,
                borderStyle: s.borderWidth > 0 ? 'solid' : undefined,
                borderColor: s.borderWidth > 0 ? s.borderColor : undefined,
                boxShadow: shadowToCss(s.shadow, s.shadowColor),
              }}
            >
              <img
                src={block.content.src}
                alt={block.content.alt || 'Foto Profil'}
                referrerPolicy="no-referrer"
                className="w-full h-full block"
                style={{
                  objectFit: block.content.objectFit ?? 'cover',
                  transform: `scale(${imageZoom / 100})`,
                  transformOrigin: 'center center',
                }}
              />
            </div>
          </div>
        );
      }

      return (
        <div key={block.id} style={style} className="overflow-hidden">
          <img
            src={block.content.src}
            alt={block.content.alt || 'Gambar'}
            referrerPolicy="no-referrer"
            className="w-full h-full block"
            style={{
              objectFit: block.content.objectFit ?? 'cover',
              borderRadius: `${s.borderRadius}px`,
              aspectRatio:
                block.content.aspectRatio && block.content.aspectRatio !== 'auto'
                  ? block.content.aspectRatio
                  : undefined,
            }}
          />
        </div>
      );
    }

    if (block.type === 'button') {
      const btnLabel = block.content.label || 'Tautan';
      const leftIcon = resolveButtonIcon(block.content.buttonIcon, btnLabel);
      return (
        <a
          key={block.id}
          href={sanitizeExternalUrl(block.content.url, '#')}
          target="_blank"
          rel="noopener noreferrer"
          style={{
            ...style,
            backgroundColor: block.content.buttonBg ?? project.theme.accentColor,
            color: block.content.buttonText ?? '#FFFFFF',
          }}
          className="flex items-center justify-center gap-2 py-3 px-4 font-semibold text-sm hover:opacity-90 transition-opacity"
        >
          {leftIcon !== 'none' && <ButtonGlyph icon={leftIcon} className="w-4 h-4 shrink-0" />}
          <span>{btnLabel}</span>
          <ExternalLink className="w-3.5 h-3.5 opacity-75 shrink-0" />
        </a>
      );
    }

    if (block.type === 'form') {
      const done = submittedForms[block.id];
      return (
        <form
          key={block.id}
          style={style}
          onSubmit={(e) => {
            e.preventDefault();
            setSubmittedForms((prev) => ({ ...prev, [block.id]: true }));
            void trackAnalyticsEvent({
              projectId,
              projectTitle: project.title,
              slug: pub.slug,
              eventType: 'form_submit',
              ctaLabel: block.content.formTitle || 'Form Isian',
              isTest: true,
            });
          }}
          className="space-y-2.5 text-left"
        >
          <div className="font-bold text-sm">{block.content.formTitle}</div>
          <input
            type="text"
            required
            placeholder={block.content.namePlaceholder}
            className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-slate-900 text-xs outline-none focus:border-blue-500"
          />
          <input
            type="text"
            required
            placeholder={block.content.emailPlaceholder}
            className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-slate-900 text-xs outline-none focus:border-blue-500"
          />
          <button
            type="submit"
            style={{ backgroundColor: block.content.buttonColor ?? project.theme.accentColor }}
            className="w-full py-2.5 px-4 rounded-lg text-white text-xs font-semibold cursor-pointer hover:opacity-90"
          >
            {block.content.submitLabel}
          </button>
          {done && (
            <div className="text-xs font-medium text-emerald-600 pt-1">
              {block.content.successMessage || 'Data berhasil dikirim!'}
            </div>
          )}
        </form>
      );
    }

    if (block.type === 'divider') {
      return (
        <div key={block.id} style={style}>
          <hr
            style={{
              border: 'none',
              borderTopWidth: `${block.content.thickness ?? 1}px`,
              borderTopStyle: block.content.lineStyle ?? 'solid',
              borderTopColor: block.content.lineColor ?? project.theme.borderColor,
            }}
          />
        </div>
      );
    }

    if (
      block.type === 'youtube' ||
      block.type === 'facebook_video' ||
      block.type === 'tiktok_video' ||
      block.type === 'instagram_video'
    ) {
      return (
        <div key={block.id} style={style}>
          <CleanVideoEmbed
            platform={
              block.type === 'facebook_video'
                ? 'facebook'
                : block.type === 'tiktok_video'
                ? 'tiktok'
                : block.type === 'instagram_video'
                ? 'instagram'
                : 'youtube'
            }
            videoUrl={
              block.type === 'youtube'
                ? block.content.youtubeUrl
                : block.content.videoUrl
            }
            posterUrl={block.content.videoPoster}
            aspectRatio={
              block.content.videoAspectRatio ??
              block.content.youtubeAspectRatio ??
              (block.type === 'tiktok_video' || block.type === 'instagram_video' ? '9/16' : '16/9')
            }
            autoPlay={block.content.videoAutoplay ?? block.content.youtubeAutoplay ?? true}
            volume={block.content.videoVolume ?? block.content.youtubeVolume ?? 75}
            borderRadius={s.borderRadius}
            accentColor={project.theme.accentColor}
          />
        </div>
      );
    }

    if (block.type === 'catalog') {
      const layout = project.advanceOptions.blockLayout;
      const showSold = project.advanceOptions.showUnitSold;
      const detailEnabled = block.content.catalogDetailEnabled ?? true;
      const cartEnabled = block.content.catalogCartEnabled ?? true;
      const cartBtn = resolveCartButtonMetrics(block.content.catalogCartButtonSize);

      const handleQuickAdd = (e: React.MouseEvent, item: CatalogItem) => {
        e.preventDefault();
        e.stopPropagation();
        const defaultVar = parseVariants(item.variants)[0] ?? '';
        addToCart(block.id, item, defaultVar, 1);
      };

      const renderBadge = (item: CatalogItem) =>
        item.badge?.trim() ? (
          <span
            className="inline-block px-1.5 py-0.5 rounded text-[9px] font-bold text-white"
            style={{ backgroundColor: project.theme.accentColor }}
          >
            {item.badge.trim()}
          </span>
        ) : null;

      return (
        <div
          key={block.id}
          style={style}
          className={
            layout === 'grid'
              ? 'grid grid-cols-2 gap-2.5 text-left'
              : 'flex flex-col gap-2.5 text-left'
          }
        >
          {(block.content.catalogItems ?? []).map((item) => {
            const soldText = showSold ? ` · ${item.unitSold} terjual` : '';
            const fit = item.imageObjectFit ?? 'cover';
            const ratio = item.imageAspectRatio;
            const ratioStyle = (fallback?: string): React.CSSProperties => ({
              objectFit: fit,
              aspectRatio: ratio === 'auto' ? undefined : ratio ?? fallback,
            });

            if (layout === 'grid') {
              const cardContent = (
                <>
                  {renderBadge(item) && (
                    <div className="absolute top-2 left-2 z-10">{renderBadge(item)}</div>
                  )}
                  <img
                    src={item.image}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    style={ratioStyle('1/1')}
                    className="w-full bg-slate-100"
                  />
                  <div className="p-2.5 space-y-1.5 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="text-xs font-bold line-clamp-2">{item.title}</div>
                      <div
                        className="text-[11px] font-semibold tabular-nums mt-0.5"
                        style={{ color: project.theme.accentColor }}
                      >
                        {item.price}
                        <span className="opacity-70 font-normal">{soldText}</span>
                      </div>
                    </div>
                    {cartEnabled && (
                      <button
                        type="button"
                        onClick={(e) => handleQuickAdd(e, item)}
                        style={{
                          backgroundColor: project.theme.accentColor,
                          padding: cartBtn.gridPadding,
                          fontSize: `${cartBtn.gridFontSize}px`,
                          borderRadius: `${cartBtn.gridRadius}px`,
                          gap: `${cartBtn.gridGap}px`,
                        }}
                        className="w-full font-semibold text-white flex items-center justify-center cursor-pointer hover:opacity-90"
                      >
                        <ShoppingCart
                          style={{
                            width: `${cartBtn.gridIconSize}px`,
                            height: `${cartBtn.gridIconSize}px`,
                          }}
                        />
                        <span>+ Keranjang</span>
                      </button>
                    )}
                  </div>
                </>
              );

              if (detailEnabled) {
                return (
                  <div
                    key={item.id}
                    role="button"
                    tabIndex={0}
                    onClick={() => openProductDetail(block, item)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        openProductDetail(block, item);
                      }
                    }}
                    style={{
                      backgroundColor: project.theme.cardBg,
                      borderColor: project.theme.borderColor,
                    }}
                    className="rounded-xl border overflow-hidden flex flex-col relative hover:opacity-95 cursor-pointer text-left"
                  >
                    {cardContent}
                  </div>
                );
              }

              return (
                <a
                  key={item.id}
                  href={sanitizeExternalUrl(item.url, '#')}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    backgroundColor: project.theme.cardBg,
                    borderColor: project.theme.borderColor,
                  }}
                  className="rounded-xl border overflow-hidden flex flex-col relative hover:opacity-95"
                >
                  {cardContent}
                </a>
              );
            }

            if (layout === 'large-image') {
              const largeContent = (
                <>
                  {renderBadge(item) && (
                    <div className="absolute top-2.5 left-2.5 z-10">{renderBadge(item)}</div>
                  )}
                  <img
                    src={item.image}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    style={ratioStyle('16/10')}
                    className="w-full bg-slate-100"
                  />
                  <div className="p-3 flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <div className="text-xs font-bold truncate">{item.title}</div>
                      <div className="text-[11px] opacity-75 tabular-nums">
                        {item.price}
                        {soldText}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <span
                        className="text-xs font-semibold"
                        style={{ color: project.theme.accentColor }}
                      >
                        {item.ctaLabel}
                      </span>
                      {cartEnabled && (
                        <button
                          type="button"
                          onClick={(e) => handleQuickAdd(e, item)}
                          title="Tambah ke keranjang"
                          style={{
                            backgroundColor: project.theme.accentColor,
                            width: `${cartBtn.iconBoxSize}px`,
                            height: `${cartBtn.iconBoxSize}px`,
                            borderRadius: `${cartBtn.iconBoxRadius}px`,
                          }}
                          className="text-white inline-flex items-center justify-center cursor-pointer hover:opacity-90"
                        >
                          <ShoppingCart
                            style={{
                              width: `${cartBtn.iconOnlySize}px`,
                              height: `${cartBtn.iconOnlySize}px`,
                            }}
                          />
                        </button>
                      )}
                    </div>
                  </div>
                </>
              );

              if (detailEnabled) {
                return (
                  <div
                    key={item.id}
                    role="button"
                    tabIndex={0}
                    onClick={() => openProductDetail(block, item)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        openProductDetail(block, item);
                      }
                    }}
                    style={{
                      backgroundColor: project.theme.cardBg,
                      borderColor: project.theme.borderColor,
                    }}
                    className="rounded-2xl border overflow-hidden block relative hover:opacity-95 cursor-pointer text-left"
                  >
                    {largeContent}
                  </div>
                );
              }

              return (
                <a
                  key={item.id}
                  href={sanitizeExternalUrl(item.url, '#')}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    backgroundColor: project.theme.cardBg,
                    borderColor: project.theme.borderColor,
                  }}
                  className="rounded-2xl border overflow-hidden block relative hover:opacity-95"
                >
                  {largeContent}
                </a>
              );
            }

            if (layout === 'compact') {
              return (
                <div
                  key={item.id}
                  style={{
                    backgroundColor: project.theme.cardBg,
                    borderColor: project.theme.borderColor,
                  }}
                  className="rounded-xl border p-3 space-y-2.5"
                >
                  <div
                    className={`flex items-center gap-2.5 ${detailEnabled ? 'cursor-pointer' : ''}`}
                    onClick={detailEnabled ? () => openProductDetail(block, item) : undefined}
                  >
                    <img
                      src={item.image}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      style={ratioStyle()}
                      className={
                        ratio && ratio !== 'auto'
                          ? 'w-14 rounded-lg bg-slate-100 shrink-0'
                          : 'w-12 h-12 rounded-lg bg-slate-100 shrink-0'
                      }
                    />
                    <div className="min-w-0 flex-1">
                      {renderBadge(item) && <div className="mb-0.5">{renderBadge(item)}</div>}
                      <div className="text-xs font-bold truncate">{item.title}</div>
                      <div className="text-[11px] opacity-75 tabular-nums">
                        {item.price}
                        {soldText}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {detailEnabled ? (
                      <button
                        type="button"
                        onClick={() => openProductDetail(block, item)}
                        style={{ backgroundColor: project.theme.accentColor }}
                        className="flex-1 py-2 px-3 rounded-lg text-center text-xs font-semibold text-white cursor-pointer hover:opacity-95"
                      >
                        {item.ctaLabel}
                      </button>
                    ) : (
                      <a
                        href={sanitizeExternalUrl(item.url, '#')}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{ backgroundColor: project.theme.accentColor }}
                        className="flex-1 block py-2 px-3 rounded-lg text-center text-xs font-semibold text-white"
                      >
                        {item.ctaLabel}
                      </a>
                    )}
                    {cartEnabled && (
                      <button
                        type="button"
                        onClick={(e) => handleQuickAdd(e, item)}
                        title="Tambah ke keranjang"
                        style={{
                          borderColor: project.theme.accentColor,
                          color: project.theme.accentColor,
                          padding: cartBtn.compactPadding,
                          borderRadius: `${cartBtn.compactRadius}px`,
                        }}
                        className="border text-xs font-semibold flex items-center justify-center cursor-pointer hover:opacity-80 shrink-0"
                      >
                        <ShoppingCart
                          style={{
                            width: `${cartBtn.compactIconSize}px`,
                            height: `${cartBtn.compactIconSize}px`,
                          }}
                        />
                      </button>
                    )}
                  </div>
                </div>
              );
            }

            // default layout
            const defaultBody = (
              <>
                <img
                  src={item.image}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  style={ratioStyle()}
                  className={
                    ratio && ratio !== 'auto'
                      ? 'w-16 rounded-lg bg-slate-100 shrink-0'
                      : 'w-14 h-14 rounded-lg bg-slate-100 shrink-0'
                  }
                />
                <div className="min-w-0 flex-1">
                  {renderBadge(item) && <div className="mb-0.5">{renderBadge(item)}</div>}
                  <div className="text-xs font-bold truncate">{item.title}</div>
                  <div className="text-[11px] opacity-70 truncate">{item.subtitle}</div>
                  <div
                    className="text-[11px] font-semibold mt-1 tabular-nums"
                    style={{ color: project.theme.accentColor }}
                  >
                    {item.price}
                    <span className="opacity-70 font-normal">{soldText}</span>
                  </div>
                </div>
                {cartEnabled && (
                  <button
                    type="button"
                    onClick={(e) => handleQuickAdd(e, item)}
                    title="Tambah ke keranjang"
                    style={{
                      backgroundColor: project.theme.accentColor,
                      width: `${cartBtn.iconBoxSize}px`,
                      height: `${cartBtn.iconBoxSize}px`,
                      borderRadius: `${cartBtn.iconBoxRadius}px`,
                    }}
                    className="text-white flex items-center justify-center shrink-0 cursor-pointer hover:opacity-90"
                  >
                    <ShoppingCart
                      style={{
                        width: `${cartBtn.iconOnlySize}px`,
                        height: `${cartBtn.iconOnlySize}px`,
                      }}
                    />
                  </button>
                )}
              </>
            );

            if (detailEnabled) {
              return (
                <div
                  key={item.id}
                  role="button"
                  tabIndex={0}
                  onClick={() => openProductDetail(block, item)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      openProductDetail(block, item);
                    }
                  }}
                  style={{
                    backgroundColor: project.theme.cardBg,
                    borderColor: project.theme.borderColor,
                  }}
                  className="rounded-xl border p-2.5 flex items-center gap-3 hover:opacity-95 cursor-pointer text-left"
                >
                  {defaultBody}
                </div>
              );
            }

            return (
              <a
                key={item.id}
                href={sanitizeExternalUrl(item.url, '#')}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  backgroundColor: project.theme.cardBg,
                  borderColor: project.theme.borderColor,
                }}
                className="rounded-xl border p-2.5 flex items-center gap-3 hover:opacity-95"
              >
                {defaultBody}
              </a>
            );
          })}
        </div>
      );
    }

    if (block.type === 'social') {
      const visibleItems = (block.content.socialItems ?? []).filter((item) => item.visible);
      if (visibleItems.length === 0) return null;

      const socialStyle = block.content.socialStyle ?? 'filled';
      const socialShape = block.content.socialShape ?? 'circle';
      const { boxSize, iconSize, gap } = resolveSocialMetrics(block.content);
      const useBrand = block.content.socialUseBrandColors ?? true;
      const customColor = block.content.socialColor ?? project.theme.accentColor;

      const justifyClass =
        s.align === 'left'
          ? 'justify-start'
          : s.align === 'right'
          ? 'justify-end'
          : 'justify-center';

      const shapeClass = socialShape === 'rounded' ? 'rounded-xl' : 'rounded-full';

      return (
        <div
          key={block.id}
          style={{ ...style, gap: `${gap}px` }}
          className={`flex flex-wrap items-center ${justifyClass}`}
        >
          {visibleItems.map((item) => {
            const meta = SOCIAL_PLATFORMS[item.platform];
            const activeColor = useBrand ? meta.brandColor : customColor;
            const itemStyle: React.CSSProperties = {
              width: `${boxSize}px`,
              height: `${boxSize}px`,
              ...(socialStyle === 'filled'
                ? { backgroundColor: activeColor, color: '#FFFFFF' }
                : socialStyle === 'outline'
                ? {
                    backgroundColor: 'transparent',
                    color: activeColor,
                    border: `1.5px solid ${activeColor}`,
                  }
                : { backgroundColor: 'transparent', color: activeColor }),
            };

            return (
              <a
                key={item.id}
                href={sanitizeExternalUrl(item.url, '#')}
                target="_blank"
                rel="noopener noreferrer"
                title={meta.label}
                aria-label={meta.label}
                style={itemStyle}
                className={`${shapeClass} inline-flex items-center justify-center hover:opacity-85 transition-opacity shrink-0`}
              >
                <SocialGlyph
                  platform={item.platform}
                  className=""
                  style={{ width: `${iconSize}px`, height: `${iconSize}px` }}
                />
              </a>
            );
          })}
        </div>
      );
    }

    if (block.type === 'social_follower') {
      return (
        <div key={block.id} style={style}>
          <SocialFollowerList
            accounts={block.content.socialFollowerAccounts ?? []}
            gap={block.content.socialFollowerGap ?? 10}
            borderRadius={s.borderRadius}
            cardBg={
              s.backgroundColor && s.backgroundColor !== 'transparent'
                ? s.backgroundColor
                : project.theme.cardBg
            }
            borderColor={s.borderWidth > 0 ? s.borderColor : project.theme.borderColor}
            textColor={resolvedTextColor}
          />
        </div>
      );
    }

    if (block.type === 'carousel') {
      return (
        <div key={block.id} style={style}>
          <PhotoCarousel
            items={block.content.carouselItems ?? []}
            aspectRatio={block.content.carouselAspectRatio ?? '4/5'}
            objectFit={block.content.carouselObjectFit ?? 'cover'}
            borderRadius={s.borderRadius}
            cardBg={project.theme.cardBg}
            borderColor={project.theme.borderColor}
            textColor={resolvedTextColor}
            accentColor={project.theme.accentColor}
            align={s.align}
          />
        </div>
      );
    }

    if (block.type === 'social_feed') {
      return (
        <div key={block.id} style={style}>
          <SocialFeedCard
            platform={block.content.socialFeedPlatform ?? 'instagram'}
            avatar={block.content.socialFeedAvatar}
            accountName={block.content.socialFeedAccountName ?? 'Studio Kreatif'}
            handle={block.content.socialFeedHandle ?? '@studiokreatif'}
            accountUrl={block.content.socialFeedAccountUrl}
            verified={block.content.socialFeedVerified ?? true}
            followers={block.content.socialFeedFollowers}
            followersLabel={block.content.socialFeedFollowersLabel}
            bio={block.content.socialFeedBio}
            followLabel={block.content.socialFeedFollowLabel}
            aspectRatio={block.content.socialFeedRatio ?? '4/5'}
            posts={block.content.socialFeedPosts ?? []}
            borderRadius={s.borderRadius}
            borderColor={project.theme.borderColor}
            textColor={resolvedTextColor}
            accentColor={project.theme.accentColor}
          />
        </div>
      );
    }

    if (block.type === 'maps_place') {
      return (
        <div key={block.id} style={style}>
          <MapsPlaceCard
            photoUrl={block.content.mapsPhotoUrl ?? ''}
            photoBadgeLabel={block.content.mapsPhotoBadgeLabel}
            photoRatio={block.content.mapsPhotoRatio}
            title={block.content.mapsTitle ?? 'Nama Lokasi'}
            rating={block.content.mapsRating}
            reviewCount={block.content.mapsReviewCount}
            service={block.content.mapsService}
            accessible={block.content.mapsAccessible}
            servicesList={block.content.mapsServicesList}
            address={block.content.mapsAddress}
            mapsUrl={block.content.mapsUrl}
            buttonLabel={block.content.mapsButtonLabel}
            borderRadius={s.borderRadius}
            textColor={resolvedTextColor}
            borderColor={project.theme.borderColor}
            accentColor={project.theme.accentColor}
            align={s.align}
          />
        </div>
      );
    }

    return null;
  };

  const detailContext = useMemo(() => {
    if (subPage.type !== 'detail') return null;
    const blk = findBlockById(project.blocks, subPage.blockId, bottomNavbar.items);
    const item = blk?.content.catalogItems?.find((it) => it.id === subPage.itemId);
    if (!blk || !item) return null;
    return { block: blk, item };
  }, [project.blocks, bottomNavbar.items, subPage]);

  const activeCartBlock = useMemo(() => {
    const refBlockId =
      (subPage.type === 'cart' ? subPage.blockId : undefined) ?? cart[0]?.blockId;
    if (refBlockId) {
      const found = findBlockById(project.blocks, refBlockId, bottomNavbar.items);
      if (found) return found;
    }
    return firstCatalog;
  }, [subPage, cart, project.blocks, bottomNavbar.items, firstCatalog]);

  const activeWaPhone = activeCartBlock?.content.catalogWhatsappNumber;
  const activeStoreName =
    activeCartBlock?.content.catalogStoreName?.trim() || project.title;
  const activeWaIntro = activeCartBlock?.content.catalogWhatsappIntro;
  const activeAskCustomerInfo = activeCartBlock?.content.catalogAskCustomerInfo ?? true;
  const activeShippingEnabled = activeCartBlock?.content.catalogShippingEnabled ?? true;
  const resolvedShippingOptions = useMemo(
    () => resolveCatalogShippingOptions(activeCartBlock?.content),
    [activeCartBlock]
  );
  const enabledShippingOptions = useMemo(
    () => resolvedShippingOptions.filter((opt) => opt.enabled !== false),
    [resolvedShippingOptions]
  );
  const activeSelectedShipIdx = useMemo(() => {
    const idx = enabledShippingOptions.findIndex(
      (o) => o.id === (customer.shippingMethod ?? 'makan_ditempat')
    );
    return idx >= 0 ? idx : 0;
  }, [enabledShippingOptions, customer.shippingMethod]);
  const activeSelectedShipOpt = enabledShippingOptions[activeSelectedShipIdx];

  const hasPhysicalItemInCart = useMemo(
    () => cart.some((entry) => entry.productType === 'physical'),
    [cart]
  );
  const shouldShowChoices =
    activeShippingEnabled && hasPhysicalItemInCart && enabledShippingOptions.length > 0;
  const combinedPickupNote = useMemo(
    () => collectCartPickupNotes(cart).join('; '),
    [cart]
  );

  const cartStoreGroups = useMemo(() => {
    if (cart.length === 0) return [];
    const groupsMap = new Map<
      string,
      {
        normalizedPhone: string;
        rawPhone?: string;
        storeName: string;
        intro?: string;
        askCustomerInfo: boolean;
        shippingEnabled: boolean;
        shippingOptions: CatalogShippingOptionConfig[];
        shippingNote: string;
        pickupNote?: string;
        entries: CartEntry[];
      }
    >();

    for (const entry of cart) {
      const blk = findBlockById(project.blocks, entry.blockId, bottomNavbar.items) ?? firstCatalog;
      const rawPhone = blk?.content.catalogWhatsappNumber;
      const normalizedPhone = normalizeWhatsappNumber(rawPhone);
      const existing = groupsMap.get(normalizedPhone);
      if (existing) {
        existing.entries.push(entry);
      } else {
        groupsMap.set(normalizedPhone, {
          normalizedPhone,
          rawPhone,
          storeName: blk?.content.catalogStoreName?.trim() || project.title,
          intro: blk?.content.catalogWhatsappIntro,
          askCustomerInfo: blk?.content.catalogAskCustomerInfo ?? true,
          shippingEnabled: blk?.content.catalogShippingEnabled ?? true,
          shippingOptions: resolveCatalogShippingOptions(blk?.content),
          shippingNote: blk?.content.catalogShippingNote?.trim() || DEFAULT_SHIPPING_NOTE,
          pickupNote: blk?.content.catalogPickupNote,
          entries: [entry],
        });
      }
    }

    return Array.from(groupsMap.values()).map((grp) => {
      const hasPhysical = grp.entries.some((e) => e.productType === 'physical');
      const grpEnabledOpts = grp.shippingOptions.filter((o) => o.enabled !== false);
      const showChoices = grp.shippingEnabled && hasPhysical && grpEnabledOpts.length > 0;
      const selIdxRaw = grpEnabledOpts.findIndex(
        (o) => o.id === (customer.shippingMethod ?? 'makan_ditempat')
      );
      const selIdx = selIdxRaw >= 0 ? selIdxRaw : 0;
      const selOpt = grpEnabledOpts[selIdx];
      const grpPickupNote = collectCartPickupNotes(grp.entries).join('; ');
      const customerPayload: Partial<CustomerOrderInfo> | undefined =
        grp.askCustomerInfo || showChoices
          ? {
              ...(grp.askCustomerInfo
                ? {
                    name: customer.name,
                    phone: customer.phone,
                    address: customer.address,
                    notes: customer.notes,
                  }
                : {}),
              ...(showChoices && selOpt
                ? {
                    shippingMethod: selOpt.id,
                    shippingOptionNumber: selIdx + 1,
                    shippingOptionLabel: selOpt.label,
                    arrivalTimeLabel: selOpt.askArrivalTime
                      ? selOpt.arrivalTimeLabel || 'Waktu'
                      : undefined,
                    arrivalTime: selOpt.askArrivalTime ? customer.arrivalTime : undefined,
                    guestCountLabel: selOpt.askGuestCount
                      ? selOpt.guestCountLabel || 'Jumlah Orang'
                      : undefined,
                    guestCount: selOpt.askGuestCount ? customer.guestCount : undefined,
                    checklistConfirmed: selOpt.checklistEnabled
                      ? customer.checklistConfirmed
                      : undefined,
                    checklistText: selOpt.checklistEnabled ? selOpt.checklistText : undefined,
                    pickupNote:
                      selOpt.id === 'ambil_sendiri' ? grpPickupNote || undefined : undefined,
                    shippingNoteTitle: selOpt.noteTitle || 'Catatan:',
                    shippingNote: selOpt.noteText?.trim() || undefined,
                  }
                : {}),
            }
          : undefined;
      return {
        ...grp,
        waUrl: buildWhatsappOrderUrl({
          phone: grp.rawPhone,
          storeName: grp.storeName,
          intro: grp.intro,
          items: grp.entries,
          customer: customerPayload,
        }),
      };
    });
  }, [cart, project.blocks, bottomNavbar.items, project.title, firstCatalog, customer]);

  const cartWaUrl = cartStoreGroups[0]?.waUrl ?? '#';

  const isWidePreview = previewSize.width >= 720;
  const containerPaddingClass = isWidePreview
    ? 'max-w-[680px] mx-auto px-4 sm:px-6'
    : 'px-4 sm:px-6';

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{ width: `min(${previewSize.width}px, 96vw)`, height: `min(${previewSize.height}px, 90vh)` }}
        className={`flex flex-col bg-white shadow-2xl border border-slate-200 transition-all relative ${
          isWidePreview ? 'rounded-2xl' : 'rounded-3xl'
        }`}
      >
        <div className="px-3 sm:px-4 py-2 border-b border-slate-200 flex items-center justify-between gap-2 bg-slate-50 shrink-0 flex-wrap rounded-t-[inherit] relative z-20">
          <div className="flex items-center gap-2 min-w-0">
            {subPage.type !== 'home' && (
              <button
                type="button"
                onClick={() => {
                  setSubPage({ type: 'home' });
                  scrollToTop();
                }}
                className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-white border border-slate-200 text-[11px] font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer shrink-0"
              >
                <ArrowLeft className="w-3 h-3" />
                <span>Halaman Utama</span>
              </button>
            )}
            <div className="text-xs font-bold text-slate-700 truncate">
              {subPage.type === 'detail'
                ? 'Detail Produk'
                : subPage.type === 'cart'
                ? 'Keranjang WA'
                : `Pratinjau · ${project.title}`}
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0 flex-wrap">
            {hasCartFeature && (
              <button
                type="button"
                onClick={() => openCartPage()}
                title="Buka Keranjang Belanja"
                className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-semibold cursor-pointer transition-colors"
              >
                <ShoppingCart className="w-3.5 h-3.5" />
                <span className="tabular-nums">{totalCartCount}</span>
              </button>
            )}

            <DeviceViewportSelector
              selectedDeviceId={selectedDeviceId}
              width={previewSize.width}
              height={previewSize.height}
              rotated={rotated}
              customDevices={customDevices}
              onSelectDevice={(dev) => {
                setSelectedDeviceId(dev.id);
                setRotated(false);
                setPreviewSize({ width: dev.width, height: dev.height });
              }}
              onChangeDimensions={(w, h) => {
                setSelectedDeviceId('responsive');
                setPreviewSize({ width: w, height: h });
              }}
              onToggleRotate={() => {
                setRotated((prev) => !prev);
                setPreviewSize((prev) => ({ width: prev.height, height: prev.width }));
              }}
              onAddCustomDevice={(dev) => setCustomDevices((prev) => [...prev, dev])}
              compact
              menuAlign="right"
            />

            <button
              type="button"
              onClick={onClose}
              className="p-1 rounded-lg hover:bg-slate-200 text-slate-500 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 min-h-0 relative overflow-hidden flex flex-col rounded-b-[inherit]">
          <div
            ref={scrollBodyRef}
            onClickCapture={(e) => {
              const target = e.target as HTMLElement | null;
              const anchor = target?.closest?.('a[href]') as HTMLAnchorElement | null;
              if (!anchor) return;
              const href = anchor.getAttribute('href') || '';
              if (!isWhatsappHref(href)) return;
              if (anchor.dataset.waTracked === '1') return;
              const label =
                anchor.getAttribute('data-wa-label') ||
                anchor.textContent?.trim().slice(0, 60) ||
                'Tombol WhatsApp';
              recordPreviewWaClick(label, href);
            }}
            className="flex-1 overflow-y-auto relative"
          style={{
            backgroundColor: project.theme.canvasBg,
            color: project.theme.textColor,
            paddingTop: `${
              project.advanceOptions.pageTopPadding ??
              (project.blocks[0]?.style.fullBleed ? 0 : 12)
            }px`,
            paddingBottom: isWidePreview ? '32px' : '24px',
          }}
        >
          {subPage.type === 'home' && (
            <div className={`w-full ${totalCartCount > 0 && hasCartFeature ? 'pb-16' : ''}`}>
              {project.blocks.map((block) => (
                <div
                  key={block.id}
                  className={
                    block.style.fullBleed
                      ? 'w-full px-0'
                      : containerPaddingClass
                  }
                >
                  {renderPreviewBlock(block, 0)}
                </div>
              ))}
            </div>
          )}

          {subPage.type === 'detail' && detailContext && (() => {
            const { block, item } = detailContext;
            const cartEnabled = block.content.catalogCartEnabled ?? true;
            const variants = parseVariants(item.variants);
            const activeVariant =
              variants.includes(detailVariant) ? detailVariant : variants[0] ?? '';
            const photos = [item.image, ...(item.gallery ?? [])].filter(Boolean);
            const safePhotoIdx = Math.min(detailPhotoIdx, Math.max(0, photos.length - 1));
            const blockProductType = block.content.catalogProductType ?? 'physical';
            const singleEntry = createCartEntry(
              block.id,
              item,
              activeVariant,
              detailQty,
              blockProductType
            );
            const directWaUrl = buildWhatsappOrderUrl({
              phone: block.content.catalogWhatsappNumber,
              storeName: block.content.catalogStoreName?.trim() || project.title,
              intro: block.content.catalogWhatsappIntro,
              items: [singleEntry],
            });

            return (
              <div className={`w-full ${containerPaddingClass} ${totalCartCount > 0 && cartEnabled ? 'pb-20' : 'pb-6'} space-y-4`}>
                <div className="flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setSubPage({ type: 'home' });
                      scrollToTop();
                    }}
                    style={{
                      backgroundColor: project.theme.cardBg,
                      borderColor: project.theme.borderColor,
                      color: project.theme.textColor,
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold cursor-pointer hover:opacity-90"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Kembali</span>
                  </button>

                  {cartEnabled && (
                    <button
                      type="button"
                      onClick={() => openCartPage(block.id)}
                      style={{
                        backgroundColor: project.theme.cardBg,
                        borderColor: project.theme.borderColor,
                        color: project.theme.textColor,
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold cursor-pointer hover:opacity-90"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                      <span>Keranjang ({totalCartCount})</span>
                    </button>
                  )}
                </div>

                {/* Product Photo & Gallery */}
                <div
                  style={{
                    backgroundColor: project.theme.cardBg,
                    borderColor: project.theme.borderColor,
                  }}
                  className="rounded-2xl border overflow-hidden"
                >
                  <div className="relative bg-slate-100">
                    {item.badge?.trim() && (
                      <span
                        className="absolute top-3 left-3 z-10 px-2.5 py-1 rounded-lg text-[11px] font-bold text-white shadow-xs"
                        style={{ backgroundColor: project.theme.accentColor }}
                      >
                        {item.badge.trim()}
                      </span>
                    )}
                    <img
                      src={photos[safePhotoIdx] || item.image}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      className="w-full aspect-4/3 object-cover block"
                    />
                  </div>
                  {photos.length > 1 && (
                    <div className="p-2.5 flex items-center gap-2 overflow-x-auto border-t" style={{ borderColor: project.theme.borderColor }}>
                      {photos.map((pSrc, pIdx) => (
                        <button
                          key={`${item.id}_p_${pIdx}`}
                          type="button"
                          onClick={() => setDetailPhotoIdx(pIdx)}
                          style={{
                            borderColor:
                              pIdx === safePhotoIdx
                                ? project.theme.accentColor
                                : project.theme.borderColor,
                          }}
                          className={`w-14 h-14 rounded-lg overflow-hidden border-2 shrink-0 cursor-pointer transition-opacity ${
                            pIdx === safePhotoIdx ? 'opacity-100' : 'opacity-65 hover:opacity-100'
                          }`}
                        >
                          <img src={pSrc} alt="" className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Product Info */}
                <div
                  style={{
                    backgroundColor: project.theme.cardBg,
                    borderColor: project.theme.borderColor,
                  }}
                  className="rounded-2xl border p-4 space-y-3.5"
                >
                  <div>
                    <h2 className="text-lg font-bold leading-snug">{item.title}</h2>
                    {item.subtitle && (
                      <p className="text-xs opacity-75 mt-1">{item.subtitle}</p>
                    )}
                    <div className="flex items-baseline gap-2 mt-2">
                      <span
                        className="text-lg font-bold tabular-nums"
                        style={{ color: project.theme.accentColor }}
                      >
                        {item.price}
                      </span>
                      {project.advanceOptions.showUnitSold && (
                        <span className="text-xs opacity-65 tabular-nums">
                          · {item.unitSold} terjual
                        </span>
                      )}
                    </div>
                  </div>

                  {variants.length > 0 && (
                    <div className="space-y-1.5 pt-2 border-t" style={{ borderColor: project.theme.borderColor }}>
                      <div className="text-xs font-semibold opacity-80">Pilih Varian:</div>
                      <div className="flex flex-wrap gap-1.5">
                        {variants.map((v) => {
                          const selected = v === activeVariant;
                          return (
                            <button
                              key={v}
                              type="button"
                              onClick={() => setDetailVariant(v)}
                              style={
                                selected
                                  ? {
                                      backgroundColor: project.theme.accentColor,
                                      borderColor: project.theme.accentColor,
                                      color: '#FFFFFF',
                                    }
                                  : {
                                      backgroundColor: 'transparent',
                                      borderColor: project.theme.borderColor,
                                      color: project.theme.textColor,
                                    }
                              }
                              className="px-3 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer transition-colors"
                            >
                              {v}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {cartEnabled && (
                    <div className="flex items-center justify-between pt-2 border-t" style={{ borderColor: project.theme.borderColor }}>
                      <span className="text-xs font-semibold opacity-80">Jumlah</span>
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setDetailQty((q) => Math.max(1, q - 1))}
                          style={{ borderColor: project.theme.borderColor }}
                          className="w-8 h-8 rounded-lg border flex items-center justify-center cursor-pointer hover:opacity-80"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="w-8 text-center text-sm font-bold tabular-nums">
                          {detailQty}
                        </span>
                        <button
                          type="button"
                          onClick={() => setDetailQty((q) => q + 1)}
                          style={{ borderColor: project.theme.borderColor }}
                          className="w-8 h-8 rounded-lg border flex items-center justify-center cursor-pointer hover:opacity-80"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}

                  {item.description?.trim() && (
                    <div className="pt-2 border-t space-y-1" style={{ borderColor: project.theme.borderColor }}>
                      <div className="text-xs font-semibold opacity-80">Deskripsi Produk</div>
                      <div className="text-xs leading-relaxed opacity-90 whitespace-pre-line">
                        {item.description}
                      </div>
                    </div>
                  )}

                  <div className="pt-2 space-y-2">
                    {cartEnabled && (
                      <>
                        <button
                          type="button"
                          onClick={() => addToCart(block.id, item, activeVariant, detailQty)}
                          style={{ backgroundColor: project.theme.accentColor }}
                          className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-2 cursor-pointer hover:opacity-95"
                        >
                          <ShoppingCart className="w-4 h-4" />
                          <span>Tambah ke Keranjang</span>
                        </button>
                        <a
                          href={directWaUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          data-wa-tracked="1"
                          onClick={() =>
                            recordPreviewWaClick(
                              `Pesan Langsung: ${item.title} x${detailQty}`,
                              directWaUrl,
                              singleEntry.unitPrice * detailQty
                            )
                          }
                          className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 flex items-center justify-center gap-2 transition-colors"
                        >
                          <MessageCircle className="w-4 h-4" />
                          <span>Pesan Langsung via WhatsApp</span>
                        </a>
                      </>
                    )}

                    {item.url && !item.url.startsWith('https://example.com') && sanitizeExternalUrl(item.url, '') && (
                      <a
                        href={sanitizeExternalUrl(item.url, '#')}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{
                          borderColor: project.theme.borderColor,
                          color: project.theme.textColor,
                        }}
                        className="w-full py-2.5 px-4 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 hover:opacity-85"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>{cartEnabled ? 'Kunjungi Tautan Produk' : item.ctaLabel || 'Buka Tautan'}</span>
                      </a>
                    )}
                  </div>
                </div>
              </div>
            );
          })()}

          {subPage.type === 'cart' && (
            <div className={`w-full ${containerPaddingClass} pb-8 space-y-4`}>
              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setSubPage({ type: 'home' });
                    scrollToTop();
                  }}
                  style={{
                    backgroundColor: project.theme.cardBg,
                    borderColor: project.theme.borderColor,
                    color: project.theme.textColor,
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold cursor-pointer hover:opacity-90"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Kembali</span>
                </button>
                {cart.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setCart([])}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold text-red-600 hover:bg-red-500/10 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Kosongkan</span>
                  </button>
                )}
              </div>

              {cart.length === 0 ? (
                <div
                  style={{
                    backgroundColor: project.theme.cardBg,
                    borderColor: project.theme.borderColor,
                  }}
                  className="rounded-2xl border p-8 text-center space-y-3"
                >
                  <div className="w-12 h-12 rounded-2xl mx-auto flex items-center justify-center bg-slate-500/10">
                    <ShoppingBag className="w-6 h-6 opacity-60" />
                  </div>
                  <div className="text-sm font-bold">Keranjang masih kosong</div>
                  <p className="text-xs opacity-70">
                    Pilih produk dari katalog terlebih dahulu untuk memesan via WhatsApp.
                  </p>
                  <button
                    type="button"
                    onClick={() => setSubPage({ type: 'home' })}
                    style={{ backgroundColor: project.theme.accentColor }}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-white cursor-pointer hover:opacity-95"
                  >
                    Lihat Katalog Produk
                  </button>
                </div>
              ) : (
                <>
                  {/* Daftar Item Keranjang */}
                  <div
                    style={{
                      backgroundColor: project.theme.cardBg,
                      borderColor: project.theme.borderColor,
                    }}
                    className="rounded-2xl border divide-y"
                  >
                    {cart.map((entry) => (
                      <div
                        key={entry.key}
                        style={{ borderColor: project.theme.borderColor }}
                        className="p-3 flex items-start gap-3"
                      >
                        <img
                          src={entry.image}
                          alt={entry.title}
                          referrerPolicy="no-referrer"
                          className="w-14 h-14 rounded-xl object-cover bg-slate-100 shrink-0"
                        />
                        <div className="min-w-0 flex-1 space-y-1">
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <div className="text-xs font-bold leading-snug">{entry.title}</div>
                              {entry.variant && (
                                <div className="text-[11px] opacity-70">
                                  Varian: {entry.variant}
                                </div>
                              )}
                            </div>
                            <button
                              type="button"
                              onClick={() => removeFromCart(entry.key)}
                              title="Hapus item"
                              className="p-1 rounded-md text-slate-400 hover:text-red-500 cursor-pointer shrink-0"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="flex items-center justify-between gap-2 pt-1">
                            <div
                              className="text-xs font-bold tabular-nums"
                              style={{ color: project.theme.accentColor }}
                            >
                              {entry.unitPrice > 0
                                ? formatRupiah(entry.unitPrice * entry.qty)
                                : entry.priceText}
                            </div>

                            <div className="inline-flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => updateCartQty(entry.key, -1)}
                                style={{ borderColor: project.theme.borderColor }}
                                className="w-6 h-6 rounded-md border flex items-center justify-center cursor-pointer"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="w-6 text-center text-xs font-bold tabular-nums">
                                {entry.qty}
                              </span>
                              <button
                                type="button"
                                onClick={() => updateCartQty(entry.key, 1)}
                                style={{ borderColor: project.theme.borderColor }}
                                className="w-6 h-6 rounded-md border flex items-center justify-center cursor-pointer"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Form Data Pembeli */}
                  {activeAskCustomerInfo && (
                    <div
                      style={{
                        backgroundColor: project.theme.cardBg,
                        borderColor: project.theme.borderColor,
                      }}
                      className="rounded-2xl border p-4 space-y-2.5"
                    >
                      <div className="text-xs font-bold">Data Pemesan</div>
                      <input
                        type="text"
                        value={customer.name}
                        placeholder="Nama lengkap"
                        onChange={(e) =>
                          setCustomer((prev) => ({ ...prev, name: e.target.value }))
                        }
                        style={{ borderColor: project.theme.borderColor }}
                        className="w-full px-3 py-2 rounded-xl border bg-transparent text-xs outline-none"
                      />
                      <input
                        type="tel"
                        value={customer.phone}
                        placeholder="No. HP / WhatsApp (opsional)"
                        onChange={(e) =>
                          setCustomer((prev) => ({ ...prev, phone: e.target.value }))
                        }
                        style={{ borderColor: project.theme.borderColor }}
                        className="w-full px-3 py-2 rounded-xl border bg-transparent text-xs outline-none"
                      />
                      <textarea
                        rows={2}
                        value={customer.address}
                        placeholder={
                          !hasPhysicalItemInCart
                            ? 'Alamat / Lokasi'
                            : shouldShowChoices &&
                              (customer.shippingMethod === 'makan_ditempat' ||
                                customer.shippingMethod === 'ambil_sendiri')
                            ? 'Alamat (opsional)'
                            : 'Alamat lengkap pengiriman / patokan lokasi'
                        }
                        onChange={(e) =>
                          setCustomer((prev) => ({ ...prev, address: e.target.value }))
                        }
                        style={{ borderColor: project.theme.borderColor }}
                        className="w-full px-3 py-2 rounded-xl border bg-transparent text-xs outline-none resize-none"
                      />
                      <input
                        type="text"
                        value={customer.notes}
                        placeholder="Catatan pesanan (opsional)"
                        onChange={(e) =>
                          setCustomer((prev) => ({ ...prev, notes: e.target.value }))
                        }
                        style={{ borderColor: project.theme.borderColor }}
                        className="w-full px-3 py-2 rounded-xl border bg-transparent text-xs outline-none"
                      />
                    </div>
                  )}

                  {/* Pilihan (Khusus Produk Fisik) */}
                  {shouldShowChoices && (
                    <div
                      style={{
                        backgroundColor: project.theme.cardBg,
                        borderColor: project.theme.borderColor,
                      }}
                      className="rounded-2xl border p-4 space-y-3"
                    >
                      <div className="text-xs font-bold">Pilihan</div>
                      <div className="space-y-2">
                        {enabledShippingOptions.map((opt, idx) => {
                          const isSelected = activeSelectedShipOpt?.id === opt.id;
                          const selectOption = () =>
                            setCustomer((prev) => ({
                              ...prev,
                              shippingMethod: opt.id as ShippingMethodId,
                              checklistConfirmed:
                                prev.shippingMethod === opt.id
                                  ? prev.checklistConfirmed
                                  : false,
                            }));
                          const hasExtraInputs = Boolean(
                            opt.askArrivalTime || opt.askGuestCount
                          );

                          return (
                            <div
                              key={opt.id}
                              style={
                                isSelected
                                  ? {
                                      borderColor: project.theme.accentColor,
                                      backgroundColor: `${project.theme.accentColor}12`,
                                    }
                                  : { borderColor: project.theme.borderColor }
                              }
                              className="rounded-xl border transition-colors overflow-hidden"
                            >
                              <label
                                onClick={selectOption}
                                className="flex items-start gap-2.5 p-2.5 cursor-pointer"
                              >
                                <input
                                  type="radio"
                                  name="lynk_shipping_method"
                                  checked={isSelected}
                                  onChange={selectOption}
                                  className="mt-0.5 shrink-0 cursor-pointer"
                                />
                                <div className="min-w-0 flex-1">
                                  <div className="text-xs font-semibold leading-snug">
                                    {idx + 1}. {opt.label}
                                  </div>
                                </div>
                              </label>

                              {isSelected &&
                                (hasExtraInputs ||
                                  (opt.checklistEnabled && opt.checklistText?.trim()) ||
                                  (opt.id === 'ambil_sendiri' && combinedPickupNote)) && (
                                  <div className="px-3 pb-3 pt-0.5 space-y-2">
                                    {hasExtraInputs && (
                                      <div
                                        className={`grid gap-2 ${
                                          opt.askArrivalTime && opt.askGuestCount
                                            ? 'grid-cols-2'
                                            : 'grid-cols-1'
                                        }`}
                                      >
                                        {opt.askArrivalTime && (
                                          <div>
                                            <label className="block text-[11px] font-semibold opacity-80 mb-1">
                                              {opt.arrivalTimeLabel || 'Waktu'}
                                            </label>
                                            <input
                                              type="text"
                                              value={customer.arrivalTime ?? ''}
                                              placeholder={
                                                opt.arrivalTimePlaceholder || 'Contoh: 18:30 WIB'
                                              }
                                              onChange={(e) =>
                                                setCustomer((prev) => ({
                                                  ...prev,
                                                  arrivalTime: e.target.value,
                                                }))
                                              }
                                              style={{
                                                borderColor: project.theme.borderColor,
                                                backgroundColor: project.theme.cardBg,
                                              }}
                                              className="w-full px-2.5 py-1.5 rounded-lg border text-xs outline-none"
                                            />
                                          </div>
                                        )}
                                        {opt.askGuestCount && (
                                          <div>
                                            <label className="block text-[11px] font-semibold opacity-80 mb-1">
                                              {opt.guestCountLabel || 'Jumlah Orang'}
                                            </label>
                                            <input
                                              type="text"
                                              value={customer.guestCount ?? ''}
                                              placeholder={
                                                opt.guestCountPlaceholder || 'Contoh: 4 orang'
                                              }
                                              onChange={(e) =>
                                                setCustomer((prev) => ({
                                                  ...prev,
                                                  guestCount: e.target.value,
                                                }))
                                              }
                                              style={{
                                                borderColor: project.theme.borderColor,
                                                backgroundColor: project.theme.cardBg,
                                              }}
                                              className="w-full px-2.5 py-1.5 rounded-lg border text-xs outline-none"
                                            />
                                          </div>
                                        )}
                                      </div>
                                    )}

                                    {opt.checklistEnabled && opt.checklistText?.trim() && (
                                      <label
                                        style={{
                                          borderColor: customer.checklistConfirmed
                                            ? '#10B981'
                                            : project.theme.borderColor,
                                          backgroundColor: project.theme.cardBg,
                                        }}
                                        className="flex items-start gap-2 p-2.5 rounded-lg border cursor-pointer"
                                      >
                                        <input
                                          type="checkbox"
                                          checked={Boolean(customer.checklistConfirmed)}
                                          onChange={(e) =>
                                            setCustomer((prev) => ({
                                              ...prev,
                                              checklistConfirmed: e.target.checked,
                                            }))
                                          }
                                          className="mt-0.5 shrink-0 accent-emerald-600 cursor-pointer"
                                        />
                                        <span className="text-[11px] font-medium leading-relaxed">
                                          {opt.checklistText.trim()}
                                        </span>
                                      </label>
                                    )}

                                    {opt.id === 'ambil_sendiri' && combinedPickupNote && (
                                      <div className="text-[11px] font-semibold text-amber-900 bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-1.5 leading-snug">
                                        Info Produk: {combinedPickupNote}
                                      </div>
                                    )}
                                  </div>
                                )}
                            </div>
                          );
                        })}
                      </div>

                      {/* Catatan Pilihan Terpilih */}
                      {activeSelectedShipOpt?.noteText?.trim() && (
                        <div className="rounded-xl bg-amber-50 border-2 border-amber-300 p-3.5 text-amber-950 space-y-1">
                          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900">
                            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                            <span>{activeSelectedShipOpt.noteTitle?.trim() || 'Catatan:'}</span>
                          </div>
                          <p className="text-xs font-bold leading-relaxed text-amber-950 whitespace-pre-line">
                            {activeSelectedShipOpt.noteText.trim()}
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Ringkasan & Tombol WhatsApp */}
                  <div
                    style={{
                      backgroundColor: project.theme.cardBg,
                      borderColor: project.theme.borderColor,
                    }}
                    className="rounded-2xl border p-4 space-y-3"
                  >
                    <div className="flex items-center justify-between text-xs opacity-75">
                      <span>Total Item</span>
                      <span className="font-semibold tabular-nums">{totalCartCount} produk</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold">Total Estimasi</span>
                      <span
                        className="text-base font-bold tabular-nums"
                        style={{ color: project.theme.accentColor }}
                      >
                        {totalCartAmount > 0 ? formatRupiah(totalCartAmount) : 'Sesuai konfirmasi WA'}
                      </span>
                    </div>
                    {cartStoreGroups.length <= 1 ? (
                      <a
                        href={cartWaUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        data-wa-tracked="1"
                        onClick={() =>
                          recordPreviewWaClick(
                            `Keranjang WA (${totalCartCount} item)`,
                            cartWaUrl,
                            totalCartAmount
                          )
                        }
                        className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-colors"
                      >
                        <MessageCircle className="w-4 h-4" />
                        <span>Kirim Pesanan via WhatsApp</span>
                      </a>
                    ) : (
                      <div className="space-y-2 pt-1">
                        <div className="text-[11px] font-medium text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-2 leading-snug">
                          Keranjang berisi produk dari {cartStoreGroups.length} nomor WhatsApp berbeda. Kirim pesanan per toko di bawah ini:
                        </div>
                        {cartStoreGroups.map((grp) => {
                          const grpCount = grp.entries.reduce((s, e) => s + e.qty, 0);
                          const grpTotal = grp.entries.reduce(
                            (s, e) => s + e.unitPrice * e.qty,
                            0
                          );
                          return (
                            <a
                              key={grp.normalizedPhone}
                              href={grp.waUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              data-wa-tracked="1"
                              onClick={() =>
                                recordPreviewWaClick(
                                  `Keranjang ${grp.storeName} (${grpCount} item)`,
                                  grp.waUrl,
                                  grpTotal
                                )
                              }
                              className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-colors"
                            >
                              <MessageCircle className="w-4 h-4 shrink-0" />
                              <span className="truncate">
                                Kirim ke {grp.storeName} ({grpCount} item)
                              </span>
                            </a>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>
          )}
          </div>

          {activeSheetContent && (
            <div
              onClick={closeBottomSheet}
              className={`absolute inset-0 z-30 flex flex-col justify-end transition-colors duration-200 ${
                sheetEntered ? 'bg-slate-950/55 backdrop-blur-[2px]' : 'bg-slate-950/0'
              }`}
            >
              <div
                onClick={(e) => e.stopPropagation()}
                style={{
                  backgroundColor: project.theme.cardBg,
                  color: project.theme.textColor,
                  borderColor: project.theme.borderColor,
                }}
                className={`w-full max-h-[84%] rounded-t-[22px] border-t shadow-2xl flex flex-col overflow-hidden transition-transform duration-200 ease-out ${
                  sheetEntered ? 'translate-y-0' : 'translate-y-full'
                }`}
              >
                <div
                  className="pt-2.5 pb-2.5 px-4 border-b flex flex-col items-center gap-2 shrink-0"
                  style={{ borderColor: project.theme.borderColor }}
                >
                  <div className="w-10 h-1 rounded-full bg-slate-300/80" />
                  <div className="w-full flex items-center justify-between gap-2">
                    <h3 className="text-sm font-bold truncate">{activeSheetContent.title}</h3>
                    <button
                      type="button"
                      onClick={closeBottomSheet}
                      aria-label="Tutup Bottom Sheet"
                      className="p-1.5 rounded-full hover:bg-slate-200/60 opacity-70 hover:opacity-100 cursor-pointer transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto p-4">
                  {activeSheetContent.children.length > 0 ? (
                    activeSheetContent.children.map((child) =>
                      renderPreviewBlock(child, 1)
                    )
                  ) : (
                    <div className="py-8 text-center text-xs opacity-60">
                      Belum ada konten di dalam Bottom Sheet ini.
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Pinned Bottom Navbar */}
          {bottomNavbar.enabled && enabledNavItems.length > 0 && (
            <nav
              style={{
                backgroundColor: bottomNavbar.barBg,
                color: bottomNavbar.textColor,
                borderColor: bottomNavbar.borderColor,
              }}
              className="shrink-0 z-20 border-t px-1.5 pt-1.5 pb-2 shadow-[0_-6px_20px_rgba(15,23,42,0.08)]"
            >
              <div
                style={{
                  gridTemplateColumns: `repeat(${enabledNavItems.length}, minmax(0, 1fr))`,
                }}
                className="grid items-end gap-0.5 max-w-[540px] mx-auto"
              >
                {enabledNavItems.map((item) => {
                  const isCenterHome =
                    bottomNavbar.centerStyle === 'elevated' &&
                    (item.action === 'scroll_top' || item.id === 'nav_home');
                  const isSheetOpen =
                    activeNavSheetId === item.id && item.action === 'sheet';
                  const iconId = resolveButtonIcon(item.icon, item.label);
                  const displayIcon = iconId === 'none' ? 'info' : iconId;

                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        if (item.action === 'scroll_top') {
                          closeBottomSheet();
                          setSubPage({ type: 'home' });
                          setTimeout(scrollToTop, 10);
                        } else if (activeNavSheetId === item.id) {
                          closeBottomSheet();
                        } else {
                          openNavBottomSheet(item.id);
                        }
                      }}
                      className="flex flex-col items-center justify-end gap-0.5 py-0.5 px-1 rounded-xl cursor-pointer transition-opacity hover:opacity-90 min-w-0"
                    >
                      {isCenterHome ? (
                        <span
                          style={{
                            backgroundColor: bottomNavbar.accentColor,
                            borderColor: bottomNavbar.barBg,
                          }}
                          className="-mt-5 w-11 h-11 rounded-full border-4 text-white flex items-center justify-center shadow-md shrink-0"
                        >
                          <ButtonGlyph icon={displayIcon} className="w-5 h-5" />
                        </span>
                      ) : (
                        <span
                          style={isSheetOpen ? { color: bottomNavbar.accentColor } : undefined}
                          className="w-6 h-6 flex items-center justify-center shrink-0"
                        >
                          <ButtonGlyph icon={displayIcon} className="w-[18px] h-[18px]" />
                        </span>
                      )}
                      <span
                        style={
                          isSheetOpen || isCenterHome
                            ? { color: bottomNavbar.accentColor }
                            : undefined
                        }
                        className={`text-[10px] leading-tight truncate max-w-full ${
                          isSheetOpen || isCenterHome ? 'font-bold' : 'font-medium opacity-80'
                        }`}
                      >
                        {item.label || 'Menu'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </nav>
          )}
        </div>

        {/* Floating Add-On WA Meta */}
        {ads.waAddonEnabled && (() => {
          const waPhone = normalizeWhatsappNumber(ads.waAddonNumber);
          const msg =
            (ads.waAddonGreeting ?? '').trim() ||
            `Halo ${project.title}, saya tertarik dengan penawaran di halaman ini.`;
          const waHref = `https://wa.me/${waPhone}?text=${encodeURIComponent(msg)}`;
          const hasNav = bottomNavbar.enabled && enabledNavItems.length > 0;
          const hasCart = subPage.type !== 'cart' && hasCartFeature && totalCartCount > 0;
          const floatBottom =
            hasNav && hasCart
              ? 'bottom-32'
              : hasNav
              ? 'bottom-20'
              : hasCart
              ? 'bottom-16'
              : 'bottom-4';
          return (
            <a
              href={waHref}
              target="_blank"
              rel="noopener noreferrer"
              data-wa-tracked="1"
              onClick={() => recordPreviewWaClick('Add-On WA Meta (Floating)', waHref)}
              className={`absolute right-4 ${floatBottom} z-20 inline-flex items-center gap-2 px-3.5 py-2 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-lg transition-all`}
            >
              <MessageCircle className="w-4 h-4 shrink-0" />
              <span>Chat WhatsApp</span>
            </a>
          );
        })()}

        {/* Toast Notifikasi */}
        {toastText && (
          <div className="pointer-events-none absolute bottom-20 left-1/2 -translate-x-1/2 z-40 px-3.5 py-1.5 rounded-full bg-slate-900/90 text-white text-[11px] font-semibold shadow-lg whitespace-nowrap">
            {toastText}
          </div>
        )}

        {/* Floating Keranjang Bar */}
        {subPage.type !== 'cart' && hasCartFeature && totalCartCount > 0 && (
          <div className="px-4 py-2.5 border-t border-slate-200 bg-white flex items-center justify-between gap-3 shrink-0 shadow-sm">
            <div className="min-w-0">
              <div className="text-[11px] font-semibold text-slate-500 tabular-nums">
                {totalCartCount} item di keranjang
              </div>
              <div className="text-sm font-bold text-slate-900 tabular-nums truncate">
                {totalCartAmount > 0 ? formatRupiah(totalCartAmount) : 'Siap pesan via WA'}
              </div>
            </div>
            <button
              type="button"
              onClick={() => openCartPage()}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer shrink-0 transition-colors"
            >
              <ShoppingCart className="w-3.5 h-3.5" />
              <span>Lihat Keranjang</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export function CodeModal({
  projectId,
  project,
  onClose,
}: {
  projectId: string;
  project: BuilderProject;
  onClose: () => void;
}) {
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState<string | null>(null);
  const html = generateProjectHtml(project, { projectId });

  const handleCopy = async () => {
    const ok = await copyTextToClipboard(html);
    if (ok) {
      setCopyError(null);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } else {
      setCopyError('Gagal menyalin otomatis. Silakan klik tombol Unduh .html.');
      setTimeout(() => setCopyError(null), 3500);
    }
  };

  const handleDownloadHtml = () => {
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.title.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'halaman'}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-3xl max-h-[85vh] flex flex-col bg-white rounded-2xl overflow-hidden shadow-2xl border border-slate-200"
      >
        <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Kode Ekspor HTML</h2>
            <p className="text-xs text-slate-500">
              Siap ditempel ke platform link-in-bio atau diunggah sebagai halaman statis.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleDownloadHtml}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh .html</span>
            </button>
            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-xs font-semibold text-white cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Tersalin!' : 'Salin Kode'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
        {copyError && (
          <div className="px-5 py-2 bg-amber-50 border-b border-amber-200 text-amber-800 text-xs font-medium">
            {copyError}
          </div>
        )}
        <pre className="flex-1 overflow-auto p-4 bg-slate-950 text-slate-100 text-xs font-mono leading-relaxed">
          <code>{html}</code>
        </pre>
      </div>
    </div>
  );
}

export type ImportedPayload =
  | { kind: 'single'; project: BuilderProject }
  | { kind: 'workspace'; bundle: WorkspaceBundle };

export function ImportModal({
  onImport,
  onClose,
}: {
  onImport: (payload: ImportedPayload) => void;
  onClose: () => void;
}) {
  const [rawJson, setRawJson] = useState('');
  const [error, setError] = useState<string | null>(null);

  const tryParseAndImport = (text: string) => {
    try {
      const parsed = JSON.parse(text) as Record<string, unknown>;
      if (parsed && Array.isArray(parsed.projects) && parsed.projects.length > 0) {
        onImport({ kind: 'workspace', bundle: parsed as unknown as WorkspaceBundle });
        onClose();
        return;
      }
      const single = parsed as unknown as BuilderProject;
      if (!single || !Array.isArray(single.blocks) || !single.theme) {
        setError('Format file backup tidak valid.');
        return;
      }
      onImport({ kind: 'single', project: single });
      onClose();
    } catch {
      setError('Gagal membaca JSON. Pastikan isi file backup valid.');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        tryParseAndImport(reader.result);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden"
      >
        <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Import Backup Proyek (.json)</h2>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Mendukung file backup 1 usaha maupun backup semua usaha sekaligus.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-slate-100 text-slate-500 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <label className="flex flex-col items-center justify-center gap-2 py-6 px-4 rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 hover:bg-slate-100 cursor-pointer transition-colors">
            <FileUp className="w-6 h-6 text-blue-600" />
            <span className="text-xs font-semibold text-slate-700">
              Pilih file backup .json dari perangkat
            </span>
            <input type="file" accept=".json,application/json" onChange={handleFileChange} className="hidden" />
          </label>

          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">
              Atau tempel isi JSON di sini:
            </label>
            <textarea
              rows={5}
              value={rawJson}
              onChange={(e) => {
                setRawJson(e.target.value);
                setError(null);
              }}
              placeholder='{"title": "...", "theme": {...}, "blocks": [...]}'
              className="w-full p-3 text-xs font-mono rounded-xl border border-slate-200 focus:border-blue-500 outline-none"
            />
          </div>

          {error && <div className="text-xs text-red-600 font-medium">{error}</div>}

          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] text-slate-400">
              Usaha yang diimpor ditambahkan ke daftar tanpa menghapus proyek lama.
            </span>
            <div className="flex gap-2 shrink-0">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => tryParseAndImport(rawJson)}
                disabled={!rawJson.trim()}
                className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-xs font-semibold text-white cursor-pointer"
              >
                Muat Proyek
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function formatUpdatedAt(ts: number): string {
  const diffSec = Math.max(0, Math.floor((Date.now() - ts) / 1000));
  if (diffSec < 60) return 'Baru saja';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin} menit lalu`;
  const diffHour = Math.floor(diffMin / 60);
  if (diffHour < 24) return `${diffHour} jam lalu`;
  return new Date(ts).toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export function ProjectsModal({
  projects,
  activeProjectId,
  onSelectProject,
  onCreateProject,
  onDuplicateProject,
  onDeleteProject,
  onDownloadHtml,
  onOpenDomainAndAds,
  onOpenDashboard,
  onBackupAll,
  onOpenImport,
  onClose,
}: {
  projects: ProjectRecord[];
  activeProjectId: string;
  onSelectProject: (id: string) => void;
  onCreateProject: (mode: 'template' | 'blank') => void;
  onDuplicateProject: (id: string) => void;
  onDeleteProject: (id: string) => void;
  onDownloadHtml: (record: ProjectRecord) => void;
  onOpenDomainAndAds: (id: string) => void;
  onOpenDashboard: () => void;
  onBackupAll: () => void;
  onOpenImport: () => void;
  onClose: () => void;
}) {
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-3xl max-h-[88vh] flex flex-col bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden"
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-3 bg-slate-50/70 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <FolderKanban className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm font-bold text-slate-900 truncate">
                Daftar Unit Usaha ({projects.length})
              </h2>
              <p className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                <HardDrive className="w-3 h-3 text-emerald-600 shrink-0" />
                <span>Setiap unit usaha memiliki slug, domain kustom, dan pelacakan klik WA sendiri</span>
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-200/70 text-slate-500 cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action Strip */}
        <div className="px-5 py-3 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 bg-white shrink-0">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => {
                onCreateProject('template');
                onClose();
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Usaha Baru (Template)</span>
            </button>
            <button
              type="button"
              onClick={() => {
                onCreateProject('blank');
                onClose();
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer transition-colors"
            >
              <FilePlus2 className="w-3.5 h-3.5" />
              <span>Kanvas Kosong</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenDashboard();
              }}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer"
            >
              <BarChart3 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Dashboard WA</span>
            </button>
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenImport();
              }}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer"
            >
              <FileUp className="w-3.5 h-3.5" />
              <span>Import</span>
            </button>
            <button
              type="button"
              onClick={onBackupAll}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-semibold cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Backup ({projects.length})</span>
            </button>
          </div>
        </div>

        {/* Project List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-2.5 bg-slate-50/50">
          {projects.map((rec, idx) => {
            const isActive = rec.id === activeProjectId;
            const isConfirming = confirmDeleteId === rec.id;
            const pub = resolveProjectPublishing(rec.project);

            return (
              <div
                key={rec.id}
                className={`p-3.5 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  isActive
                    ? 'bg-emerald-50/50 border-emerald-300 ring-1 ring-emerald-500/20'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start sm:items-center gap-3 min-w-0">
                  <div className="w-7 h-7 rounded-lg bg-slate-100 text-slate-600 text-xs font-bold flex items-center justify-center shrink-0 tabular-nums">
                    {idx + 1}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-bold text-slate-900 truncate">
                        {rec.project.title || `Usaha #${idx + 1}`}
                      </span>
                      {isActive && (
                        <span className="px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-semibold">
                          Sedang Diedit
                        </span>
                      )}
                      <span
                        className={`text-[10px] font-semibold ${
                          pub.isPublished ? 'text-emerald-700' : 'text-slate-500'
                        }`}
                      >
                        · {pub.isPublished ? 'Tayang' : 'Draft'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-1 flex-wrap">
                      <span className="font-mono text-slate-700">
                        {pub.useCustomDomain && pub.customDomain
                          ? pub.customDomain
                          : `/p/${pub.slug}`}
                      </span>
                      <span>·</span>
                      <span>{rec.project.blocks.length} elemen</span>
                      <span>·</span>
                      <span>Diubah {formatUpdatedAt(rec.updatedAt)}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 flex-wrap shrink-0">
                  {!isActive && (
                    <button
                      type="button"
                      onClick={() => {
                        onSelectProject(rec.id);
                        onClose();
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
                    >
                      Buka
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      onSelectProject(rec.id);
                      onClose();
                      onOpenDomainAndAds(rec.id);
                    }}
                    title="Atur Domain, Slug & Pixel Iklan"
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-medium cursor-pointer"
                  >
                    <Globe className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Domain & Iklan</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onDuplicateProject(rec.id);
                      onClose();
                    }}
                    title="Duplikat layout usaha ini untuk usaha baru"
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-medium cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Duplikat</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onDownloadHtml(rec)}
                    title="Unduh file HTML halaman usaha ini"
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-medium cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>HTML</span>
                  </button>

                  {projects.length > 1 && (
                    isConfirming ? (
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => {
                            onDeleteProject(rec.id);
                            setConfirmDeleteId(null);
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold cursor-pointer"
                        >
                          Yakin Hapus
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(null)}
                          className="px-2 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 text-xs cursor-pointer"
                        >
                          Batal
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteId(rec.id)}
                        title="Hapus usaha ini"
                        className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-red-50 hover:border-red-200 text-slate-400 hover:text-red-600 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer Tip */}
        <div className="px-5 py-2.5 border-t border-slate-200 bg-white text-[11px] text-slate-500 shrink-0">
          Tips: Selesaikan 1 usaha hingga rapi, lalu klik <strong>Duplikat</strong> untuk membuat usaha berikutnya agar tidak perlu menyusun ulang dari awal.
        </div>
      </div>
    </div>
  );
}
