import React, { useState } from 'react';
import {
  AlignCenter,
  AlignLeft,
  AlignRight,
  ArrowLeft,
  ChevronDown,
  Copy,
  Eye,
  EyeOff,
  GripVertical,
  Image as ImageIcon,
  Info,
  LayoutTemplate,
  Palette,
  PanelBottom,
  Plus,
  RotateCcw,
  ShoppingCart,
  SlidersHorizontal,
  Trash2,
  Type,
  Upload,
  Video,
  X,
} from 'lucide-react';
import {
  AdvanceOptions,
  BlockLayoutMode,
  BlockStyle,
  BlockType,
  BottomNavbarConfig,
  BottomNavbarItem,
  BottomNavbarItemAction,
  BottomSheetTriggerStyle,
  BuilderBlock,
  ButtonIconId,
  CarouselAspectRatio,
  CarouselItem,
  CatalogCartButtonSize,
  CatalogItem,
  CatalogProductType,
  CatalogShippingOptionConfig,
  PageTheme,
  ShadowPreset,
  ShippingMethodId,
  SocialFollowerAccount,
  SocialLinkItem,
  SocialPlatform,
  SocialPostItem,
} from '../types/builder';
import {
  cloneDefaultCatalogShippingOptions,
  resolveCatalogShippingOptions,
} from '../utils/cartHelpers';
import {
  BLOCK_TYPE_NAMES,
  CAROUSEL_SAMPLE_1_SVG,
  CAROUSEL_SAMPLE_2_SVG,
  CAROUSEL_SAMPLE_3_SVG,
  DEFAULT_STYLE,
  MAPS_LOCATION_SVG,
  PRODUCT_CARD_SVG,
  createBlock,
  createId,
} from '../data/presets';
import { SOCIAL_PLATFORMS, SOCIAL_PLATFORM_LIST, resolveSocialMetrics } from '../utils/socialIcons';
import { BUTTON_ICON_LIST, resolveButtonIcon } from '../utils/buttonIcons';
import { ButtonGlyph } from './ButtonIcon';
import { SocialGlyph } from './SocialIcon';

import { readAndCompressImage, readVideoFileSafe } from '../utils/imageHelpers';

interface RightInspectorProps {
  selectedBlock: BuilderBlock | null;
  theme: PageTheme;
  advanceOptions: AdvanceOptions;
  bottomNavbar: BottomNavbarConfig;
  inspectorMode: 'element' | 'navbar';
  activeNavItemId: string;
  selectedParentNavId: string | null;
  selectedParentNavLabel: string | null;
  onChangeInspectorMode: (mode: 'element' | 'navbar') => void;
  onSelectNavItem: (id: string) => void;
  onUpdateBottomNavbar: (updater: (prev: BottomNavbarConfig) => BottomNavbarConfig) => void;
  onUpdateAdvanceOptions: (patch: Partial<AdvanceOptions>) => void;
  onUpdateBlock: (id: string, updater: (block: BuilderBlock) => BuilderBlock) => void;
  onDuplicateBlock: (id: string) => void;
  onAddChildToContainer: (containerId: string, type: BlockType) => void;
  onSelectBlock?: (id: string) => void;
}

export function RightInspector({
  selectedBlock,
  theme,
  advanceOptions,
  bottomNavbar,
  inspectorMode,
  activeNavItemId,
  selectedParentNavId,
  selectedParentNavLabel,
  onChangeInspectorMode,
  onSelectNavItem,
  onUpdateBottomNavbar,
  onUpdateAdvanceOptions,
  onUpdateBlock,
  onDuplicateBlock,
  onAddChildToContainer,
  onSelectBlock,
}: RightInspectorProps) {
  const [dragItemState, setDragItemState] = useState<{
    draggedId: string | null;
    targetId: string | null;
  }>({ draggedId: null, targetId: null });
  const [newSocialPlatform, setNewSocialPlatform] = useState<SocialPlatform>('instagram');
  const [newSocialFollowerPlatform, setNewSocialFollowerPlatform] =
    useState<SocialPlatform>('tiktok');
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [inspectorTab, setInspectorTab] = useState<'content' | 'appearance'>('content');
  const [expandedCatalogItems, setExpandedCatalogItems] = useState<Record<string, boolean>>({});
  const [activeShippingOptionId, setActiveShippingOptionId] =
    useState<ShippingMethodId>('makan_ditempat');

  const updateStyle = (patch: Partial<BlockStyle>) => {
    if (!selectedBlock) return;
    onUpdateBlock(selectedBlock.id, (blk) => ({
      ...blk,
      style: { ...blk.style, ...patch },
    }));
  };

  const updateContent = (patch: Partial<BuilderBlock['content']>) => {
    if (!selectedBlock) return;
    onUpdateBlock(selectedBlock.id, (blk) => ({
      ...blk,
      content: { ...blk.content, ...patch },
    }));
  };

  const handleResetStyle = () => {
    if (!selectedBlock) return;
    onUpdateBlock(selectedBlock.id, (blk) => ({
      ...blk,
      style: {
        ...DEFAULT_STYLE,
        textColor: theme.textColor,
        useThemeTextColor: true,
        shadowColor: undefined,
        backgroundColor:
          blk.type === 'container' || blk.type === 'toggle_container' || blk.type === 'form'
            ? '#FFFFFF'
            : 'transparent',
        borderWidth:
          blk.type === 'container' || blk.type === 'toggle_container' || blk.type === 'form'
            ? 1
            : 0,
        paddingX: undefined,
        paddingTop: undefined,
        paddingBottom: undefined,
        fullBleed: false,
      },
    }));
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !selectedBlock) return;
    const targetBlockId = selectedBlock.id;
    setUploadError(null);
    try {
      const compressed = await readAndCompressImage(file, { maxDimension: 1080, quality: 0.82 });
      onUpdateBlock(targetBlockId, (blk) => ({
        ...blk,
        content: { ...blk.content, src: compressed },
      }));
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Gagal memproses gambar.');
    }
  };

  const handleCatalogItemImageUpload = async (
    itemId: string,
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !selectedBlock) return;
    const targetBlockId = selectedBlock.id;
    setUploadError(null);
    try {
      const compressed = await readAndCompressImage(file, { maxDimension: 1080, quality: 0.82 });
      onUpdateBlock(targetBlockId, (blk) => ({
        ...blk,
        content: {
          ...blk.content,
          catalogItems: (blk.content.catalogItems ?? []).map((item) =>
            item.id === itemId ? { ...item, image: compressed } : item
          ),
        },
      }));
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Gagal memproses gambar produk.');
    }
  };

  const handleCatalogItemGalleryUpload = async (
    itemId: string,
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !selectedBlock) return;
    const targetBlockId = selectedBlock.id;
    setUploadError(null);
    try {
      const compressed = await readAndCompressImage(file, { maxDimension: 1080, quality: 0.82 });
      onUpdateBlock(targetBlockId, (blk) => ({
        ...blk,
        content: {
          ...blk.content,
          catalogItems: (blk.content.catalogItems ?? []).map((item) =>
            item.id === itemId
              ? { ...item, gallery: [...(item.gallery ?? []), compressed] }
              : item
          ),
        },
      }));
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Gagal memproses foto galeri.');
    }
  };

  const handleRemoveCatalogGalleryImage = (itemId: string, idx: number) => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.catalogItems ?? [];
    const target = current.find((it) => it.id === itemId);
    if (!target) return;
    const nextGallery = (target.gallery ?? []).filter((_, i) => i !== idx);
    handleUpdateCatalogItem(itemId, { gallery: nextGallery });
  };

  const handleUpdateCatalogItem = (itemId: string, patch: Partial<CatalogItem>) => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.catalogItems ?? [];
    updateContent({
      catalogItems: current.map((item) => (item.id === itemId ? { ...item, ...patch } : item)),
    });
  };

  const handleAddCatalogItem = () => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.catalogItems ?? [];
    const nextItem: CatalogItem = {
      id: createId('item'),
      title: `Produk #${current.length + 1}`,
      subtitle: 'Deskripsi singkat produk Anda',
      description: 'Tuliskan detail lengkap produk, spesifikasi, atau manfaat di sini.',
      variants: 'Reguler, Paket Lengkap',
      price: 'Rp 75.000',
      ctaLabel: 'Lihat Detail',
      url: 'https://example.com',
      image: PRODUCT_CARD_SVG,
      imageAspectRatio: '4/3',
      imageObjectFit: 'cover',
      unitSold: 12,
    };
    updateContent({ catalogItems: [...current, nextItem] });
    setExpandedCatalogItems((prev) => ({ ...prev, [nextItem.id]: true }));
  };

  const handleDeleteCatalogItem = (itemId: string) => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.catalogItems ?? [];
    updateContent({
      catalogItems: current.filter((item) => item.id !== itemId),
    });
  };

  const handleReorderCatalogItem = (draggedId: string, targetId: string) => {
    if (!selectedBlock || draggedId === targetId) return;
    const current = [...(selectedBlock.content.catalogItems ?? [])];
    const fromIdx = current.findIndex((i) => i.id === draggedId);
    const toIdx = current.findIndex((i) => i.id === targetId);
    if (fromIdx === -1 || toIdx === -1) return;
    const [moved] = current.splice(fromIdx, 1);
    current.splice(toIdx, 0, moved);
    updateContent({ catalogItems: current });
  };

  const handleUpdateSocialItem = (itemId: string, patch: Partial<SocialLinkItem>) => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.socialItems ?? [];
    updateContent({
      socialItems: current.map((item) => (item.id === itemId ? { ...item, ...patch } : item)),
    });
  };

  const handleAddSocialItem = (platform: SocialPlatform) => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.socialItems ?? [];
    const meta = SOCIAL_PLATFORMS[platform];
    const nextItem: SocialLinkItem = {
      id: createId(`soc_${platform}`),
      platform,
      url: meta.placeholderUrl,
      visible: true,
    };
    updateContent({ socialItems: [...current, nextItem] });
  };

  const handleDeleteSocialItem = (itemId: string) => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.socialItems ?? [];
    updateContent({
      socialItems: current.filter((item) => item.id !== itemId),
    });
  };

  const handleReorderSocialItem = (draggedId: string, targetId: string) => {
    if (!selectedBlock || draggedId === targetId) return;
    const current = [...(selectedBlock.content.socialItems ?? [])];
    const fromIdx = current.findIndex((i) => i.id === draggedId);
    const toIdx = current.findIndex((i) => i.id === targetId);
    if (fromIdx === -1 || toIdx === -1) return;
    const [moved] = current.splice(fromIdx, 1);
    current.splice(toIdx, 0, moved);
    updateContent({ socialItems: current });
  };

  const makeDefaultFollowerAccount = (platform: SocialPlatform): SocialFollowerAccount => {
    const meta = SOCIAL_PLATFORMS[platform] ?? SOCIAL_PLATFORMS.instagram;
    return {
      id: createId(`sfa_${platform}`),
      platform,
      avatar: '',
      accountName: 'Studio Kreatif Nusantara',
      handle: '@studiokreatif',
      accountUrl: meta.placeholderUrl,
      verified: true,
      postsCount: '128',
      postsLabel: 'Postingan',
      followers: '45,8 rb',
      followersLabel: 'Follower',
      following: '312',
      followingLabel: 'Mengikuti',
      bio: '',
      followLabel: 'Ikuti',
    };
  };

  const handleAddSocialFollowerAccount = (platform: SocialPlatform) => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.socialFollowerAccounts ?? [];
    updateContent({
      socialFollowerAccounts: [...current, makeDefaultFollowerAccount(platform)],
    });
  };

  const handleAddPopularSocialFollowers = () => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.socialFollowerAccounts ?? [];
    const existing = new Set(current.map((a) => a.platform));
    const popular: SocialPlatform[] = [
      'instagram',
      'tiktok',
      'facebook',
      'youtube',
      'threads',
      'twitter',
      'telegram',
    ];
    const additions = popular
      .filter((p) => !existing.has(p))
      .map((p) => makeDefaultFollowerAccount(p));
    if (additions.length === 0) return;
    updateContent({
      socialFollowerAccounts: [...current, ...additions],
    });
  };

  const handleUpdateSocialFollowerAccount = (
    accountId: string,
    patch: Partial<SocialFollowerAccount>
  ) => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.socialFollowerAccounts ?? [];
    updateContent({
      socialFollowerAccounts: current.map((acc) =>
        acc.id === accountId ? { ...acc, ...patch } : acc
      ),
    });
  };

  const handleDeleteSocialFollowerAccount = (accountId: string) => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.socialFollowerAccounts ?? [];
    updateContent({
      socialFollowerAccounts: current.filter((acc) => acc.id !== accountId),
    });
  };

  const handleReorderSocialFollowerAccount = (draggedId: string, targetId: string) => {
    if (!selectedBlock || draggedId === targetId) return;
    const current = [...(selectedBlock.content.socialFollowerAccounts ?? [])];
    const fromIdx = current.findIndex((i) => i.id === draggedId);
    const toIdx = current.findIndex((i) => i.id === targetId);
    if (fromIdx === -1 || toIdx === -1) return;
    const [moved] = current.splice(fromIdx, 1);
    current.splice(toIdx, 0, moved);
    updateContent({ socialFollowerAccounts: current });
  };

  const handleSocialFollowerAvatarUpload = async (
    accountId: string,
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !selectedBlock) return;
    const targetBlockId = selectedBlock.id;
    setUploadError(null);
    try {
      const compressed = await readAndCompressImage(file, { maxDimension: 512, quality: 0.85 });
      onUpdateBlock(targetBlockId, (blk) => ({
        ...blk,
        content: {
          ...blk.content,
          socialFollowerAccounts: (blk.content.socialFollowerAccounts ?? []).map((acc) =>
            acc.id === accountId ? { ...acc, avatar: compressed } : acc
          ),
        },
      }));
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Gagal memproses foto profil.');
    }
  };

  const SAMPLE_CAROUSEL_IMAGES = [
    CAROUSEL_SAMPLE_1_SVG,
    CAROUSEL_SAMPLE_2_SVG,
    CAROUSEL_SAMPLE_3_SVG,
  ];

  const handleUpdateCarouselItem = (itemId: string, patch: Partial<CarouselItem>) => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.carouselItems ?? [];
    updateContent({
      carouselItems: current.map((item) => (item.id === itemId ? { ...item, ...patch } : item)),
    });
  };

  const handleCarouselItemImageUpload = async (
    itemId: string,
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !selectedBlock) return;
    const targetBlockId = selectedBlock.id;
    setUploadError(null);
    try {
      const compressed = await readAndCompressImage(file, { maxDimension: 1080, quality: 0.82 });
      onUpdateBlock(targetBlockId, (blk) => ({
        ...blk,
        content: {
          ...blk.content,
          carouselItems: (blk.content.carouselItems ?? []).map((item) =>
            item.id === itemId ? { ...item, image: compressed } : item
          ),
        },
      }));
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Gagal memproses foto carousel.');
    }
  };

  const makeDefaultCarouselSlide = (index: number): CarouselItem => ({
    id: createId('slide'),
    image: SAMPLE_CAROUSEL_IMAGES[index % SAMPLE_CAROUSEL_IMAGES.length],
    title: `Foto #${index + 1}`,
    caption: 'Tambahkan keterangan singkat di bawah foto ini.',
    url: '',
  });

  const handleAddCarouselItem = () => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.carouselItems ?? [];
    if (current.length >= 20) return;
    updateContent({
      carouselItems: [...current, makeDefaultCarouselSlide(current.length)],
    });
  };

  const handleSetCarouselCount = (targetCount: number) => {
    if (!selectedBlock || Number.isNaN(targetCount)) return;
    const clamped = Math.max(1, Math.min(20, Math.round(targetCount)));
    const current = selectedBlock.content.carouselItems ?? [];
    if (clamped === current.length) return;
    if (clamped < current.length) {
      updateContent({ carouselItems: current.slice(0, clamped) });
    } else {
      const additions: CarouselItem[] = [];
      for (let i = current.length; i < clamped; i++) {
        additions.push(makeDefaultCarouselSlide(i));
      }
      updateContent({ carouselItems: [...current, ...additions] });
    }
  };

  const handleDeleteCarouselItem = (itemId: string) => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.carouselItems ?? [];
    updateContent({
      carouselItems: current.filter((item) => item.id !== itemId),
    });
  };

  const handleReorderCarouselItem = (draggedId: string, targetId: string) => {
    if (!selectedBlock || draggedId === targetId) return;
    const current = [...(selectedBlock.content.carouselItems ?? [])];
    const fromIdx = current.findIndex((i) => i.id === draggedId);
    const toIdx = current.findIndex((i) => i.id === targetId);
    if (fromIdx === -1 || toIdx === -1) return;
    const [moved] = current.splice(fromIdx, 1);
    current.splice(toIdx, 0, moved);
    updateContent({ carouselItems: current });
  };

  const handleSocialFeedAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !selectedBlock) return;
    const targetBlockId = selectedBlock.id;
    setUploadError(null);
    try {
      const compressed = await readAndCompressImage(file, { maxDimension: 480, quality: 0.84 });
      onUpdateBlock(targetBlockId, (blk) => ({
        ...blk,
        content: { ...blk.content, socialFeedAvatar: compressed },
      }));
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Gagal memproses foto profil.');
    }
  };

  const handleMapsPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !selectedBlock) return;
    const targetBlockId = selectedBlock.id;
    setUploadError(null);
    try {
      const compressed = await readAndCompressImage(file, { maxDimension: 1080, quality: 0.82 });
      onUpdateBlock(targetBlockId, (blk) => ({
        ...blk,
        content: { ...blk.content, mapsPhotoUrl: compressed },
      }));
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Gagal memproses foto lokasi.');
    }
  };

  const handleUpdateSocialPost = (postId: string, patch: Partial<SocialPostItem>) => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.socialFeedPosts ?? [];
    updateContent({
      socialFeedPosts: current.map((p) => (p.id === postId ? { ...p, ...patch } : p)),
    });
  };

  const handleSocialPostImageUpload = async (
    postId: string,
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !selectedBlock) return;
    const targetBlockId = selectedBlock.id;
    setUploadError(null);
    try {
      const compressed = await readAndCompressImage(file, { maxDimension: 1080, quality: 0.82 });
      onUpdateBlock(targetBlockId, (blk) => ({
        ...blk,
        content: {
          ...blk.content,
          socialFeedPosts: (blk.content.socialFeedPosts ?? []).map((p) =>
            p.id === postId ? { ...p, imageUrl: compressed } : p
          ),
        },
      }));
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Gagal memproses gambar postingan.');
    }
  };

  const handleSocialPostVideoUpload = async (
    postId: string,
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !selectedBlock) return;
    const targetBlockId = selectedBlock.id;
    setUploadError(null);
    try {
      const videoData = await readVideoFileSafe(file, 12);
      onUpdateBlock(targetBlockId, (blk) => ({
        ...blk,
        content: {
          ...blk.content,
          socialFeedPosts: (blk.content.socialFeedPosts ?? []).map((p) =>
            p.id === postId ? { ...p, videoUrl: videoData, mediaType: 'video' } : p
          ),
        },
      }));
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Gagal membaca file video.');
    }
  };

  const makeDefaultSocialPost = (index: number): SocialPostItem => ({
    id: createId('sfp'),
    mediaType: 'image',
    imageUrl: SAMPLE_CAROUSEL_IMAGES[index % SAMPLE_CAROUSEL_IMAGES.length],
    videoUrl: '',
    caption: `Postingan #${index + 1} — tambahkan cerita atau detail konten Anda di sini.`,
    likes: '245',
    comments: '18',
    url: '',
  });

  const handleAddSocialPost = () => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.socialFeedPosts ?? [];
    if (current.length >= 20) return;
    updateContent({
      socialFeedPosts: [...current, makeDefaultSocialPost(current.length)],
    });
  };

  const handleSetSocialPostCount = (targetCount: number) => {
    if (!selectedBlock || Number.isNaN(targetCount)) return;
    const clamped = Math.max(1, Math.min(20, Math.round(targetCount)));
    const current = selectedBlock.content.socialFeedPosts ?? [];
    if (clamped === current.length) return;
    if (clamped < current.length) {
      updateContent({ socialFeedPosts: current.slice(0, clamped) });
    } else {
      const additions: SocialPostItem[] = [];
      for (let i = current.length; i < clamped; i++) {
        additions.push(makeDefaultSocialPost(i));
      }
      updateContent({ socialFeedPosts: [...current, ...additions] });
    }
  };

  const handleDeleteSocialPost = (postId: string) => {
    if (!selectedBlock) return;
    const current = selectedBlock.content.socialFeedPosts ?? [];
    updateContent({
      socialFeedPosts: current.filter((p) => p.id !== postId),
    });
  };

  const handleReorderSocialPost = (draggedId: string, targetId: string) => {
    if (!selectedBlock || draggedId === targetId) return;
    const current = [...(selectedBlock.content.socialFeedPosts ?? [])];
    const fromIdx = current.findIndex((i) => i.id === draggedId);
    const toIdx = current.findIndex((i) => i.id === targetId);
    if (fromIdx === -1 || toIdx === -1) return;
    const [moved] = current.splice(fromIdx, 1);
    current.splice(toIdx, 0, moved);
    updateContent({ socialFeedPosts: current });
  };

  const renderAdvanceOptionSection = () => (
    <section className="space-y-4">
      <h3 className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#64748B]">
        Block Layout &amp; Tampilan Katalog
      </h3>

      {/* Show Unit Sold */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-800">
            <span>Show Unit Sold</span>
            <span
              title="Tampilkan jumlah unit terjual pada detail produk di katalog."
              className="text-slate-400 hover:text-slate-600 cursor-help"
            >
              <Info className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="text-xs text-slate-600 mt-0.5">
            Show total unit sold on product detail
          </div>
        </div>
        <ToggleSwitch
          checked={advanceOptions.showUnitSold}
          onChange={(checked) => onUpdateAdvanceOptions({ showUnitSold: checked })}
          label="Show total unit sold on product detail"
        />
      </div>

      {/* 5. Block Layout */}
      <div className="space-y-2.5 pt-1">
        <div className="text-xs font-semibold text-slate-800">Block Layout</div>
        <div className="grid grid-cols-2 gap-2.5">
          {(
            [
              { id: 'default', label: 'Default' },
              { id: 'grid', label: 'Grid' },
              { id: 'large-image', label: 'Large Image' },
              { id: 'compact', label: 'Compact' },
            ] as { id: BlockLayoutMode; label: string }[]
          ).map((option) => {
            const active = advanceOptions.blockLayout === option.id;
            return (
              <button
                key={option.id}
                type="button"
                onClick={() => onUpdateAdvanceOptions({ blockLayout: option.id })}
                className="flex flex-col items-center text-center group cursor-pointer focus-visible:outline-2 focus-visible:outline-emerald-600 rounded-xl"
              >
                <div
                  className={`relative w-full aspect-[4/3.6] rounded-xl p-1.5 border transition-all bg-white ${
                    active
                      ? 'border-emerald-500 ring-2 ring-emerald-500/20'
                      : 'border-slate-200 group-hover:border-slate-300'
                  }`}
                >
                  <LayoutWireframe mode={option.id} />
                </div>
                <span
                  className={`text-xs mt-1.5 font-medium ${
                    active ? 'text-emerald-700 font-semibold' : 'text-slate-700'
                  }`}
                >
                  {option.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
      </section>
  );

  const renderNavbarSettings = () => {
    const items = bottomNavbar.items;
    const activeItem =
      items.find((it) => it.id === activeNavItemId) ?? items[0] ?? null;

    const updateNavItem = (itemId: string, patch: Partial<BottomNavbarItem>) => {
      onUpdateBottomNavbar((prev) => ({
        ...prev,
        items: prev.items.map((it) => (it.id === itemId ? { ...it, ...patch } : it)),
      }));
    };

    const applyNavSheetTemplate = (
      itemId: string,
      tpl: 'galeri' | 'belanja' | 'kontak' | 'alamat' | 'form'
    ) => {
      let nextTitle = 'Informasi';
      let nextChildren: BuilderBlock[] = [];
      if (tpl === 'galeri') {
        nextTitle = 'Galeri Foto & Karya';
        const blk = createBlock('carousel', theme);
        nextChildren = [{ ...blk, style: { ...blk.style, marginBottom: 0 } }];
      } else if (tpl === 'belanja') {
        nextTitle = 'Belanja & Produk';
        const blk = createBlock('catalog', theme);
        nextChildren = [{ ...blk, style: { ...blk.style, marginBottom: 0 } }];
      } else if (tpl === 'kontak') {
        nextTitle = 'Hubungi Kami';
        const txt = createBlock('text', theme);
        const btn = createBlock('button', theme);
        const soc = createBlock('social', theme);
        nextChildren = [
          {
            ...txt,
            label: 'Info Kontak',
            style: { ...txt.style, align: 'left', marginBottom: 10 },
            content: {
              text: 'Pilih saluran tercepat untuk terhubung langsung dengan tim kami.',
              variant: 'body',
              fontWeight: 'normal',
            },
          },
          {
            ...btn,
            label: 'Tombol WhatsApp',
            style: { ...btn.style, marginBottom: 12 },
            content: {
              label: 'Chat via WhatsApp',
              url: 'https://wa.me/6281234567890',
              buttonBg: '#059669',
              buttonText: '#FFFFFF',
              buttonIcon: 'phone',
            },
          },
          { ...soc, style: { ...soc.style, marginBottom: 0 } },
        ];
      } else if (tpl === 'alamat') {
        nextTitle = 'Alamat & Lokasi Maps';
        const blk = createBlock('maps_place', theme);
        nextChildren = [{ ...blk, style: { ...blk.style, marginBottom: 0 } }];
      } else {
        nextTitle = 'Formulir Pesan';
        const blk = createBlock('form', theme);
        nextChildren = [{ ...blk, style: { ...blk.style, marginBottom: 0 } }];
      }
      updateNavItem(itemId, {
        action: 'sheet',
        sheetTitle: nextTitle,
        children: nextChildren,
      });
    };

    const slotLabel = (idx: number) => {
      if (idx === 0) return 'Menu Kiri 1';
      if (idx === 1) return 'Menu Kiri 2';
      if (idx === 2) return 'Menu Tengah (Home)';
      if (idx === 3) return 'Menu Kanan 1';
      return 'Menu Kanan 2';
    };

    return (
      <div className="flex-1 overflow-y-auto p-3.5 space-y-3.5 bg-[#F8FAFC]">
        {/* Kotak 1: Status & Tampilan Navbar */}
        <div className="p-3 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-3">
          <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-100">
            <div>
              <h4 className="text-[13px] font-bold text-slate-900">Navbar Bawah</h4>
              <p className="text-[11px] text-slate-500">
                Aktifkan menu mengambang dengan Modal Bottom Sheet
              </p>
            </div>
            <ToggleSwitch
              checked={bottomNavbar.enabled}
              onChange={(checked) =>
                onUpdateBottomNavbar((prev) => ({ ...prev, enabled: checked }))
              }
              label="Aktifkan Navbar Bawah"
            />
          </div>

          <div>
            <div className="text-xs font-semibold text-slate-700 mb-1.5">
              Gaya Tombol Tengah (Home)
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {(
                [
                  { id: 'elevated', label: 'Menonjol (Bulat)' },
                  { id: 'inline', label: 'Sejajar Rata' },
                ] as const
              ).map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() =>
                    onUpdateBottomNavbar((prev) => ({ ...prev, centerStyle: opt.id }))
                  }
                  className={`py-1.5 px-2 rounded-lg text-[11px] font-semibold border transition-colors cursor-pointer ${
                    bottomNavbar.centerStyle === opt.id
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-700">Warna Navbar</span>
              <button
                type="button"
                onClick={() =>
                  onUpdateBottomNavbar((prev) => ({
                    ...prev,
                    barBg: theme.cardBg,
                    textColor: theme.textColor,
                    accentColor: theme.accentColor,
                    borderColor: theme.borderColor,
                  }))
                }
                className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 hover:underline cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Samakan Tema</span>
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-medium text-slate-500 mb-1">
                  Latar Bar
                </label>
                <input
                  type="color"
                  value={bottomNavbar.barBg}
                  onChange={(e) =>
                    onUpdateBottomNavbar((prev) => ({ ...prev, barBg: e.target.value }))
                  }
                  className="w-full h-8 rounded-lg border border-slate-200 bg-white p-0.5 cursor-pointer"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-500 mb-1">
                  Teks &amp; Ikon
                </label>
                <input
                  type="color"
                  value={bottomNavbar.textColor}
                  onChange={(e) =>
                    onUpdateBottomNavbar((prev) => ({ ...prev, textColor: e.target.value }))
                  }
                  className="w-full h-8 rounded-lg border border-slate-200 bg-white p-0.5 cursor-pointer"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-500 mb-1">
                  Aksen (Home)
                </label>
                <input
                  type="color"
                  value={bottomNavbar.accentColor}
                  onChange={(e) =>
                    onUpdateBottomNavbar((prev) => ({ ...prev, accentColor: e.target.value }))
                  }
                  className="w-full h-8 rounded-lg border border-slate-200 bg-white p-0.5 cursor-pointer"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-500 mb-1">
                  Garis Atas
                </label>
                <input
                  type="color"
                  value={bottomNavbar.borderColor}
                  onChange={(e) =>
                    onUpdateBottomNavbar((prev) => ({ ...prev, borderColor: e.target.value }))
                  }
                  className="w-full h-8 rounded-lg border border-slate-200 bg-white p-0.5 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Kotak 2: Daftar 5 Menu & Editor Menu Terpilih */}
        <div className="p-3 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-3">
          <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-100">
            <h4 className="text-[13px] font-bold text-slate-900">5 Menu Navbar</h4>
            <span className="text-[11px] text-slate-400">Klik menu untuk edit</span>
          </div>

          <div className="grid grid-cols-5 gap-1">
            {items.map((it) => {
              const isSelectedNav = activeItem?.id === it.id;
              const icId = resolveButtonIcon(it.icon, it.label);
              const glyph = icId === 'none' ? 'info' : icId;
              return (
                <button
                  key={it.id}
                  type="button"
                  onClick={() => onSelectNavItem(it.id)}
                  className={`relative flex flex-col items-center justify-center gap-1 py-2 px-1 rounded-lg border text-center transition-all cursor-pointer min-w-0 ${
                    isSelectedNav
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  } ${it.enabled === false ? 'opacity-50' : ''}`}
                >
                  <span
                    className={`absolute top-1 right-1 w-1.5 h-1.5 rounded-full ${
                      it.enabled !== false
                        ? isSelectedNav
                          ? 'bg-emerald-200'
                          : 'bg-emerald-500'
                        : 'bg-slate-400'
                    }`}
                  />
                  <ButtonGlyph icon={glyph} className="w-3.5 h-3.5 shrink-0" />
                  <span className="text-[10px] font-semibold truncate max-w-full">
                    {it.label || 'Menu'}
                  </span>
                </button>
              );
            })}
          </div>

          {activeItem && (() => {
            const activeIdx = items.findIndex((i) => i.id === activeItem.id);
            const activeIcon = resolveButtonIcon(activeItem.icon, activeItem.label);
            return (
              <div className="pt-2 border-t border-slate-100 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      {activeItem.label || 'Menu'}
                    </div>
                    <div className="text-[11px] text-slate-400">{slotLabel(activeIdx)}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-medium text-slate-500">
                      {activeItem.enabled !== false ? 'Aktif' : 'Nonaktif'}
                    </span>
                    <ToggleSwitch
                      checked={activeItem.enabled !== false}
                      onChange={(checked) => updateNavItem(activeItem.id, { enabled: checked })}
                      label={`Aktifkan menu ${activeItem.label}`}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Label Menu
                  </label>
                  <input
                    type="text"
                    value={activeItem.label}
                    onChange={(e) => updateNavItem(activeItem.id, { label: e.target.value })}
                    placeholder="Contoh: Galeri"
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:border-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <div className="text-xs font-medium text-slate-700 mb-1.5">Pilih Ikon</div>
                  <div className="grid grid-cols-4 gap-1">
                    {BUTTON_ICON_LIST.filter((ic) => ic.id !== 'none').map((ic) => {
                      const active = activeIcon === ic.id;
                      return (
                        <button
                          key={ic.id}
                          type="button"
                          onClick={() =>
                            updateNavItem(activeItem.id, { icon: ic.id as ButtonIconId })
                          }
                          className={`flex flex-col items-center justify-center gap-0.5 py-1.5 px-1 rounded-lg border text-[10px] font-medium transition-colors cursor-pointer ${
                            active
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          <ButtonGlyph icon={ic.id} className="w-3.5 h-3.5" />
                          <span className="truncate max-w-full">{ic.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Aksi Saat Diklik
                  </label>
                  <select
                    value={activeItem.action}
                    onChange={(e) =>
                      updateNavItem(activeItem.id, {
                        action: e.target.value as BottomNavbarItemAction,
                      })
                    }
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:border-emerald-500 outline-none"
                  >
                    <option value="sheet">Buka Modal Bottom Sheet</option>
                    <option value="scroll_top">Ke Atas / Beranda (Home)</option>
                  </select>
                </div>

                {activeItem.action === 'sheet' && (
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/90 space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-slate-800">
                        Isi Modal Bottom Sheet
                      </span>
                      <span className="text-[11px] text-slate-400 tabular-nums">
                        {activeItem.children.length} elemen
                      </span>
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-1">
                        Judul Modal Sheet
                      </label>
                      <input
                        type="text"
                        value={activeItem.sheetTitle}
                        onChange={(e) =>
                          updateNavItem(activeItem.id, { sheetTitle: e.target.value })
                        }
                        placeholder={activeItem.label}
                        className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:border-emerald-500 outline-none"
                      />
                    </div>

                    <div>
                      <div className="text-[11px] font-semibold text-slate-600 mb-1.5">
                        Isi Cepat Template
                      </div>
                      <div className="grid grid-cols-2 gap-1.5">
                        {(
                          [
                            { id: 'galeri', label: 'Galeri Foto' },
                            { id: 'belanja', label: 'Katalog Belanja' },
                            { id: 'kontak', label: 'Kontak & WA' },
                            { id: 'alamat', label: 'Alamat & Maps' },
                            { id: 'form', label: 'Form Isian' },
                          ] as const
                        ).map((tpl) => (
                          <button
                            key={tpl.id}
                            type="button"
                            onClick={() => applyNavSheetTemplate(activeItem.id, tpl.id)}
                            className="py-1.5 px-2 rounded-lg bg-white border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/40 text-[11px] font-medium text-slate-700 cursor-pointer text-left truncate transition-colors"
                          >
                            {tpl.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="text-[11px] font-semibold text-slate-600 mb-1.5">
                        Elemen di Dalam Modal
                      </div>
                      {activeItem.children.length > 0 ? (
                        <div className="space-y-1.5">
                          {activeItem.children.map((child, cIdx) => (
                            <div
                              key={child.id}
                              className="flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white"
                            >
                              <button
                                type="button"
                                onClick={() => onSelectBlock?.(child.id)}
                                className="min-w-0 flex-1 text-left cursor-pointer hover:text-emerald-700"
                              >
                                <div className="text-xs font-semibold text-slate-800 truncate">
                                  {cIdx + 1}. {child.label.trim() || BLOCK_TYPE_NAMES[child.type]}
                                </div>
                                <div className="text-[11px] text-slate-400 truncate">
                                  {BLOCK_TYPE_NAMES[child.type]} · Klik untuk edit
                                </div>
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  updateNavItem(activeItem.id, {
                                    children: activeItem.children.filter(
                                      (ch) => ch.id !== child.id
                                    ),
                                  })
                                }
                                title="Hapus elemen dari modal"
                                className="p-1 rounded hover:bg-red-50 text-slate-400 hover:text-red-600 cursor-pointer shrink-0"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="py-3 px-2.5 rounded-lg border border-dashed border-slate-300 bg-white text-center text-[11px] text-slate-400">
                          Modal sheet ini masih kosong.
                        </div>
                      )}
                    </div>

                    <div>
                      <div className="text-[11px] font-semibold text-slate-600 mb-1.5">
                        + Tambah Elemen ke Modal
                      </div>
                      <div className="grid grid-cols-2 gap-1.5">
                        {(
                          [
                            { type: 'carousel', label: 'Galeri Foto' },
                            { type: 'catalog', label: 'Katalog Produk' },
                            { type: 'maps_place', label: 'Maps & Ulasan' },
                            { type: 'button', label: 'Tombol CTA' },
                            { type: 'text', label: 'Teks / Info' },
                            { type: 'social', label: 'Ikon Sosmed' },
                            { type: 'image', label: 'Gambar' },
                            { type: 'form', label: 'Form Isian' },
                          ] as { type: BlockType; label: string }[]
                        ).map((opt) => (
                          <button
                            key={opt.type}
                            type="button"
                            onClick={() => onAddChildToContainer(activeItem.id, opt.type)}
                            className="flex items-center gap-1 py-1.5 px-2 rounded-lg border border-slate-200 bg-white hover:border-emerald-400 hover:bg-emerald-50/40 text-[11px] font-medium text-slate-700 cursor-pointer truncate transition-colors"
                          >
                            <Plus className="w-3 h-3 text-emerald-600 shrink-0" />
                            <span className="truncate">{opt.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })()}
        </div>
      </div>
    );
  };

  const renderElementSettings = () => {
    if (!selectedBlock) {
      return (
        <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-4">
          <div className="w-11 h-11 rounded-xl bg-[#EFF7F4] text-emerald-600 flex items-center justify-center">
            <SlidersHorizontal className="w-5 h-5" />
          </div>
          <div className="space-y-1.5">
            <div className="text-[14px] font-semibold text-slate-800">Belum Ada Elemen Dipilih</div>
            <p className="text-[13px] text-slate-500 leading-relaxed">
              Klik elemen mana saja pada kanvas HP atau tab <strong>Lapisan</strong> untuk mengubah teks, tautan, spasi, dan tampilannya.
            </p>
          </div>
          <div className="w-full p-3 rounded-xl border border-slate-200 bg-slate-50/80 text-left space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="text-xs font-bold text-slate-800">Navbar Bawah (5 Menu)</div>
                <div className="text-[11px] text-slate-500 truncate">
                  {bottomNavbar.enabled ? 'Aktif di halaman bawah' : 'Belum diaktifkan'}
                </div>
              </div>
              <ToggleSwitch
                checked={bottomNavbar.enabled}
                onChange={(checked) =>
                  onUpdateBottomNavbar((prev) => ({ ...prev, enabled: checked }))
                }
                label="Aktifkan Navbar Bawah"
              />
            </div>
            <button
              type="button"
              onClick={() => onChangeInspectorMode('navbar')}
              className="w-full py-1.5 px-3 rounded-lg bg-white border border-slate-200 hover:border-emerald-400 text-xs font-semibold text-emerald-700 cursor-pointer transition-colors"
            >
              Atur 5 Menu Navbar
            </button>
          </div>
        </div>
      );
    }

    const s = selectedBlock.style;
    const c = selectedBlock.content;

    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        {selectedParentNavId && (
          <div className="px-4 py-2 bg-emerald-50/80 border-b border-emerald-100 shrink-0">
            <button
              type="button"
              onClick={() => {
                onSelectNavItem(selectedParentNavId);
                onChangeInspectorMode('navbar');
              }}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-800 hover:text-emerald-950 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Kembali ke Navbar ({selectedParentNavLabel || 'Menu'})</span>
            </button>
          </div>
        )}
        {/* Sticky Element Header + Konten / Tampilan Tab Switcher */}
        <div className="px-4 pt-3 pb-3 border-b border-slate-100 bg-white space-y-3 shrink-0">
          <div className="flex items-center justify-between gap-2">
            <div className="min-w-0">
              <div className="text-[14px] font-semibold text-slate-800 truncate">
                {selectedBlock.label}
              </div>
              <div className="text-[12px] text-emerald-600 font-medium">
                {BLOCK_TYPE_NAMES[selectedBlock.type]}
              </div>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button
                type="button"
                onClick={() => onDuplicateBlock(selectedBlock.id)}
                title="Duplikat Elemen"
                className="p-1.5 rounded-lg border border-slate-200/80 text-slate-500 hover:bg-[#EFF7F4] hover:text-emerald-700 transition-colors cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={handleResetStyle}
                title="Reset Gaya Elemen"
                className="p-1.5 rounded-lg border border-slate-200/80 text-slate-500 hover:bg-[#EFF7F4] hover:text-emerald-700 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div
            role="tablist"
            aria-label="Kategori Pengaturan Elemen"
            className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-slate-100"
          >
            <button
              type="button"
              role="tab"
              aria-selected={inspectorTab === 'content'}
              onClick={() => setInspectorTab('content')}
              className={`inline-flex items-center justify-center gap-1.5 py-1.5 px-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                inspectorTab === 'content'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Type className="w-3.5 h-3.5" />
              <span>Konten</span>
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={inspectorTab === 'appearance'}
              onClick={() => setInspectorTab('appearance')}
              className={`inline-flex items-center justify-center gap-1.5 py-1.5 px-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                inspectorTab === 'appearance'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Palette className="w-3.5 h-3.5" />
              <span>Tampilan</span>
            </button>
          </div>
        </div>

        {/* Scrollable Tab Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {uploadError && (
            <div className="p-2.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-[11px] font-medium flex items-start justify-between gap-2">
              <span>{uploadError}</span>
              <button
                type="button"
                onClick={() => setUploadError(null)}
                className="p-0.5 text-red-500 hover:text-red-700 cursor-pointer shrink-0"
                aria-label="Tutup peringatan"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {inspectorTab === 'content' && (
            <section className="space-y-3">
              <h3 className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#64748B]">
                Konten Elemen
              </h3>

          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Nama Lapisan</label>
            <input
              type="text"
              value={selectedBlock.label}
              onChange={(e) =>
                onUpdateBlock(selectedBlock.id, (blk) => ({ ...blk, label: e.target.value }))
              }
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 focus:border-blue-500 outline-none"
            />
          </div>

          {selectedBlock.type === 'container' && (
            <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
              <div className="text-xs font-medium text-slate-700">Tambah ke Dalam Wadah:</div>
              <div className="grid grid-cols-2 gap-1.5">
                {(['text', 'image', 'button', 'divider'] as BlockType[]).map((childType) => (
                  <button
                    key={childType}
                    type="button"
                    onClick={() => onAddChildToContainer(selectedBlock.id, childType)}
                    className="inline-flex items-center justify-center gap-1 py-1.5 px-2 rounded-md bg-white border border-slate-200 hover:border-blue-400 text-xs font-medium text-slate-700 cursor-pointer"
                  >
                    <Plus className="w-3 h-3 text-blue-600" />
                    <span>{BLOCK_TYPE_NAMES[childType]}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {selectedBlock.type === 'toggle_container' && (
            <div className="space-y-3">
              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2.5">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Teks Tombol saat Sembunyi (Tutup)
                  </label>
                  <input
                    type="text"
                    value={c.toggleShowLabel ?? 'Tampilkan Konten'}
                    placeholder="Tampilkan Konten"
                    onChange={(e) => updateContent({ toggleShowLabel: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:border-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Teks Tombol saat Tampil (Buka)
                  </label>
                  <input
                    type="text"
                    value={c.toggleHideLabel ?? 'Sembunyikan Konten'}
                    placeholder="Sembunyikan Konten"
                    onChange={(e) => updateContent({ toggleHideLabel: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:border-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Kondisi Awal (Saat Halaman Dibuka)
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => updateContent({ toggleDefaultOpen: false })}
                      className={`py-1.5 px-2 rounded-lg text-[11px] font-semibold border transition-colors cursor-pointer ${
                        !c.toggleDefaultOpen
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      Hide (Default)
                    </button>
                    <button
                      type="button"
                      onClick={() => updateContent({ toggleDefaultOpen: true })}
                      className={`py-1.5 px-2 rounded-lg text-[11px] font-semibold border transition-colors cursor-pointer ${
                        c.toggleDefaultOpen
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      Show (Terbuka)
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Gaya Tombol
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    {(['solid', 'outline'] as const).map((variant) => {
                      const active = (c.toggleButtonStyle ?? 'solid') === variant;
                      return (
                        <button
                          key={variant}
                          type="button"
                          onClick={() => updateContent({ toggleButtonStyle: variant })}
                          className={`py-1 rounded-lg text-[11px] font-semibold border capitalize transition-colors cursor-pointer ${
                            active
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {variant === 'solid' ? 'Penuh (Solid)' : 'Garis (Outline)'}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] font-medium text-slate-500 mb-1">
                      Warna Tombol
                    </label>
                    <input
                      type="color"
                      value={c.toggleButtonBg ?? '#2563EB'}
                      onChange={(e) => updateContent({ toggleButtonBg: e.target.value })}
                      className="w-full h-8 rounded border border-slate-200 bg-white p-0.5 cursor-pointer"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-medium text-slate-500 mb-1">
                      Warna Teks
                    </label>
                    <input
                      type="color"
                      value={c.toggleButtonText ?? '#FFFFFF'}
                      onChange={(e) => updateContent({ toggleButtonText: e.target.value })}
                      className="w-full h-8 rounded border border-slate-200 bg-white p-0.5 cursor-pointer"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1.5">
                    Ikon Sebelah Kiri Tombol
                  </label>
                  <div className="grid grid-cols-4 gap-1">
                    {BUTTON_ICON_LIST.map((ic) => {
                      const activeIcon = resolveButtonIcon(
                        c.toggleButtonIcon,
                        c.toggleShowLabel ?? 'Tampilkan Konten'
                      );
                      const isActive = activeIcon === ic.id;
                      return (
                        <button
                          key={ic.id}
                          type="button"
                          onClick={() => updateContent({ toggleButtonIcon: ic.id })}
                          className={`flex flex-col items-center justify-center gap-0.5 py-1.5 px-1 rounded-lg border text-[10px] font-medium transition-colors cursor-pointer ${
                            isActive
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {ic.id === 'none' ? (
                            <span className="h-3.5 leading-3.5 text-[11px] font-bold">—</span>
                          ) : (
                            <ButtonGlyph icon={ic.id} className="w-3.5 h-3.5" />
                          )}
                          <span className="truncate max-w-full">{ic.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
                <div className="text-xs font-medium text-slate-700">Tambah ke Dalam Wadah:</div>
                <div className="grid grid-cols-2 gap-1.5">
                  {(['text', 'image', 'button', 'form', 'youtube', 'divider'] as BlockType[]).map(
                    (childType) => (
                      <button
                        key={childType}
                        type="button"
                        onClick={() => onAddChildToContainer(selectedBlock.id, childType)}
                        className="inline-flex items-center justify-center gap-1 py-1.5 px-2 rounded-md bg-white border border-slate-200 hover:border-blue-400 text-xs font-medium text-slate-700 cursor-pointer"
                      >
                        <Plus className="w-3 h-3 text-blue-600" />
                        <span>{BLOCK_TYPE_NAMES[childType]}</span>
                      </button>
                    )
                  )}
                </div>
              </div>
            </div>
          )}

          {selectedBlock.type === 'bottom_sheet' && (() => {
            const triggerStyle = c.sheetTriggerStyle ?? 'icon';
            const triggerLabel = c.sheetTriggerLabel ?? 'Lokasi Maps';
            const activeIcon = resolveButtonIcon(c.sheetTriggerIcon ?? 'map-pin', triggerLabel);
            const children = selectedBlock.children ?? [];

            const applySheetTemplate = (
              templateId: 'maps' | 'contact' | 'promo' | 'form'
            ) => {
              let nextTitle = 'Lokasi & Ulasan';
              let nextChildren: BuilderBlock[] = [];
              if (templateId === 'maps') {
                nextTitle = 'Lokasi & Ulasan';
                const mapBlk = createBlock('maps_place', theme);
                nextChildren = [{ ...mapBlk, style: { ...mapBlk.style, marginBottom: 0 } }];
              } else if (templateId === 'contact') {
                nextTitle = 'Hubungi Kami';
                const txt = createBlock('text', theme);
                const btn = createBlock('button', theme);
                const soc = createBlock('social', theme);
                nextChildren = [
                  {
                    ...txt,
                    label: 'Info Kontak',
                    style: { ...txt.style, align: 'left', marginBottom: 8 },
                    content: {
                      text: 'Pilih saluran tercepat untuk terhubung langsung dengan tim kami.',
                      variant: 'body',
                      fontWeight: 'normal',
                    },
                  },
                  {
                    ...btn,
                    label: 'Tombol WhatsApp',
                    style: { ...btn.style, marginBottom: 12 },
                    content: {
                      label: 'Chat via WhatsApp',
                      url: 'https://wa.me/6281234567890',
                      buttonBg: '#059669',
                      buttonText: '#FFFFFF',
                      buttonIcon: 'phone',
                    },
                  },
                  {
                    ...soc,
                    style: { ...soc.style, marginBottom: 0 },
                  },
                ];
              } else if (templateId === 'promo') {
                nextTitle = 'Info & Promo Spesial';
                const img = createBlock('image', theme);
                const txt = createBlock('text', theme);
                const btn = createBlock('button', theme);
                nextChildren = [
                  {
                    ...img,
                    style: { ...img.style, marginBottom: 10 },
                  },
                  {
                    ...txt,
                    label: 'Judul Promo',
                    style: { ...txt.style, align: 'left', marginBottom: 10 },
                    content: {
                      text: 'Penawaran terbatas minggu ini — klik tombol di bawah untuk klaim langsung.',
                      variant: 'body',
                      fontWeight: 'normal',
                    },
                  },
                  {
                    ...btn,
                    style: { ...btn.style, marginBottom: 0 },
                    content: {
                      label: 'Ambil Promo Sekarang',
                      url: 'https://example.com/promo',
                      buttonBg: theme.accentColor,
                      buttonText: '#FFFFFF',
                      buttonIcon: 'shopping-bag',
                    },
                  },
                ];
              } else {
                nextTitle = 'Formulir Pendaftaran';
                const frm = createBlock('form', theme);
                nextChildren = [{ ...frm, style: { ...frm.style, marginBottom: 0 } }];
              }

              onUpdateBlock(selectedBlock.id, (blk) => ({
                ...blk,
                content: {
                  ...blk.content,
                  sheetTitle: nextTitle,
                },
                children: nextChildren,
              }));
            };

            return (
              <div className="space-y-3.5">
                {/* Kotak 1: Pemicu (Icon / Tombol) */}
                <div className="p-3 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-3">
                  <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-100">
                    <h4 className="text-[13px] font-bold text-slate-900">Pemicu Bottom Sheet</h4>
                    <span className="text-[11px] text-slate-400">Tampilan Klik</span>
                  </div>

                  <div>
                    <div className="text-xs font-semibold text-slate-700 mb-1.5">Gaya Pemicu</div>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(
                        [
                          { id: 'icon', label: 'Ikon Bulat' },
                          { id: 'pill', label: 'Kapsul' },
                          { id: 'button', label: 'Tombol' },
                        ] as { id: BottomSheetTriggerStyle; label: string }[]
                      ).map((opt) => (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => updateContent({ sheetTriggerStyle: opt.id })}
                          className={`py-1.5 px-2 rounded-lg text-[11px] font-semibold border transition-colors cursor-pointer ${
                            triggerStyle === opt.id
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-xs font-semibold text-slate-700 mb-1.5">Pilih Ikon</div>
                    <div className="grid grid-cols-4 gap-1">
                      {BUTTON_ICON_LIST.map((ic) => {
                        const isActive = activeIcon === ic.id;
                        return (
                          <button
                            key={ic.id}
                            type="button"
                            onClick={() => updateContent({ sheetTriggerIcon: ic.id })}
                            className={`flex flex-col items-center justify-center gap-0.5 py-1.5 px-1 rounded-lg border text-[10px] font-medium transition-colors cursor-pointer ${
                              isActive
                                ? 'bg-blue-600 text-white border-blue-600'
                                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            {ic.id === 'none' ? (
                              <span className="h-3.5 leading-3.5 text-[11px] font-bold">—</span>
                            ) : (
                              <ButtonGlyph icon={ic.id} className="w-3.5 h-3.5" />
                            )}
                            <span className="truncate max-w-full">{ic.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {triggerStyle === 'icon' && (
                    <div>
                      <div className="flex items-center justify-between text-xs font-medium text-slate-700 mb-1">
                        <span>Ukuran Ikon</span>
                        <span className="text-[11px] text-slate-400 tabular-nums">
                          {c.sheetIconSize ?? 52}px
                        </span>
                      </div>
                      <input
                        type="range"
                        min={36}
                        max={72}
                        step={2}
                        value={c.sheetIconSize ?? 52}
                        onChange={(e) => updateContent({ sheetIconSize: Number(e.target.value) })}
                        className="w-full accent-blue-600 cursor-pointer"
                      />
                    </div>
                  )}

                  <div className="space-y-2">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Label Teks
                      </label>
                      <input
                        type="text"
                        value={triggerLabel}
                        placeholder="Lokasi Maps"
                        onChange={(e) => updateContent({ sheetTriggerLabel: e.target.value })}
                        className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:border-blue-500 outline-none"
                      />
                    </div>
                    {triggerStyle !== 'button' && (
                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Keterangan <span className="text-[11px] font-normal text-slate-400">(opsional)</span>
                        </label>
                        <input
                          type="text"
                          value={c.sheetTriggerSublabel ?? ''}
                          placeholder="Lihat lokasi & ulasan"
                          onChange={(e) =>
                            updateContent({ sheetTriggerSublabel: e.target.value })
                          }
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:border-blue-500 outline-none"
                        />
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] font-medium text-slate-500 mb-1">
                        Warna Latar
                      </label>
                      <input
                        type="color"
                        value={c.sheetTriggerBg || theme.accentColor}
                        onChange={(e) => updateContent({ sheetTriggerBg: e.target.value })}
                        className="w-full h-8 rounded-lg border border-slate-200 bg-white p-0.5 cursor-pointer"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-slate-500 mb-1">
                        Warna Ikon / Teks
                      </label>
                      <input
                        type="color"
                        value={c.sheetTriggerText ?? '#FFFFFF'}
                        onChange={(e) => updateContent({ sheetTriggerText: e.target.value })}
                        className="w-full h-8 rounded-lg border border-slate-200 bg-white p-0.5 cursor-pointer"
                      />
                    </div>
                  </div>
                </div>

                {/* Kotak 2: Isi Bottom Sheet */}
                <div className="p-3 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-3">
                  <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-100">
                    <h4 className="text-[13px] font-bold text-slate-900">Isi Bottom Sheet</h4>
                    <span className="text-[11px] text-slate-400 tabular-nums">
                      {children.length} elemen
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Judul Bottom Sheet
                    </label>
                    <input
                      type="text"
                      value={c.sheetTitle ?? 'Lokasi & Ulasan'}
                      placeholder="Lokasi & Ulasan"
                      onChange={(e) => updateContent({ sheetTitle: e.target.value })}
                      className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:border-blue-500 outline-none"
                    />
                  </div>

                  <div>
                    <div className="text-xs font-semibold text-slate-700 mb-1.5">
                      Isi Cepat Template
                    </div>
                    <div className="grid grid-cols-2 gap-1.5">
                      {(
                        [
                          { id: 'maps', label: 'Maps & Ulasan' },
                          { id: 'contact', label: 'Kontak & WA' },
                          { id: 'promo', label: 'Promo / Info' },
                          { id: 'form', label: 'Form Isian' },
                        ] as const
                      ).map((tpl) => (
                        <button
                          key={tpl.id}
                          type="button"
                          onClick={() => applySheetTemplate(tpl.id)}
                          className="py-1.5 px-2 rounded-lg bg-slate-50 border border-slate-200 hover:border-blue-400 hover:bg-blue-50/40 text-[11px] font-medium text-slate-700 cursor-pointer text-left truncate transition-colors"
                        >
                          {tpl.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-xs font-semibold text-slate-700 mb-1.5">
                      Elemen di Dalam Sheet
                    </div>
                    {children.length > 0 ? (
                      <div className="space-y-1.5">
                        {children.map((child, idx) => (
                          <div
                            key={child.id}
                            className="flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-slate-50"
                          >
                            <button
                              type="button"
                              onClick={() => onSelectBlock?.(child.id)}
                              className="min-w-0 flex-1 text-left cursor-pointer hover:text-blue-600"
                            >
                              <div className="text-xs font-semibold text-slate-800 truncate">
                                {idx + 1}. {child.label.trim() || BLOCK_TYPE_NAMES[child.type]}
                              </div>
                              <div className="text-[11px] text-slate-400 truncate">
                                {BLOCK_TYPE_NAMES[child.type]} · Klik untuk edit
                              </div>
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                onUpdateBlock(selectedBlock.id, (blk) => ({
                                  ...blk,
                                  children: (blk.children ?? []).filter(
                                    (ch) => ch.id !== child.id
                                  ),
                                }))
                              }
                              title="Hapus elemen ini dari sheet"
                              className="p-1 rounded hover:bg-red-50 text-slate-400 hover:text-red-600 cursor-pointer shrink-0"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="py-3 px-2.5 rounded-lg border border-dashed border-slate-200 text-center text-[11px] text-slate-400">
                        Belum ada elemen di dalam sheet
                      </div>
                    )}
                  </div>

                  <div>
                    <div className="text-xs font-semibold text-slate-700 mb-1.5">
                      Tambah Elemen ke Sheet
                    </div>
                    <div className="grid grid-cols-2 gap-1.5">
                      {(
                        [
                          'maps_place',
                          'text',
                          'image',
                          'button',
                          'form',
                          'catalog',
                          'carousel',
                          'social',
                        ] as BlockType[]
                      ).map((childType) => (
                        <button
                          key={childType}
                          type="button"
                          onClick={() => onAddChildToContainer(selectedBlock.id, childType)}
                          className="inline-flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg bg-slate-50 border border-slate-200 hover:border-blue-400 text-[11px] font-medium text-slate-700 cursor-pointer"
                        >
                          <Plus className="w-3 h-3 text-blue-600 shrink-0" />
                          <span className="truncate">{BLOCK_TYPE_NAMES[childType]}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}

          {selectedBlock.type === 'catalog' && (() => {
            const cartEnabled = c.catalogCartEnabled ?? true;
            const detailEnabled = c.catalogDetailEnabled ?? true;
            const productType = c.catalogProductType ?? 'physical';
            const hasPhysicalItem =
              productType === 'physical' ||
              (c.catalogItems ?? []).some((it) => it.productType === 'physical');
            const items = c.catalogItems ?? [];

            return (
              <div className="space-y-3.5">
                {/* Kotak 1: Fitur Halaman */}
                <div className="p-3 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-3">
                  <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-100">
                    <h4 className="text-[13px] font-bold text-slate-900 flex items-center gap-1.5">
                      <ShoppingCart className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Fitur Katalog</span>
                    </h4>
                    <span className="text-[11px] text-slate-400">Tampilan &amp; Alur</span>
                  </div>

                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-medium text-slate-700">Halaman Detail</span>
                      <ToggleSwitch
                        checked={detailEnabled}
                        onChange={(checked) => updateContent({ catalogDetailEnabled: checked })}
                        label="Halaman Detail"
                      />
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-medium text-slate-700">
                        Keranjang WhatsApp
                      </span>
                      <ToggleSwitch
                        checked={cartEnabled}
                        onChange={(checked) => updateContent({ catalogCartEnabled: checked })}
                        label="Keranjang WhatsApp"
                      />
                    </div>
                  </div>

                  {cartEnabled && (
                    <div className="pt-2.5 border-t border-slate-100 space-y-3">
                      <div className="space-y-1.5">
                        <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                          Jenis Produk
                        </div>
                        <div className="grid grid-cols-2 gap-1.5">
                          {(
                            [
                              { id: 'physical', label: 'Produk Fisik' },
                              { id: 'service', label: 'Produk Jasa' },
                            ] as { id: CatalogProductType; label: string }[]
                          ).map((pt) => {
                            const active = productType === pt.id;
                            return (
                              <button
                                key={pt.id}
                                type="button"
                                onClick={() => updateContent({ catalogProductType: pt.id })}
                                className={`py-1.5 px-2.5 rounded-lg text-xs font-semibold border cursor-pointer transition-colors ${
                                  active
                                    ? 'bg-emerald-600 text-white border-emerald-600'
                                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                                }`}
                              >
                                {pt.label}
                              </button>
                            );
                          })}
                        </div>
                        <p className="text-[11px] text-slate-400 leading-snug">
                          {productType === 'service'
                            ? 'Hanya form data pemesan.'
                            : 'Data pemesan + opsi kirim / ambil.'}
                        </p>
                      </div>

                      <div className="space-y-1.5">
                        <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                          Tombol Keranjang
                        </div>
                        <div className="grid grid-cols-3 gap-1.5">
                          {(
                            [
                              { id: 'sm', label: 'Kecil' },
                              { id: 'md', label: 'Sedang' },
                              { id: 'lg', label: 'Besar' },
                            ] as { id: CatalogCartButtonSize; label: string }[]
                          ).map((sz) => {
                            const active = (c.catalogCartButtonSize ?? 'md') === sz.id;
                            return (
                              <button
                                key={sz.id}
                                type="button"
                                onClick={() => updateContent({ catalogCartButtonSize: sz.id })}
                                className={`py-1.5 px-2 rounded-lg text-xs font-semibold border cursor-pointer transition-colors ${
                                  active
                                    ? 'bg-emerald-600 text-white border-emerald-600'
                                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                                }`}
                              >
                                {sz.label}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Kotak 2: Pesan WhatsApp */}
                {cartEnabled && (
                  <div className="p-3 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-2.5">
                    <div className="pb-2 border-b border-slate-100">
                      <h4 className="text-[13px] font-bold text-slate-900">Pesan WhatsApp</h4>
                    </div>

                    <div className="space-y-2.5">
                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Nomor WhatsApp
                        </label>
                        <input
                          type="text"
                          value={c.catalogWhatsappNumber ?? '6281234567890'}
                          placeholder="6281234567890"
                          onChange={(e) =>
                            updateContent({ catalogWhatsappNumber: e.target.value })
                          }
                          className="w-full px-2.5 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 bg-slate-50/50 focus:bg-white outline-none focus:border-emerald-500 tabular-nums"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Nama Toko
                        </label>
                        <input
                          type="text"
                          value={c.catalogStoreName ?? ''}
                          placeholder="Otomatis pakai nama halaman"
                          onChange={(e) => updateContent({ catalogStoreName: e.target.value })}
                          className="w-full px-2.5 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 bg-slate-50/50 focus:bg-white outline-none focus:border-emerald-500"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Pesan Pembuka
                        </label>
                        <input
                          type="text"
                          value={
                            c.catalogWhatsappIntro ??
                            'Halo, saya ingin memesan produk berikut:'
                          }
                          placeholder="Halo, saya ingin memesan produk berikut:"
                          onChange={(e) =>
                            updateContent({ catalogWhatsappIntro: e.target.value })
                          }
                          className="w-full px-2.5 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 bg-slate-50/50 focus:bg-white outline-none focus:border-emerald-500"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Kotak 3: Checkout & Pengiriman */}
                {cartEnabled && (
                  <div className="p-3 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-2.5">
                    <div className="pb-2 border-b border-slate-100">
                      <h4 className="text-[13px] font-bold text-slate-900">Checkout</h4>
                    </div>

                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-medium text-slate-700">
                          Form Data Pemesan
                        </span>
                        <ToggleSwitch
                          checked={c.catalogAskCustomerInfo ?? true}
                          onChange={(checked) =>
                            updateContent({ catalogAskCustomerInfo: checked })
                          }
                          label="Form Data Pemesan"
                        />
                      </div>

                      {hasPhysicalItem && (
                        <>
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-medium text-slate-700">
                              Opsi Pengiriman
                            </span>
                            <ToggleSwitch
                              checked={c.catalogShippingEnabled ?? true}
                              onChange={(checked) =>
                                updateContent({ catalogShippingEnabled: checked })
                              }
                              label="Opsi Pengiriman"
                            />
                          </div>

                          {(c.catalogShippingEnabled ?? true) && (() => {
                            const shippingOpts = resolveCatalogShippingOptions(c);
                            const activeShipOpt =
                              shippingOpts.find((o) => o.id === activeShippingOptionId) ??
                              shippingOpts[0];
                            const updateShipOpt = (
                              optId: ShippingMethodId,
                              patch: Partial<CatalogShippingOptionConfig>
                            ) => {
                              const nextOpts = shippingOpts.map((o) =>
                                o.id === optId ? { ...o, ...patch } : o
                              );
                              updateContent({ catalogShippingOptions: nextOpts });
                            };

                            return (
                              <div className="pt-2.5 border-t border-slate-100 space-y-2.5">
                                <div className="flex items-center justify-between gap-2">
                                  <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                                    Setting Pilihan &amp; Catatan
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      updateContent({
                                        catalogShippingOptions:
                                          cloneDefaultCatalogShippingOptions(),
                                      })
                                    }
                                    className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 hover:underline cursor-pointer"
                                  >
                                    <RotateCcw className="w-3 h-3" />
                                    <span>Reset Default</span>
                                  </button>
                                </div>

                                {/* Pilih 1 dari 4 Opsi */}
                                <div className="grid grid-cols-2 gap-1.5">
                                  {shippingOpts.map((opt, oIdx) => {
                                    const isSel = activeShipOpt.id === opt.id;
                                    return (
                                      <button
                                        key={opt.id}
                                        type="button"
                                        onClick={() => setActiveShippingOptionId(opt.id)}
                                        className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg border text-left text-[11px] font-semibold transition-colors cursor-pointer min-w-0 ${
                                          isSel
                                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                                        } ${opt.enabled === false ? 'opacity-55' : ''}`}
                                      >
                                        <span
                                          className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                                            opt.enabled !== false
                                              ? isSel
                                                ? 'bg-emerald-200'
                                                : 'bg-emerald-500'
                                              : 'bg-slate-400'
                                          }`}
                                        />
                                        <span className="truncate">
                                          {oIdx + 1}. {opt.label}
                                        </span>
                                      </button>
                                    );
                                  })}
                                </div>

                                {/* Detail Pengaturan Opsi Terpilih */}
                                {activeShipOpt && (
                                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/90 space-y-2.5">
                                    <div className="flex items-center justify-between gap-2 pb-1.5 border-b border-slate-200/70">
                                      <span className="text-xs font-bold text-slate-800 truncate">
                                        {activeShipOpt.label}
                                      </span>
                                      <ToggleSwitch
                                        checked={activeShipOpt.enabled !== false}
                                        onChange={(checked) =>
                                          updateShipOpt(activeShipOpt.id, { enabled: checked })
                                        }
                                        label={`Aktifkan pilihan ${activeShipOpt.label}`}
                                      />
                                    </div>

                                    <div>
                                      <label className="block text-[11px] font-medium text-slate-600 mb-1">
                                        Nama Pilihan
                                      </label>
                                      <input
                                        type="text"
                                        value={activeShipOpt.label}
                                        onChange={(e) =>
                                          updateShipOpt(activeShipOpt.id, {
                                            label: e.target.value,
                                          })
                                        }
                                        className="w-full px-2.5 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 bg-white focus:border-emerald-500 outline-none"
                                      />
                                    </div>

                                    {/* Isian Waktu / Jam */}
                                    <div className="p-2 rounded-lg bg-white border border-slate-200/80 space-y-2">
                                      <div className="flex items-center justify-between gap-2">
                                        <span className="text-[11px] font-semibold text-slate-700">
                                          Tambahkan Waktu / Jam
                                        </span>
                                        <ToggleSwitch
                                          checked={Boolean(activeShipOpt.askArrivalTime)}
                                          onChange={(checked) =>
                                            updateShipOpt(activeShipOpt.id, {
                                              askArrivalTime: checked,
                                            })
                                          }
                                          label="Tambahkan input waktu"
                                        />
                                      </div>
                                      {activeShipOpt.askArrivalTime && (
                                        <div className="grid grid-cols-2 gap-1.5">
                                          <input
                                            type="text"
                                            value={activeShipOpt.arrivalTimeLabel ?? ''}
                                            placeholder="Label (mis. Diambil jam)"
                                            onChange={(e) =>
                                              updateShipOpt(activeShipOpt.id, {
                                                arrivalTimeLabel: e.target.value,
                                              })
                                            }
                                            className="w-full px-2 py-1 text-[11px] text-slate-800 rounded border border-slate-200 bg-slate-50 focus:bg-white outline-none focus:border-emerald-500"
                                          />
                                          <input
                                            type="text"
                                            value={activeShipOpt.arrivalTimePlaceholder ?? ''}
                                            placeholder="Contoh: 18:30 WIB"
                                            onChange={(e) =>
                                              updateShipOpt(activeShipOpt.id, {
                                                arrivalTimePlaceholder: e.target.value,
                                              })
                                            }
                                            className="w-full px-2 py-1 text-[11px] text-slate-800 rounded border border-slate-200 bg-slate-50 focus:bg-white outline-none focus:border-emerald-500"
                                          />
                                        </div>
                                      )}
                                    </div>

                                    {/* Isian Jumlah Orang */}
                                    <div className="p-2 rounded-lg bg-white border border-slate-200/80 space-y-2">
                                      <div className="flex items-center justify-between gap-2">
                                        <span className="text-[11px] font-semibold text-slate-700">
                                          Tambahkan Jumlah Orang
                                        </span>
                                        <ToggleSwitch
                                          checked={Boolean(activeShipOpt.askGuestCount)}
                                          onChange={(checked) =>
                                            updateShipOpt(activeShipOpt.id, {
                                              askGuestCount: checked,
                                            })
                                          }
                                          label="Tambahkan jumlah orang"
                                        />
                                      </div>
                                      {activeShipOpt.askGuestCount && (
                                        <div className="grid grid-cols-2 gap-1.5">
                                          <input
                                            type="text"
                                            value={activeShipOpt.guestCountLabel ?? ''}
                                            placeholder="Label (mis. Jumlah Orang)"
                                            onChange={(e) =>
                                              updateShipOpt(activeShipOpt.id, {
                                                guestCountLabel: e.target.value,
                                              })
                                            }
                                            className="w-full px-2 py-1 text-[11px] text-slate-800 rounded border border-slate-200 bg-slate-50 focus:bg-white outline-none focus:border-emerald-500"
                                          />
                                          <input
                                            type="text"
                                            value={activeShipOpt.guestCountPlaceholder ?? ''}
                                            placeholder="Contoh: 4 orang"
                                            onChange={(e) =>
                                              updateShipOpt(activeShipOpt.id, {
                                                guestCountPlaceholder: e.target.value,
                                              })
                                            }
                                            className="w-full px-2 py-1 text-[11px] text-slate-800 rounded border border-slate-200 bg-slate-50 focus:bg-white outline-none focus:border-emerald-500"
                                          />
                                        </div>
                                      )}
                                    </div>

                                    {/* Checklist Konfirmasi */}
                                    <div className="p-2 rounded-lg bg-white border border-slate-200/80 space-y-2">
                                      <div className="flex items-center justify-between gap-2">
                                        <span className="text-[11px] font-semibold text-slate-700">
                                          Tampilkan Checklist
                                        </span>
                                        <ToggleSwitch
                                          checked={Boolean(activeShipOpt.checklistEnabled)}
                                          onChange={(checked) =>
                                            updateShipOpt(activeShipOpt.id, {
                                              checklistEnabled: checked,
                                            })
                                          }
                                          label="Tampilkan checklist konfirmasi"
                                        />
                                      </div>
                                      {activeShipOpt.checklistEnabled && (
                                        <textarea
                                          rows={2}
                                          value={activeShipOpt.checklistText ?? ''}
                                          placeholder="Contoh: Pesan kurir setelah pembayaran dan makanan telah siap"
                                          onChange={(e) =>
                                            updateShipOpt(activeShipOpt.id, {
                                              checklistText: e.target.value,
                                            })
                                          }
                                          className="w-full px-2 py-1.5 text-[11px] text-slate-800 rounded border border-slate-200 bg-slate-50 focus:bg-white outline-none focus:border-emerald-500 resize-y"
                                        />
                                      )}
                                    </div>

                                    {/* Catatan Pilihan */}
                                    <div className="p-2 rounded-lg bg-white border border-slate-200/80 space-y-2">
                                      <div className="text-[11px] font-semibold text-slate-700">
                                        Catatan Khusus Pilihan Ini
                                      </div>
                                      <input
                                        type="text"
                                        value={activeShipOpt.noteTitle ?? 'Catatan:'}
                                        placeholder="Judul catatan (mis. Catatan: / Catatan Penting:)"
                                        onChange={(e) =>
                                          updateShipOpt(activeShipOpt.id, {
                                            noteTitle: e.target.value,
                                          })
                                        }
                                        className="w-full px-2 py-1 text-[11px] font-semibold text-slate-800 rounded border border-slate-200 bg-slate-50 focus:bg-white outline-none focus:border-emerald-500"
                                      />
                                      <textarea
                                        rows={2}
                                        value={activeShipOpt.noteText ?? ''}
                                        placeholder="Kosongkan jika tidak perlu catatan"
                                        onChange={(e) =>
                                          updateShipOpt(activeShipOpt.id, {
                                            noteText: e.target.value,
                                          })
                                        }
                                        className="w-full px-2 py-1.5 text-[11px] text-slate-800 rounded border border-slate-200 bg-slate-50 focus:bg-white outline-none focus:border-emerald-500 resize-y"
                                      />
                                    </div>
                                  </div>
                                )}
                              </div>
                            );
                          })()}
                        </>
                      )}
                    </div>
                  </div>
                )}

                {/* Kotak 4: Daftar Produk */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between px-0.5 pt-1">
                    <div>
                      <h4 className="text-[13px] font-bold text-slate-900">
                        Daftar Produk ({items.length})
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        Klik produk untuk edit, geser untuk urutkan.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={handleAddCatalogItem}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer transition-colors shrink-0"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tambah</span>
                    </button>
                  </div>

                  <div className="space-y-2.5">
                    {items.map((item, idx) => {
                      const isExpanded = expandedCatalogItems[item.id] ?? idx === 0;
                      const isPhysicalItem =
                        item.productType === 'physical' ||
                        ((!item.productType || item.productType === 'inherit') &&
                          productType === 'physical');

                      return (
                        <div
                          key={item.id}
                          draggable
                          onDragStart={(e) => {
                            const activeTag = document.activeElement?.tagName;
                            if (activeTag === 'INPUT' || activeTag === 'TEXTAREA' || activeTag === 'SELECT') {
                              e.preventDefault();
                              return;
                            }
                            e.dataTransfer.setData('application/lynk-catalog-item', item.id);
                            e.dataTransfer.effectAllowed = 'move';
                            setDragItemState({ draggedId: item.id, targetId: null });
                          }}
                          onDragOver={(e) => {
                            e.preventDefault();
                            if (dragItemState.targetId !== item.id) {
                              setDragItemState((prev) => ({ ...prev, targetId: item.id }));
                            }
                          }}
                          onDrop={(e) => {
                            e.preventDefault();
                            const draggedId = e.dataTransfer.getData('application/lynk-catalog-item');
                            if (draggedId && draggedId !== item.id) {
                              handleReorderCatalogItem(draggedId, item.id);
                            }
                            setDragItemState({ draggedId: null, targetId: null });
                          }}
                          onDragEnd={() => setDragItemState({ draggedId: null, targetId: null })}
                          className={`rounded-xl border bg-white shadow-2xs overflow-hidden transition-colors ${
                            dragItemState.draggedId === item.id ? 'opacity-45' : ''
                          } ${
                            dragItemState.targetId === item.id && dragItemState.draggedId !== item.id
                              ? 'border-emerald-500 ring-1 ring-emerald-500/30'
                              : 'border-slate-200'
                          }`}
                        >
                          {/* Header Produk */}
                          <div className="px-3 py-2.5 bg-slate-50/70 flex items-center gap-2">
                            <span
                              title="Geser urutan"
                              className="text-slate-400 hover:text-slate-600 cursor-grab active:cursor-grabbing shrink-0"
                            >
                              <GripVertical className="w-3.5 h-3.5" />
                            </span>
                            <div className="w-8 h-8 rounded-lg border border-slate-200 bg-white overflow-hidden shrink-0">
                              <img
                                src={item.image || PRODUCT_CARD_SVG}
                                alt={item.title}
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <button
                              type="button"
                              onClick={() =>
                                setExpandedCatalogItems((prev) => ({
                                  ...prev,
                                  [item.id]: !isExpanded,
                                }))
                              }
                              className="flex-1 min-w-0 text-left cursor-pointer"
                            >
                              <div className="text-[13px] font-bold text-slate-900 truncate">
                                {item.title || `Produk #${idx + 1}`}
                              </div>
                              <div className="text-[11px] text-slate-500 truncate tabular-nums">
                                {item.price || 'Tanpa harga'} · {item.unitSold} terjual
                              </div>
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setExpandedCatalogItems((prev) => ({
                                  ...prev,
                                  [item.id]: !isExpanded,
                                }))
                              }
                              title={isExpanded ? 'Tutup' : 'Buka'}
                              className="p-1 rounded-md text-slate-500 hover:bg-slate-200/60 cursor-pointer shrink-0"
                            >
                              <ChevronDown
                                className={`w-4 h-4 transition-transform duration-150 ${
                                  isExpanded ? 'rotate-180' : ''
                                }`}
                              />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteCatalogItem(item.id)}
                              title="Hapus produk"
                              className="p-1 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer shrink-0"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {/* Isi Produk Dipisah Per Kotak */}
                          {isExpanded && (
                            <div className="p-2.5 space-y-2.5 bg-slate-50/40 border-t border-slate-100">
                              {/* Sub-Kotak 1: Info Utama */}
                              <div className="p-2.5 rounded-lg border border-slate-200/80 bg-white space-y-2">
                                <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                                  Info Produk
                                </div>
                                <div>
                                  <label className="block text-xs font-medium text-slate-700 mb-1">
                                    Nama Produk
                                  </label>
                                  <input
                                    type="text"
                                    value={item.title}
                                    placeholder="Nama produk"
                                    onChange={(e) =>
                                      handleUpdateCatalogItem(item.id, { title: e.target.value })
                                    }
                                    className="w-full px-2.5 py-1.5 text-xs font-medium text-slate-800 rounded-lg border border-slate-200 outline-none focus:border-emerald-500"
                                  />
                                </div>
                                <div>
                                  <label className="block text-xs font-medium text-slate-700 mb-1">
                                    Ringkasan
                                  </label>
                                  <input
                                    type="text"
                                    value={item.subtitle}
                                    placeholder="Keterangan singkat produk"
                                    onChange={(e) =>
                                      handleUpdateCatalogItem(item.id, { subtitle: e.target.value })
                                    }
                                    className="w-full px-2.5 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 outline-none focus:border-emerald-500"
                                  />
                                </div>
                                <div className="grid grid-cols-2 gap-2">
                                  <div>
                                    <label className="block text-xs font-medium text-slate-700 mb-1">
                                      Harga
                                    </label>
                                    <input
                                      type="text"
                                      value={item.price}
                                      placeholder="Rp 99.000"
                                      onChange={(e) =>
                                        handleUpdateCatalogItem(item.id, { price: e.target.value })
                                      }
                                      className="w-full px-2.5 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 outline-none focus:border-emerald-500"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-xs font-medium text-slate-700 mb-1">
                                      Terjual
                                    </label>
                                    <input
                                      type="number"
                                      min={0}
                                      value={item.unitSold}
                                      placeholder="0"
                                      onChange={(e) =>
                                        handleUpdateCatalogItem(item.id, {
                                          unitSold: Math.max(0, Number(e.target.value)),
                                        })
                                      }
                                      className="w-full px-2.5 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 outline-none focus:border-emerald-500 tabular-nums"
                                    />
                                  </div>
                                </div>
                              </div>

                              {/* Sub-Kotak 2: Foto & Galeri */}
                              <div className="p-2.5 rounded-lg border border-slate-200/80 bg-white space-y-2">
                                <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                                  Foto Produk
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <input
                                    type="url"
                                    value={item.image.startsWith('data:') ? '' : item.image}
                                    placeholder={
                                      item.image.startsWith('data:') &&
                                      !item.image.startsWith('data:image/svg+xml')
                                        ? 'Gambar terunggah'
                                        : 'URL gambar...'
                                    }
                                    onChange={(e) =>
                                      handleUpdateCatalogItem(item.id, {
                                        image: e.target.value || PRODUCT_CARD_SVG,
                                      })
                                    }
                                    className="flex-1 min-w-0 px-2.5 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 outline-none focus:border-emerald-500"
                                  />
                                  <label
                                    title="Upload gambar"
                                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-medium text-slate-700 cursor-pointer shrink-0 transition-colors"
                                  >
                                    <Upload className="w-3.5 h-3.5 text-emerald-600" />
                                    <span>Upload</span>
                                    <input
                                      type="file"
                                      accept="image/*"
                                      onChange={(e) => handleCatalogItemImageUpload(item.id, e)}
                                      className="hidden"
                                    />
                                  </label>
                                </div>

                                <div className="grid grid-cols-2 gap-2">
                                  <div>
                                    <label className="block text-xs font-medium text-slate-700 mb-1">
                                      Rasio
                                    </label>
                                    <select
                                      value={item.imageAspectRatio ?? 'auto'}
                                      onChange={(e) =>
                                        handleUpdateCatalogItem(item.id, {
                                          imageAspectRatio: e.target.value as
                                            | 'auto'
                                            | '16/9'
                                            | '4/3'
                                            | '1/1',
                                        })
                                      }
                                      className="w-full px-2 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 bg-white outline-none focus:border-emerald-500"
                                    >
                                      <option value="auto">Otomatis</option>
                                      <option value="16/9">16:9</option>
                                      <option value="4/3">4:3</option>
                                      <option value="1/1">1:1 Kotak</option>
                                    </select>
                                  </div>
                                  <div>
                                    <label className="block text-xs font-medium text-slate-700 mb-1">
                                      Tampilan
                                    </label>
                                    <select
                                      value={item.imageObjectFit ?? 'cover'}
                                      onChange={(e) =>
                                        handleUpdateCatalogItem(item.id, {
                                          imageObjectFit: e.target.value as 'cover' | 'contain',
                                        })
                                      }
                                      className="w-full px-2 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 bg-white outline-none focus:border-emerald-500"
                                    >
                                      <option value="cover">Penuh</option>
                                      <option value="contain">Utuh</option>
                                    </select>
                                  </div>
                                </div>

                                <div className="pt-1 border-t border-slate-100 space-y-1.5">
                                  <div className="flex items-center justify-between">
                                    <span className="text-xs font-medium text-slate-700">
                                      Galeri ({(item.gallery ?? []).length})
                                    </span>
                                    <label className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800 cursor-pointer">
                                      <Plus className="w-3 h-3" />
                                      <span>Tambah</span>
                                      <input
                                        type="file"
                                        accept="image/*"
                                        onChange={(e) =>
                                          handleCatalogItemGalleryUpload(item.id, e)
                                        }
                                        className="hidden"
                                      />
                                    </label>
                                  </div>
                                  {(item.gallery ?? []).length > 0 && (
                                    <div className="flex flex-wrap gap-1.5">
                                      {(item.gallery ?? []).map((gSrc, gIdx) => (
                                        <div
                                          key={`${item.id}_gal_${gIdx}`}
                                          className="relative w-10 h-10 rounded-lg border border-slate-200 bg-white overflow-hidden"
                                        >
                                          <img
                                            src={gSrc}
                                            alt={`Galeri ${gIdx + 1}`}
                                            className="w-full h-full object-cover"
                                          />
                                          <button
                                            type="button"
                                            onClick={() =>
                                              handleRemoveCatalogGalleryImage(item.id, gIdx)
                                            }
                                            title="Hapus foto"
                                            className="absolute top-0.5 right-0.5 w-3.5 h-3.5 rounded-full bg-slate-900/75 text-white flex items-center justify-center hover:bg-red-600 cursor-pointer"
                                          >
                                            <X className="w-2.5 h-2.5" />
                                          </button>
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </div>
                              </div>

                              {/* Sub-Kotak 3: Tombol & Detail */}
                              <div className="p-2.5 rounded-lg border border-slate-200/80 bg-white space-y-2">
                                <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                                  Detail &amp; Tombol
                                </div>
                                <div className="grid grid-cols-2 gap-2">
                                  <div>
                                    <label className="block text-xs font-medium text-slate-700 mb-1">
                                      Teks Tombol
                                    </label>
                                    <input
                                      type="text"
                                      value={item.ctaLabel}
                                      placeholder="Lihat Detail"
                                      onChange={(e) =>
                                        handleUpdateCatalogItem(item.id, {
                                          ctaLabel: e.target.value,
                                        })
                                      }
                                      className="w-full px-2.5 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 outline-none focus:border-emerald-500"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-xs font-medium text-slate-700 mb-1">
                                      Link Tujuan
                                    </label>
                                    <input
                                      type="url"
                                      value={item.url}
                                      placeholder="https://..."
                                      onChange={(e) =>
                                        handleUpdateCatalogItem(item.id, { url: e.target.value })
                                      }
                                      className="w-full px-2.5 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 outline-none focus:border-emerald-500"
                                    />
                                  </div>
                                </div>

                                <div className="grid grid-cols-2 gap-2">
                                  <div>
                                    <label className="block text-xs font-medium text-slate-700 mb-1">
                                      Badge
                                    </label>
                                    <input
                                      type="text"
                                      value={item.badge ?? ''}
                                      placeholder="Promo / Laris"
                                      onChange={(e) =>
                                        handleUpdateCatalogItem(item.id, { badge: e.target.value })
                                      }
                                      className="w-full px-2.5 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 outline-none focus:border-emerald-500"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-xs font-medium text-slate-700 mb-1">
                                      Varian
                                    </label>
                                    <input
                                      type="text"
                                      value={item.variants ?? ''}
                                      placeholder="Reguler, VIP"
                                      onChange={(e) =>
                                        handleUpdateCatalogItem(item.id, {
                                          variants: e.target.value,
                                        })
                                      }
                                      className="w-full px-2.5 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 outline-none focus:border-emerald-500"
                                    />
                                  </div>
                                </div>

                                <div>
                                  <label className="block text-xs font-medium text-slate-700 mb-1">
                                    Deskripsi Detail
                                  </label>
                                  <textarea
                                    rows={2}
                                    value={item.description ?? ''}
                                    placeholder="Spesifikasi atau isi paket..."
                                    onChange={(e) =>
                                      handleUpdateCatalogItem(item.id, {
                                        description: e.target.value,
                                      })
                                    }
                                    className="w-full px-2.5 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 outline-none focus:border-emerald-500 resize-y"
                                  />
                                </div>
                              </div>

                              {/* Sub-Kotak 4: Tipe Item (jika Keranjang aktif) */}
                              {cartEnabled && (
                                <div className="p-2.5 rounded-lg border border-slate-200/80 bg-white space-y-2">
                                  <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                                    Tipe Item
                                  </div>
                                  <div>
                                    <label className="block text-xs font-medium text-slate-700 mb-1">
                                      Jenis Produk
                                    </label>
                                    <select
                                      value={item.productType ?? 'inherit'}
                                      onChange={(e) =>
                                        handleUpdateCatalogItem(item.id, {
                                          productType: e.target.value as
                                            | 'inherit'
                                            | CatalogProductType,
                                        })
                                      }
                                      className="w-full px-2.5 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 bg-white outline-none focus:border-emerald-500"
                                    >
                                      <option value="inherit">
                                        Ikuti Katalog (
                                        {productType === 'service' ? 'Jasa' : 'Fisik'})
                                      </option>
                                      <option value="physical">Produk Fisik</option>
                                      <option value="service">Produk Jasa</option>
                                    </select>
                                  </div>

                                  {isPhysicalItem && (
                                    <div>
                                      <label className="block text-xs font-medium text-slate-700 mb-1">
                                        Catatan Ambil di Lokasi
                                      </label>
                                      <input
                                        type="text"
                                        value={item.pickupNote ?? ''}
                                        placeholder="Opsional, misal: Masak ± 30 menit"
                                        onChange={(e) =>
                                          handleUpdateCatalogItem(item.id, {
                                            pickupNote: e.target.value,
                                          })
                                        }
                                        className="w-full px-2.5 py-1.5 text-xs text-slate-800 rounded-lg border border-slate-200 outline-none focus:border-emerald-500"
                                      />
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })()}

          {selectedBlock.type === 'carousel' && (() => {
            const carouselItems = c.carouselItems ?? [];
            const currentRatio: CarouselAspectRatio = c.carouselAspectRatio ?? '4/5';
            const currentFit = c.carouselObjectFit ?? 'cover';

            return (
              <div className="space-y-3.5">
                {/* Ukuran / Rasio Foto */}
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1.5">
                    Ukuran / Rasio Foto
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {(
                      [
                        { id: '1/1', label: '1:1' },
                        { id: '4/5', label: '4:5' },
                        { id: '9/16', label: '9:16' },
                        { id: '16/9', label: '16:9' },
                      ] as const
                    ).map((opt) => {
                      const active = currentRatio === opt.id;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => updateContent({ carouselAspectRatio: opt.id })}
                          className={`py-1.5 px-2 rounded-lg text-xs font-semibold border transition-colors cursor-pointer tabular-nums ${
                            active
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                          }`}
                        >
                          {opt.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Penyesuaian Gambar */}
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Penyesuaian Foto
                  </label>
                  <select
                    value={currentFit}
                    onChange={(e) =>
                      updateContent({
                        carouselObjectFit: e.target.value as 'cover' | 'contain',
                      })
                    }
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white outline-none focus:border-blue-500"
                  >
                    <option value="cover">Penuhi Bingkai (Cover)</option>
                    <option value="contain">Tampil Utuh (Contain)</option>
                  </select>
                </div>

                {/* Pengaturan Jumlah Foto */}
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-slate-700">Jumlah Foto</span>
                    <div className="inline-flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleSetCarouselCount(carouselItems.length - 1)}
                        disabled={carouselItems.length <= 1}
                        aria-label="Kurangi jumlah foto"
                        className="w-6 h-6 rounded border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 text-xs font-bold text-slate-700 cursor-pointer"
                      >
                        -
                      </button>
                      <input
                        type="number"
                        min={1}
                        max={20}
                        value={carouselItems.length}
                        onChange={(e) => handleSetCarouselCount(Number(e.target.value))}
                        className="w-12 h-6 px-1 text-center text-xs font-semibold rounded border border-slate-200 bg-white tabular-nums outline-none focus:border-blue-500"
                      />
                      <button
                        type="button"
                        onClick={() => handleSetCarouselCount(carouselItems.length + 1)}
                        disabled={carouselItems.length >= 20}
                        aria-label="Tambah jumlah foto"
                        className="w-6 h-6 rounded border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 text-xs font-bold text-slate-700 cursor-pointer"
                      >
                        +
                      </button>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddCarouselItem}
                    disabled={carouselItems.length >= 20}
                    className="w-full inline-flex items-center justify-center gap-1 py-1.5 px-2.5 rounded-md bg-blue-50 text-blue-700 hover:bg-blue-100 disabled:opacity-45 text-[11px] font-semibold cursor-pointer transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Tambah Foto ({carouselItems.length}/20)</span>
                  </button>
                </div>

                {/* Daftar Slide Foto */}
                <div className="space-y-2.5">
                  {carouselItems.map((item, idx) => (
                    <div
                      key={item.id}
                      draggable
                      onDragStart={(e) => {
                        const activeTag = document.activeElement?.tagName;
                        if (activeTag === 'INPUT' || activeTag === 'TEXTAREA') {
                          e.preventDefault();
                          return;
                        }
                        e.dataTransfer.setData('application/lynk-carousel-item', item.id);
                        e.dataTransfer.effectAllowed = 'move';
                        setDragItemState({ draggedId: item.id, targetId: null });
                      }}
                      onDragOver={(e) => {
                        e.preventDefault();
                        if (dragItemState.targetId !== item.id) {
                          setDragItemState((prev) => ({ ...prev, targetId: item.id }));
                        }
                      }}
                      onDrop={(e) => {
                        e.preventDefault();
                        const draggedId = e.dataTransfer.getData('application/lynk-carousel-item');
                        if (draggedId && draggedId !== item.id) {
                          handleReorderCarouselItem(draggedId, item.id);
                        }
                        setDragItemState({ draggedId: null, targetId: null });
                      }}
                      onDragEnd={() => setDragItemState({ draggedId: null, targetId: null })}
                      className={`p-2.5 rounded-lg border bg-slate-50/70 space-y-2 transition-colors ${
                        dragItemState.draggedId === item.id ? 'opacity-45' : ''
                      } ${
                        dragItemState.targetId === item.id && dragItemState.draggedId !== item.id
                          ? 'border-blue-500 ring-1 ring-blue-500/30'
                          : 'border-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1.5">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span
                            title="Tarik untuk ubah urutan foto"
                            className="text-slate-400 hover:text-slate-600 cursor-grab active:cursor-grabbing shrink-0"
                          >
                            <GripVertical className="w-3.5 h-3.5" />
                          </span>
                          <span className="text-[11px] font-bold text-slate-700">
                            Foto #{idx + 1}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleDeleteCarouselItem(item.id)}
                          disabled={carouselItems.length <= 1}
                          title={
                            carouselItems.length <= 1
                              ? 'Minimal 1 foto harus ada'
                              : 'Hapus foto'
                          }
                          className="p-1 rounded text-slate-400 hover:text-red-600 hover:bg-red-50 disabled:opacity-35 cursor-pointer shrink-0"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Upload & Link Gambar */}
                      <div className="flex items-center gap-2">
                        <div className="w-10 h-10 rounded-md border border-slate-200 bg-white overflow-hidden shrink-0 flex items-center justify-center">
                          <img
                            src={item.image || CAROUSEL_SAMPLE_1_SVG}
                            alt={item.title || `Foto ${idx + 1}`}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0 flex items-center gap-1">
                          <input
                            type="url"
                            value={item.image.startsWith('data:') ? '' : item.image}
                            placeholder={
                              item.image.startsWith('data:') &&
                              !item.image.startsWith('data:image/svg+xml')
                                ? 'Foto lokal terunggah'
                                : 'https://... (link gambar)'
                            }
                            onChange={(e) =>
                              handleUpdateCarouselItem(item.id, {
                                image:
                                  e.target.value ||
                                  SAMPLE_CAROUSEL_IMAGES[idx % SAMPLE_CAROUSEL_IMAGES.length],
                              })
                            }
                            className="flex-1 min-w-0 px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                          />
                          <label
                            title="Upload foto dari perangkat"
                            className="inline-flex items-center gap-1 px-2 py-1 rounded border border-slate-200 bg-white hover:bg-slate-100 text-[11px] font-medium text-slate-700 cursor-pointer shrink-0 transition-colors"
                          >
                            <Upload className="w-3 h-3 text-blue-600" />
                            <span>Upload</span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={(e) => handleCarouselItemImageUpload(item.id, e)}
                              className="hidden"
                            />
                          </label>
                        </div>
                      </div>

                      {/* Foto : Judul */}
                      <div>
                        <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                          Judul Foto
                        </label>
                        <input
                          type="text"
                          value={item.title}
                          placeholder="Judul foto..."
                          onChange={(e) =>
                            handleUpdateCarouselItem(item.id, { title: e.target.value })
                          }
                          className="w-full px-2 py-1 text-xs font-semibold rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                        />
                      </div>

                      {/* Keterangan : Di bawah foto */}
                      <div>
                        <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                          Keterangan (Di bawah foto)
                        </label>
                        <textarea
                          rows={2}
                          value={item.caption}
                          placeholder="Tulis keterangan foto..."
                          onChange={(e) =>
                            handleUpdateCarouselItem(item.id, { caption: e.target.value })
                          }
                          className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500 resize-y"
                        />
                      </div>

                      {/* Link Tujuan (Opsional) */}
                      <div>
                        <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                          Link Tujuan Foto (Opsional)
                        </label>
                        <input
                          type="url"
                          value={item.url ?? ''}
                          placeholder="https://... (dibuka saat foto diklik)"
                          onChange={(e) =>
                            handleUpdateCarouselItem(item.id, { url: e.target.value })
                          }
                          className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}

          {selectedBlock.type === 'social_feed' && (() => {
            const platform = c.socialFeedPlatform ?? 'instagram';
            const meta = SOCIAL_PLATFORMS[platform] ?? SOCIAL_PLATFORMS.instagram;
            const posts = c.socialFeedPosts ?? [];
            const currentRatio: CarouselAspectRatio = c.socialFeedRatio ?? '4/5';

            return (
              <div className="space-y-4">
                {/* 1. Logo Sosmed & Profil Akun */}
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2.5">
                  <div className="text-[11px] font-bold text-slate-700">
                    1. Logo Sosmed &amp; Profil Akun
                  </div>

                  <div>
                    <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                      Platform Sosial Media
                    </label>
                    <select
                      value={platform}
                      onChange={(e) => {
                        const nextPlat = e.target.value as SocialPlatform;
                        const nextMeta = SOCIAL_PLATFORMS[nextPlat];
                        const currentDefaultLabel =
                          platform === 'youtube' ? 'Subscriber' : 'Follower';
                        const nextDefaultLabel =
                          nextPlat === 'youtube' ? 'Subscriber' : 'Follower';
                        updateContent({
                          socialFeedPlatform: nextPlat,
                          socialFeedAccountUrl:
                            !c.socialFeedAccountUrl || c.socialFeedAccountUrl === meta.placeholderUrl
                              ? nextMeta.placeholderUrl
                              : c.socialFeedAccountUrl,
                          socialFeedFollowersLabel:
                            !c.socialFeedFollowersLabel ||
                            c.socialFeedFollowersLabel === currentDefaultLabel
                              ? nextDefaultLabel
                              : c.socialFeedFollowersLabel,
                        });
                      }}
                      className="w-full px-2 py-1.5 text-xs font-semibold rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                    >
                      {SOCIAL_PLATFORM_LIST.map((plat) => (
                        <option key={plat.id} value={plat.id}>
                          {plat.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Foto Profil (Opsional) */}
                  <div className="flex items-center gap-2">
                    <div
                      style={{ backgroundColor: meta.brandColor }}
                      className="w-9 h-9 rounded-full text-white overflow-hidden shrink-0 flex items-center justify-center border border-slate-200"
                    >
                      {c.socialFeedAvatar ? (
                        <img
                          src={c.socialFeedAvatar}
                          alt={c.socialFeedAccountName || meta.label}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <SocialGlyph platform={platform} className="w-4 h-4" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0 flex items-center gap-1">
                      <input
                        type="url"
                        value={c.socialFeedAvatar?.startsWith('data:') ? '' : c.socialFeedAvatar ?? ''}
                        placeholder={
                          c.socialFeedAvatar?.startsWith('data:')
                            ? 'Foto profil terunggah'
                            : 'URL Foto Profil (opsional)'
                        }
                        onChange={(e) => updateContent({ socialFeedAvatar: e.target.value })}
                        className="flex-1 min-w-0 px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                      />
                      <label className="inline-flex items-center gap-1 px-2 py-1 rounded border border-slate-200 bg-white hover:bg-slate-100 text-[11px] font-medium text-slate-700 cursor-pointer shrink-0">
                        <Upload className="w-3 h-3 text-blue-600" />
                        <span>Upload</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleSocialFeedAvatarUpload}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-1.5">
                    <div>
                      <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                        Nama Akun
                      </label>
                      <input
                        type="text"
                        value={c.socialFeedAccountName ?? ''}
                        placeholder="Studio Kreatif"
                        onChange={(e) => updateContent({ socialFeedAccountName: e.target.value })}
                        className="w-full px-2 py-1 text-xs font-semibold rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                        Username / Handle
                      </label>
                      <input
                        type="text"
                        value={c.socialFeedHandle ?? ''}
                        placeholder="@studiokreatif"
                        onChange={(e) => updateContent({ socialFeedHandle: e.target.value })}
                        className="w-full px-2 py-1 text-xs rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-1.5">
                    <div>
                      <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                        Teks Tombol
                      </label>
                      <input
                        type="text"
                        value={c.socialFeedFollowLabel ?? 'Ikuti'}
                        placeholder="Ikuti"
                        onChange={(e) => updateContent({ socialFeedFollowLabel: e.target.value })}
                        className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                        Link Profil Akun
                      </label>
                      <input
                        type="url"
                        value={c.socialFeedAccountUrl ?? ''}
                        placeholder={meta.placeholderUrl}
                        onChange={(e) => updateContent({ socialFeedAccountUrl: e.target.value })}
                        className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-0.5">
                    <span className="text-[11px] font-medium text-slate-700">
                      Centang Verifikasi Akun
                    </span>
                    <ToggleSwitch
                      checked={c.socialFeedVerified ?? true}
                      onChange={(checked) => updateContent({ socialFeedVerified: checked })}
                      label="Centang Verifikasi Akun"
                    />
                  </div>
                </div>

                {/* 2. Follower / Subscribe */}
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
                  <div className="text-[11px] font-bold text-slate-700">
                    2. Follower / Subscribe (Di Sebelah Kiri Tombol Ikuti)
                  </div>
                  <div className="grid grid-cols-2 gap-1.5">
                    <div>
                      <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                        Jumlah
                      </label>
                      <input
                        type="text"
                        value={c.socialFeedFollowers ?? ''}
                        placeholder="45,8 rb"
                        onChange={(e) => updateContent({ socialFeedFollowers: e.target.value })}
                        className="w-full px-2 py-1 text-[11px] font-semibold rounded border border-slate-200 bg-white outline-none focus:border-blue-500 tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                        Label
                      </label>
                      <input
                        type="text"
                        value={
                          c.socialFeedFollowersLabel ??
                          (platform === 'youtube' ? 'Subscriber' : 'Follower')
                        }
                        placeholder={platform === 'youtube' ? 'Subscriber' : 'Follower'}
                        onChange={(e) =>
                          updateContent({ socialFeedFollowersLabel: e.target.value })
                        }
                        className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                      Bio Singkat Akun (Opsional)
                    </label>
                    <textarea
                      rows={2}
                      value={c.socialFeedBio ?? ''}
                      placeholder="Kosongkan jika tidak ingin menampilkan bio..."
                      onChange={(e) => updateContent({ socialFeedBio: e.target.value })}
                      className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500 resize-y"
                    />
                  </div>
                </div>

                {/* 3. Ukuran / Rasio Postingan */}
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1.5">
                    3. Ukuran / Rasio Postingan
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {(
                      [
                        { id: '1/1', label: '1:1' },
                        { id: '4/5', label: '4:5' },
                        { id: '9/16', label: '9:16' },
                        { id: '16/9', label: '16:9' },
                      ] as const
                    ).map((opt) => {
                      const active = currentRatio === opt.id;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => updateContent({ socialFeedRatio: opt.id })}
                          className={`py-1.5 px-2 rounded-lg text-xs font-semibold border transition-colors cursor-pointer tabular-nums ${
                            active
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                          }`}
                        >
                          {opt.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* 4. Daftar Postingan Carousel (Gambar / Video) */}
                <div className="space-y-2.5">
                  <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-slate-700">
                        4. Jumlah Postingan
                      </span>
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleSetSocialPostCount(posts.length - 1)}
                          disabled={posts.length <= 1}
                          className="w-6 h-6 rounded border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 text-xs font-bold text-slate-700 cursor-pointer"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          min={1}
                          max={20}
                          value={posts.length}
                          onChange={(e) => handleSetSocialPostCount(Number(e.target.value))}
                          className="w-12 h-6 px-1 text-center text-xs font-semibold rounded border border-slate-200 bg-white tabular-nums outline-none focus:border-blue-500"
                        />
                        <button
                          type="button"
                          onClick={() => handleSetSocialPostCount(posts.length + 1)}
                          disabled={posts.length >= 20}
                          className="w-6 h-6 rounded border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 text-xs font-bold text-slate-700 cursor-pointer"
                        >
                          +
                        </button>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={handleAddSocialPost}
                      disabled={posts.length >= 20}
                      className="w-full inline-flex items-center justify-center gap-1 py-1.5 px-2.5 rounded-md bg-blue-50 text-blue-700 hover:bg-blue-100 disabled:opacity-45 text-[11px] font-semibold cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tambah Postingan ({posts.length}/20)</span>
                    </button>
                  </div>

                  {posts.map((post, idx) => (
                    <div
                      key={post.id}
                      draggable
                      onDragStart={(e) => {
                        const activeTag = document.activeElement?.tagName;
                        if (activeTag === 'INPUT' || activeTag === 'TEXTAREA') {
                          e.preventDefault();
                          return;
                        }
                        e.dataTransfer.setData('application/lynk-sf-post', post.id);
                        e.dataTransfer.effectAllowed = 'move';
                        setDragItemState({ draggedId: post.id, targetId: null });
                      }}
                      onDragOver={(e) => {
                        e.preventDefault();
                        if (dragItemState.targetId !== post.id) {
                          setDragItemState((prev) => ({ ...prev, targetId: post.id }));
                        }
                      }}
                      onDrop={(e) => {
                        e.preventDefault();
                        const draggedId = e.dataTransfer.getData('application/lynk-sf-post');
                        if (draggedId && draggedId !== post.id) {
                          handleReorderSocialPost(draggedId, post.id);
                        }
                        setDragItemState({ draggedId: null, targetId: null });
                      }}
                      onDragEnd={() => setDragItemState({ draggedId: null, targetId: null })}
                      className={`p-2.5 rounded-lg border bg-slate-50/70 space-y-2 transition-colors ${
                        dragItemState.draggedId === post.id ? 'opacity-45' : ''
                      } ${
                        dragItemState.targetId === post.id && dragItemState.draggedId !== post.id
                          ? 'border-blue-500 ring-1 ring-blue-500/30'
                          : 'border-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1.5">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span
                            title="Tarik untuk ubah urutan"
                            className="text-slate-400 hover:text-slate-600 cursor-grab active:cursor-grabbing shrink-0"
                          >
                            <GripVertical className="w-3.5 h-3.5" />
                          </span>
                          <span className="text-[11px] font-bold text-slate-700">
                            Postingan #{idx + 1}
                          </span>
                        </div>

                        <div className="flex items-center gap-1">
                          <div className="inline-flex rounded-md border border-slate-200 bg-white p-0.5">
                            <button
                              type="button"
                              onClick={() => handleUpdateSocialPost(post.id, { mediaType: 'image' })}
                              className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold cursor-pointer ${
                                post.mediaType === 'image'
                                  ? 'bg-blue-600 text-white'
                                  : 'text-slate-600 hover:text-slate-900'
                              }`}
                            >
                              <ImageIcon className="w-2.5 h-2.5" />
                              <span>Gambar</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleUpdateSocialPost(post.id, { mediaType: 'video' })}
                              className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold cursor-pointer ${
                                post.mediaType === 'video'
                                  ? 'bg-blue-600 text-white'
                                  : 'text-slate-600 hover:text-slate-900'
                              }`}
                            >
                              <Video className="w-2.5 h-2.5" />
                              <span>Video</span>
                            </button>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleDeleteSocialPost(post.id)}
                            disabled={posts.length <= 1}
                            title="Hapus postingan"
                            className="p-1 rounded text-slate-400 hover:text-red-600 hover:bg-red-50 disabled:opacity-35 cursor-pointer shrink-0"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {post.mediaType === 'video' && (
                        <div className="space-y-1.5">
                          <label className="block text-[10px] font-medium text-slate-500">
                            Link Video (YouTube / TikTok / IG / FB / MP4) atau Upload
                          </label>
                          <div className="flex items-center gap-1">
                            <input
                              type="url"
                              value={post.videoUrl?.startsWith('data:') ? '' : post.videoUrl ?? ''}
                              placeholder={
                                post.videoUrl?.startsWith('data:')
                                  ? 'File video lokal terunggah'
                                  : 'https://... (link video)'
                              }
                              onChange={(e) =>
                                handleUpdateSocialPost(post.id, { videoUrl: e.target.value })
                              }
                              className="flex-1 min-w-0 px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                            />
                            <label
                              title="Upload video dari perangkat"
                              className="inline-flex items-center gap-1 px-2 py-1 rounded border border-slate-200 bg-white hover:bg-slate-100 text-[11px] font-medium text-slate-700 cursor-pointer shrink-0"
                            >
                              <Upload className="w-3 h-3 text-blue-600" />
                              <span>Video</span>
                              <input
                                type="file"
                                accept="video/*"
                                onChange={(e) => handleSocialPostVideoUpload(post.id, e)}
                                className="hidden"
                              />
                            </label>
                          </div>
                        </div>
                      )}

                      {/* Foto / Sampul Thumbnail */}
                      <div>
                        <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                          {post.mediaType === 'video'
                            ? 'Sampul / Thumbnail Video (Opsional)'
                            : 'Foto Postingan (Link / Upload)'}
                        </label>
                        <div className="flex items-center gap-2">
                          <div className="w-9 h-9 rounded-md border border-slate-200 bg-white overflow-hidden shrink-0 flex items-center justify-center">
                            <img
                              src={post.imageUrl || CAROUSEL_SAMPLE_1_SVG}
                              alt={`Post ${idx + 1}`}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1 min-w-0 flex items-center gap-1">
                            <input
                              type="url"
                              value={post.imageUrl.startsWith('data:') ? '' : post.imageUrl}
                              placeholder={
                                post.imageUrl.startsWith('data:') &&
                                !post.imageUrl.startsWith('data:image/svg+xml')
                                  ? 'Gambar lokal terunggah'
                                  : 'https://... (link foto)'
                              }
                              onChange={(e) =>
                                handleUpdateSocialPost(post.id, {
                                  imageUrl:
                                    e.target.value ||
                                    SAMPLE_CAROUSEL_IMAGES[idx % SAMPLE_CAROUSEL_IMAGES.length],
                                })
                              }
                              className="flex-1 min-w-0 px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                            />
                            <label
                              title="Upload foto dari perangkat"
                              className="inline-flex items-center gap-1 px-2 py-1 rounded border border-slate-200 bg-white hover:bg-slate-100 text-[11px] font-medium text-slate-700 cursor-pointer shrink-0"
                            >
                              <Upload className="w-3 h-3 text-blue-600" />
                              <span>Foto</span>
                              <input
                                type="file"
                                accept="image/*"
                                onChange={(e) => handleSocialPostImageUpload(post.id, e)}
                                className="hidden"
                              />
                            </label>
                          </div>
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                          Caption / Keterangan Postingan
                        </label>
                        <textarea
                          rows={2}
                          value={post.caption}
                          placeholder="Tulis caption postingan..."
                          onChange={(e) =>
                            handleUpdateSocialPost(post.id, { caption: e.target.value })
                          }
                          className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500 resize-y"
                        />
                      </div>

                      <div className="grid grid-cols-3 gap-1.5">
                        <div>
                          <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                            Suka
                          </label>
                          <input
                            type="text"
                            value={post.likes ?? ''}
                            placeholder="1,4 rb"
                            onChange={(e) =>
                              handleUpdateSocialPost(post.id, { likes: e.target.value })
                            }
                            className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500 tabular-nums"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                            Komentar
                          </label>
                          <input
                            type="text"
                            value={post.comments ?? ''}
                            placeholder="68"
                            onChange={(e) =>
                              handleUpdateSocialPost(post.id, { comments: e.target.value })
                            }
                            className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500 tabular-nums"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                            Link Post
                          </label>
                          <input
                            type="url"
                            value={post.url ?? ''}
                            placeholder="https://..."
                            onChange={(e) =>
                              handleUpdateSocialPost(post.id, { url: e.target.value })
                            }
                            className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}

          {selectedBlock.type === 'maps_place' && (
            <div className="space-y-3">
              {/* Foto Lokasi Maps */}
              <div className="space-y-2 p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                <label className="block text-[11px] font-semibold text-slate-700">
                  Foto Lokasi Maps
                </label>
                <div className="flex items-center gap-2">
                  <div className="w-16 h-11 rounded-md border border-slate-200 bg-white overflow-hidden shrink-0 flex items-center justify-center">
                    <img
                      src={c.mapsPhotoUrl || MAPS_LOCATION_SVG}
                      alt={c.mapsTitle || 'Foto Lokasi'}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0 flex items-center gap-1">
                    <input
                      type="url"
                      value={c.mapsPhotoUrl?.startsWith('data:') ? '' : c.mapsPhotoUrl ?? ''}
                      placeholder={
                        c.mapsPhotoUrl?.startsWith('data:') &&
                        !c.mapsPhotoUrl?.startsWith('data:image/svg+xml')
                          ? 'Foto lokal terunggah'
                          : 'https://... (link foto)'
                      }
                      onChange={(e) =>
                        updateContent({
                          mapsPhotoUrl: e.target.value || MAPS_LOCATION_SVG,
                        })
                      }
                      className="flex-1 min-w-0 px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                    />
                    <label
                      title="Upload foto lokasi"
                      className="inline-flex items-center gap-1 px-2 py-1 rounded border border-slate-200 bg-white hover:bg-slate-100 text-[11px] font-medium text-slate-700 cursor-pointer shrink-0"
                    >
                      <Upload className="w-3 h-3 text-blue-600" />
                      <span>Upload</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleMapsPhotoUpload}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-medium text-slate-500 mb-1">
                    Rasio Foto Lokasi
                  </label>
                  <div className="grid grid-cols-4 gap-1">
                    {(['16/9', '4/3', '4/5', '1/1'] as const).map((ratio) => {
                      const active = (c.mapsPhotoRatio ?? '16/9') === ratio;
                      return (
                        <button
                          key={ratio}
                          type="button"
                          onClick={() => updateContent({ mapsPhotoRatio: ratio })}
                          className={`py-1 rounded text-[11px] font-semibold border transition-colors cursor-pointer ${
                            active
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {ratio.replace('/', ':')}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                    Teks Badge Foto (kosongkan jika tidak perlu)
                  </label>
                  <input
                    type="text"
                    value={c.mapsPhotoBadgeLabel ?? 'Lihat foto'}
                    placeholder="Lihat foto"
                    onChange={(e) => updateContent({ mapsPhotoBadgeLabel: e.target.value })}
                    className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              {/* Nama Lokasi */}
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">
                  Nama Tempat / Lokasi
                </label>
                <input
                  type="text"
                  value={c.mapsTitle ?? ''}
                  placeholder="Diksar Satpam"
                  onChange={(e) => updateContent({ mapsTitle: e.target.value })}
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 focus:border-blue-500 outline-none"
                />
              </div>

              {/* Rating Bintang & Ulasan */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Rating Bintang (0–5)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={5}
                    step={0.1}
                    value={c.mapsRating ?? 4.9}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      updateContent({
                        mapsRating: Number.isFinite(val) ? Math.max(0, Math.min(5, val)) : 0,
                      });
                    }}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 focus:border-blue-500 outline-none tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Jumlah Ulasan
                  </label>
                  <input
                    type="text"
                    value={c.mapsReviewCount ?? ''}
                    placeholder="1.643"
                    onChange={(e) => updateContent({ mapsReviewCount: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 focus:border-blue-500 outline-none tabular-nums"
                  />
                </div>
              </div>

              {/* Layanan & Aksesibilitas */}
              <div className="space-y-2 p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Kategori / Layanan Utama
                  </label>
                  <input
                    type="text"
                    value={c.mapsService ?? ''}
                    placeholder="Layanan Satpam"
                    onChange={(e) => updateContent({ mapsService: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:border-blue-500 outline-none"
                  />
                </div>

                <div className="flex items-center justify-between pt-0.5">
                  <span className="text-[11px] font-medium text-slate-600">
                    Ikon Aksesibilitas (Kursi Roda)
                  </span>
                  <ToggleSwitch
                    checked={c.mapsAccessible ?? true}
                    onChange={(next) => updateContent({ mapsAccessible: next })}
                    label="Ikon Aksesibilitas"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                    Daftar Layanan Tambahan (pisahkan dengan koma)
                  </label>
                  <input
                    type="text"
                    value={c.mapsServicesList ?? ''}
                    placeholder="Contoh: Konsultasi Gratis, Buka 24 Jam, Parkir Luas"
                    onChange={(e) => updateContent({ mapsServicesList: e.target.value })}
                    className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                    Alamat / Jam Operasional (Opsional)
                  </label>
                  <input
                    type="text"
                    value={c.mapsAddress ?? ''}
                    placeholder="Jl. Merdeka No. 10, Jakarta · Buka 08.00–17.00"
                    onChange={(e) => updateContent({ mapsAddress: e.target.value })}
                    className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              {/* Link Google Maps */}
              <div className="space-y-2 p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                <label className="block text-[11px] font-semibold text-slate-700">
                  Link Google Maps (Opsional)
                </label>
                <input
                  type="url"
                  value={c.mapsUrl ?? ''}
                  placeholder="https://maps.google.com/..."
                  onChange={(e) => updateContent({ mapsUrl: e.target.value })}
                  className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                />
                <div>
                  <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                    Label Tombol Maps
                  </label>
                  <input
                    type="text"
                    value={c.mapsButtonLabel ?? 'Buka di Google Maps'}
                    placeholder="Buka di Google Maps"
                    onChange={(e) => updateContent({ mapsButtonLabel: e.target.value })}
                    className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>
          )}

          {selectedBlock.type === 'text' && (
            <>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Isi Teks</label>
                <textarea
                  rows={3}
                  value={c.text ?? ''}
                  placeholder="Tulis teks (kosongkan jika tidak digunakan)"
                  onChange={(e) => updateContent({ text: e.target.value })}
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 focus:border-blue-500 outline-none resize-y"
                />
                {!(c.text ?? '').trim() && (
                  <p className="mt-1 text-[11px] text-slate-400">
                    Teks kosong otomatis disembunyikan di pratinjau &amp; hasil halaman.
                  </p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Ukuran</label>
                  <select
                    value={c.variant ?? 'body'}
                    onChange={(e) =>
                      updateContent({ variant: e.target.value as 'h1' | 'h2' | 'body' })
                    }
                    className="w-full px-2 py-1.5 text-xs rounded-lg border border-slate-200 bg-white outline-none"
                  >
                    <option value="h1">Judul Besar</option>
                    <option value="h2">Subjudul</option>
                    <option value="body">Paragraf</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Ketebalan</label>
                  <select
                    value={c.fontWeight ?? 'normal'}
                    onChange={(e) =>
                      updateContent({ fontWeight: e.target.value as 'normal' | 'semibold' | 'bold' })
                    }
                    className="w-full px-2 py-1.5 text-xs rounded-lg border border-slate-200 bg-white outline-none"
                  >
                    <option value="normal">Normal</option>
                    <option value="semibold">Semi Tebal</option>
                    <option value="bold">Tebal</option>
                  </select>
                </div>
              </div>
            </>
          )}

          {selectedBlock.type === 'button' && (
            <>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Teks Tombol</label>
                <input
                  type="text"
                  value={c.label ?? ''}
                  onChange={(e) => updateContent({ label: e.target.value })}
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 focus:border-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">URL Tujuan</label>
                <input
                  type="url"
                  value={c.url ?? ''}
                  placeholder="https://..."
                  onChange={(e) => updateContent({ url: e.target.value })}
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 focus:border-blue-500 outline-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Warna Tombol</label>
                  <input
                    type="color"
                    value={c.buttonBg ?? '#2563EB'}
                    onChange={(e) => updateContent({ buttonBg: e.target.value })}
                    className="w-full h-8 rounded-lg border border-slate-200 p-0.5 cursor-pointer"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Warna Teks</label>
                  <input
                    type="color"
                    value={c.buttonText ?? '#FFFFFF'}
                    onChange={(e) => updateContent({ buttonText: e.target.value })}
                    className="w-full h-8 rounded-lg border border-slate-200 p-0.5 cursor-pointer"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">
                  Ikon Sebelah Kiri Tombol
                </label>
                <div className="grid grid-cols-4 gap-1">
                  {BUTTON_ICON_LIST.map((ic) => {
                    const activeIcon = resolveButtonIcon(c.buttonIcon, c.label);
                    const isActive = activeIcon === ic.id;
                    return (
                      <button
                        key={ic.id}
                        type="button"
                        onClick={() => updateContent({ buttonIcon: ic.id })}
                        className={`flex flex-col items-center justify-center gap-0.5 py-1.5 px-1 rounded-lg border text-[10px] font-medium transition-colors cursor-pointer ${
                          isActive
                            ? 'bg-blue-600 text-white border-blue-600'
                            : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {ic.id === 'none' ? (
                          <span className="h-3.5 leading-3.5 text-[11px] font-bold">—</span>
                        ) : (
                          <ButtonGlyph icon={ic.id} className="w-3.5 h-3.5" />
                        )}
                        <span className="truncate max-w-full">{ic.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          )}

          {selectedBlock.type === 'image' && (() => {
            const isCircle = c.imageShape === 'circle';
            const circleSize = c.circleSize ?? 112;
            const imageZoom = c.imageZoom ?? 100;
            return (
              <>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Unggah Gambar</label>
                  <label className="flex items-center justify-center gap-1.5 w-full py-2 px-3 rounded-lg border border-dashed border-slate-300 bg-slate-50 hover:bg-slate-100 text-xs font-medium text-slate-700 cursor-pointer transition-colors">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Pilih File Gambar</span>
                    <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                  </label>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Atau URL Gambar</label>
                  <input
                    type="text"
                    value={c.src ?? ''}
                    onChange={(e) => updateContent({ src: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 focus:border-blue-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1.5">Bentuk Foto</label>
                  <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 rounded-lg">
                    <button
                      type="button"
                      onClick={() => updateContent({ imageShape: 'rect' })}
                      className={`py-1.5 px-2 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                        !isCircle
                          ? 'bg-white text-emerald-700 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Kotak / Banner
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        updateContent({
                          imageShape: 'circle',
                          aspectRatio: '1/1',
                          objectFit: c.objectFit ?? 'cover',
                          circleSize,
                          imageZoom,
                        })
                      }
                      className={`py-1.5 px-2 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                        isCircle
                          ? 'bg-white text-emerald-700 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Bulat (Lingkaran)
                    </button>
                  </div>
                </div>

                {isCircle && (
                  <div className="p-3 rounded-xl bg-[#EFF7F4]/80 border border-emerald-200/80 space-y-3">
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-medium text-slate-700">Ukuran Lingkaran</span>
                        <span className="font-semibold text-emerald-700 tabular-nums">
                          {circleSize}px
                        </span>
                      </div>
                      <input
                        type="range"
                        min={48}
                        max={240}
                        step={2}
                        value={circleSize}
                        onChange={(e) =>
                          updateContent({ circleSize: Number(e.target.value) })
                        }
                        className="w-full accent-emerald-600 cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-medium text-slate-700">
                          Besar Foto di Dalam Lingkaran
                        </span>
                        <div className="flex items-center gap-1.5">
                          {imageZoom !== 100 && (
                            <button
                              type="button"
                              onClick={() => updateContent({ imageZoom: 100 })}
                              className="px-1.5 py-0.5 rounded bg-white border border-emerald-200 text-[10px] font-semibold text-emerald-700 hover:bg-emerald-50 cursor-pointer"
                            >
                              100%
                            </button>
                          )}
                          <span className="font-semibold text-emerald-700 tabular-nums">
                            {imageZoom}%
                          </span>
                        </div>
                      </div>
                      <input
                        type="range"
                        min={50}
                        max={220}
                        step={5}
                        value={imageZoom}
                        onChange={(e) =>
                          updateContent({ imageZoom: Number(e.target.value) })
                        }
                        className="w-full accent-emerald-600 cursor-pointer"
                      />
                    </div>

                    <button
                      type="button"
                      onClick={() => setInspectorTab('appearance')}
                      className="w-full py-1.5 px-2.5 rounded-lg bg-white border border-emerald-200 text-[11px] font-semibold text-emerald-700 hover:bg-emerald-50 transition-colors cursor-pointer"
                    >
                      Atur Outline, Warna &amp; Shadow di Tab Tampilan →
                    </button>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2">
                  {!isCircle && (
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">Rasio</label>
                      <select
                        value={c.aspectRatio ?? '16/9'}
                        onChange={(e) =>
                          updateContent({
                            aspectRatio: e.target.value as 'auto' | '16/9' | '4/3' | '1/1',
                          })
                        }
                        className="w-full px-2 py-1.5 text-xs rounded-lg border border-slate-200 bg-white outline-none"
                      >
                        <option value="auto">Otomatis</option>
                        <option value="16/9">16:9</option>
                        <option value="4/3">4:3</option>
                        <option value="1/1">1:1 Kotak</option>
                      </select>
                    </div>
                  )}
                  <div className={isCircle ? 'col-span-2' : ''}>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Penyesuaian</label>
                    <select
                      value={c.objectFit ?? 'cover'}
                      onChange={(e) =>
                        updateContent({ objectFit: e.target.value as 'cover' | 'contain' })
                      }
                      className="w-full px-2 py-1.5 text-xs rounded-lg border border-slate-200 bg-white outline-none"
                    >
                      <option value="cover">Penuhi (Cover)</option>
                      <option value="contain">Utuh (Contain)</option>
                    </select>
                  </div>
                </div>
              </>
            );
          })()}

          {selectedBlock.type === 'form' && (
            <>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Judul Form</label>
                <input
                  type="text"
                  value={c.formTitle ?? ''}
                  onChange={(e) => updateContent({ formTitle: e.target.value })}
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Label Tombol Kirim</label>
                <input
                  type="text"
                  value={c.submitLabel ?? ''}
                  onChange={(e) => updateContent({ submitLabel: e.target.value })}
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Warna Tombol Form</label>
                <input
                  type="color"
                  value={c.buttonColor ?? '#2563EB'}
                  onChange={(e) => updateContent({ buttonColor: e.target.value })}
                  className="w-full h-8 rounded-lg border border-slate-200 p-0.5 cursor-pointer"
                />
              </div>
            </>
          )}

          {(selectedBlock.type === 'youtube' ||
            selectedBlock.type === 'facebook_video' ||
            selectedBlock.type === 'tiktok_video' ||
            selectedBlock.type === 'instagram_video') && (() => {
            const isYt = selectedBlock.type === 'youtube';
            const isFb = selectedBlock.type === 'facebook_video';
            const isIg = selectedBlock.type === 'instagram_video';
            const currentUrl = isYt ? c.youtubeUrl ?? '' : c.videoUrl ?? '';
            const currentRatio =
              c.videoAspectRatio ??
              c.youtubeAspectRatio ??
              (selectedBlock.type === 'tiktok_video' || isIg ? '9/16' : '16/9');
            const currentAuto = c.videoAutoplay ?? c.youtubeAutoplay ?? true;
            const currentVol = c.videoVolume ?? c.youtubeVolume ?? 75;

            return (
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    {isYt
                      ? 'URL Video YouTube'
                      : isFb
                      ? 'URL Video Facebook'
                      : isIg
                      ? 'URL Video / Reels Instagram'
                      : 'URL Video TikTok'}
                  </label>
                  <input
                    type="url"
                    value={currentUrl}
                    placeholder={
                      isYt
                        ? 'https://www.youtube.com/watch?v=...'
                        : isFb
                        ? 'https://www.facebook.com/... atau fb.watch/...'
                        : isIg
                        ? 'https://www.instagram.com/reel/...'
                        : 'https://www.tiktok.com/... atau vt.tiktok.com/...'
                    }
                    onChange={(e) =>
                      updateContent(
                        isYt ? { youtubeUrl: e.target.value } : { videoUrl: e.target.value }
                      )
                    }
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 focus:border-blue-500 outline-none"
                  />
                </div>

                {!isYt && (
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">
                      URL Gambar Sampul (Opsional)
                    </label>
                    <input
                      type="url"
                      value={c.videoPoster ?? ''}
                      placeholder="https://... (kosongkan untuk sampul bawaan)"
                      onChange={(e) => updateContent({ videoPoster: e.target.value })}
                      className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 focus:border-blue-500 outline-none"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1.5">
                    Ukuran / Rasio Embed
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {(
                      [
                        { id: '1/1', label: '1:1' },
                        { id: '4/5', label: '4:5' },
                        { id: '9/16', label: '9:16' },
                        { id: '16/9', label: '16:9' },
                      ] as const
                    ).map((opt) => {
                      const active = currentRatio === opt.id;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() =>
                            updateContent(
                              isYt
                                ? { youtubeAspectRatio: opt.id, videoAspectRatio: opt.id }
                                : { videoAspectRatio: opt.id }
                            )
                          }
                          className={`py-1.5 px-2 rounded-lg text-xs font-semibold border transition-colors cursor-pointer tabular-nums ${
                            active
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                          }`}
                        >
                          {opt.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="flex items-center justify-between gap-3 pt-1">
                  <span className="text-xs font-medium text-slate-700">Auto Play Video</span>
                  <ToggleSwitch
                    checked={currentAuto}
                    onChange={(checked) =>
                      updateContent(
                        isYt
                          ? { youtubeAutoplay: checked, videoAutoplay: checked }
                          : { videoAutoplay: checked }
                      )
                    }
                    label="Auto Play Video"
                  />
                </div>

                <SliderRow
                  label="Volume Audio"
                  value={`${currentVol}%`}
                  min={0}
                  max={100}
                  current={currentVol}
                  onChange={(val) =>
                    updateContent(
                      isYt
                        ? { youtubeVolume: val, videoVolume: val }
                        : { videoVolume: val }
                    )
                  }
                />
              </div>
            );
          })()}

          {selectedBlock.type === 'divider' && (
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Gaya Garis</label>
                <select
                  value={c.lineStyle ?? 'solid'}
                  onChange={(e) =>
                    updateContent({ lineStyle: e.target.value as 'solid' | 'dashed' | 'dotted' })
                  }
                  className="w-full px-2 py-1.5 text-xs rounded-lg border border-slate-200 bg-white outline-none"
                >
                  <option value="solid">Lurus</option>
                  <option value="dashed">Putus-putus</option>
                  <option value="dotted">Titik-titik</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Warna Garis</label>
                <input
                  type="color"
                  value={c.lineColor ?? '#E2E8F0'}
                  onChange={(e) => updateContent({ lineColor: e.target.value })}
                  className="w-full h-8 rounded-lg border border-slate-200 p-0.5 cursor-pointer"
                />
              </div>
            </div>
          )}

          {selectedBlock.type === 'social' && (() => {
            const socialItems = c.socialItems ?? [];
            const visibleCount = socialItems.filter((item) => item.visible).length;

            return (
              <div className="space-y-3.5">
                {/* Tambah Ikon Sosial Media */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-600">
                      Daftar Ikon ({visibleCount}/{socialItems.length} tampil)
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <select
                      value={newSocialPlatform}
                      onChange={(e) => setNewSocialPlatform(e.target.value as SocialPlatform)}
                      className="flex-1 min-w-0 px-2 py-1.5 text-xs rounded-lg border border-slate-200 bg-white outline-none focus:border-blue-500"
                    >
                      {SOCIAL_PLATFORM_LIST.map((plat) => (
                        <option key={plat.id} value={plat.id}>
                          {plat.label}
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      onClick={() => handleAddSocialItem(newSocialPlatform)}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold cursor-pointer shrink-0 transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tambah</span>
                    </button>
                  </div>
                </div>

                {/* Daftar Kartu Ikon */}
                <div className="space-y-2">
                  {socialItems.length === 0 ? (
                    <div className="py-4 px-3 rounded-lg border border-dashed border-slate-300 bg-slate-50 text-center text-xs text-slate-500">
                      Belum ada ikon sosial media. Pilih platform di atas lalu klik <strong>Tambah</strong>.
                    </div>
                  ) : (
                    socialItems.map((item) => {
                      const meta = SOCIAL_PLATFORMS[item.platform];
                      return (
                        <div
                          key={item.id}
                          draggable
                          onDragStart={(e) => {
                            const activeTag = document.activeElement?.tagName;
                            if (activeTag === 'INPUT' || activeTag === 'SELECT') {
                              e.preventDefault();
                              return;
                            }
                            e.dataTransfer.setData('application/lynk-social-item', item.id);
                            e.dataTransfer.effectAllowed = 'move';
                            setDragItemState({ draggedId: item.id, targetId: null });
                          }}
                          onDragOver={(e) => {
                            e.preventDefault();
                            if (dragItemState.targetId !== item.id) {
                              setDragItemState((prev) => ({ ...prev, targetId: item.id }));
                            }
                          }}
                          onDrop={(e) => {
                            e.preventDefault();
                            const draggedId = e.dataTransfer.getData('application/lynk-social-item');
                            if (draggedId && draggedId !== item.id) {
                              handleReorderSocialItem(draggedId, item.id);
                            }
                            setDragItemState({ draggedId: null, targetId: null });
                          }}
                          onDragEnd={() => setDragItemState({ draggedId: null, targetId: null })}
                          className={`p-2.5 rounded-lg border space-y-2 transition-colors ${
                            item.visible
                              ? 'bg-slate-50/70 border-slate-200'
                              : 'bg-slate-100/70 border-slate-200/80 opacity-75'
                          } ${dragItemState.draggedId === item.id ? 'opacity-45' : ''} ${
                            dragItemState.targetId === item.id && dragItemState.draggedId !== item.id
                              ? 'border-blue-500 ring-1 ring-blue-500/30'
                              : ''
                          }`}
                        >
                          <div className="flex items-center gap-1.5">
                            <span
                              title="Tarik untuk geser urutan ikon"
                              className="text-slate-400 hover:text-slate-600 cursor-grab active:cursor-grabbing shrink-0"
                            >
                              <GripVertical className="w-3.5 h-3.5" />
                            </span>

                            <span
                              style={{ backgroundColor: meta.brandColor }}
                              className="w-6 h-6 rounded-md text-white inline-flex items-center justify-center shrink-0"
                            >
                              <SocialGlyph platform={item.platform} className="w-3.5 h-3.5" />
                            </span>

                            <select
                              value={item.platform}
                              onChange={(e) => {
                                const nextPlatform = e.target.value as SocialPlatform;
                                const nextMeta = SOCIAL_PLATFORMS[nextPlatform];
                                const oldPlaceholder = meta.placeholderUrl;
                                handleUpdateSocialItem(item.id, {
                                  platform: nextPlatform,
                                  url:
                                    !item.url || item.url === oldPlaceholder
                                      ? nextMeta.placeholderUrl
                                      : item.url,
                                });
                              }}
                              className="flex-1 min-w-0 px-2 py-1 text-xs font-semibold rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                            >
                              {SOCIAL_PLATFORM_LIST.map((plat) => (
                                <option key={plat.id} value={plat.id}>
                                  {plat.label}
                                </option>
                              ))}
                            </select>

                            <button
                              type="button"
                              onClick={() =>
                                handleUpdateSocialItem(item.id, { visible: !item.visible })
                              }
                              title={item.visible ? 'Sembunyikan ikon' : 'Tampilkan ikon'}
                              className={`inline-flex items-center gap-1 px-1.5 py-1 rounded text-[11px] font-medium cursor-pointer shrink-0 transition-colors ${
                                item.visible
                                  ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                                  : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
                              }`}
                            >
                              {item.visible ? (
                                <Eye className="w-3.5 h-3.5" />
                              ) : (
                                <EyeOff className="w-3.5 h-3.5" />
                              )}
                            </button>

                            <button
                              type="button"
                              onClick={() => handleDeleteSocialItem(item.id)}
                              title="Hapus ikon"
                              className="p-1 rounded text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer shrink-0"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <input
                            type="url"
                            value={item.url}
                            placeholder={meta.placeholderUrl}
                            onChange={(e) =>
                              handleUpdateSocialItem(item.id, { url: e.target.value })
                            }
                            className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                          />
                        </div>
                      );
                    })
                  )}
                </div>

                {/* Gaya, Ukuran, Jarak & Warna Ikon */}
                <div className="pt-2 border-t border-slate-200 space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-1">
                        Gaya Ikon
                      </label>
                      <select
                        value={c.socialStyle ?? 'filled'}
                        onChange={(e) =>
                          updateContent({
                            socialStyle: e.target.value as 'filled' | 'outline' | 'minimal',
                          })
                        }
                        className="w-full px-2 py-1.5 text-[11px] rounded-lg border border-slate-200 bg-white outline-none"
                      >
                        <option value="filled">Isi</option>
                        <option value="outline">Garis</option>
                        <option value="minimal">Minimal</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-1">
                        Bentuk
                      </label>
                      <select
                        value={c.socialShape ?? 'circle'}
                        onChange={(e) =>
                          updateContent({
                            socialShape: e.target.value as 'circle' | 'rounded',
                          })
                        }
                        className="w-full px-2 py-1.5 text-[11px] rounded-lg border border-slate-200 bg-white outline-none"
                      >
                        <option value="circle">Bulat</option>
                        <option value="rounded">Kotak Tumpul</option>
                      </select>
                    </div>
                  </div>

                  {(() => {
                    const { boxSize, gap } = resolveSocialMetrics(c);
                    return (
                      <>
                        <SliderRow
                          label="Besar Ikon"
                          value={`${boxSize}px`}
                          min={24}
                          max={64}
                          current={boxSize}
                          onChange={(val) => updateContent({ socialIconSize: val })}
                        />
                        <SliderRow
                          label="Jarak Antar Ikon"
                          value={`${gap}px`}
                          min={0}
                          max={32}
                          current={gap}
                          onChange={(val) => updateContent({ socialGap: val })}
                        />
                      </>
                    );
                  })()}

                  <div className="flex items-center justify-between gap-3">
                    <span className="text-xs font-medium text-slate-700">
                      Gunakan Warna Brand Asli
                    </span>
                    <ToggleSwitch
                      checked={c.socialUseBrandColors ?? true}
                      onChange={(checked) => updateContent({ socialUseBrandColors: checked })}
                      label="Gunakan Warna Brand Asli"
                    />
                  </div>

                  {c.socialUseBrandColors === false && (
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">
                        Warna Kustom Ikon
                      </label>
                      <input
                        type="color"
                        value={c.socialColor ?? '#2563EB'}
                        onChange={(e) => updateContent({ socialColor: e.target.value })}
                        className="w-full h-8 rounded-lg border border-slate-200 p-0.5 cursor-pointer"
                      />
                    </div>
                  )}
                </div>
              </div>
            );
          })()}

          {selectedBlock.type === 'social_follower' && (() => {
            const accounts = c.socialFollowerAccounts ?? [];
            const gap = c.socialFollowerGap ?? 10;

            return (
              <div className="space-y-3.5">
                {/* Tambah Akun Sosmed */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-600">
                      Akun Sosmed &amp; Follower ({accounts.length})
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <select
                      value={newSocialFollowerPlatform}
                      onChange={(e) =>
                        setNewSocialFollowerPlatform(e.target.value as SocialPlatform)
                      }
                      className="flex-1 min-w-0 px-2 py-1.5 text-xs rounded-lg border border-slate-200 bg-white outline-none focus:border-blue-500"
                    >
                      {SOCIAL_PLATFORM_LIST.map((plat) => (
                        <option key={plat.id} value={plat.id}>
                          {plat.label}
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      onClick={() => handleAddSocialFollowerAccount(newSocialFollowerPlatform)}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold cursor-pointer shrink-0 transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tambah</span>
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddPopularSocialFollowers}
                    className="w-full py-1.5 px-2.5 rounded-lg border border-emerald-200 bg-emerald-50/70 hover:bg-emerald-100 text-emerald-700 text-[11px] font-semibold cursor-pointer transition-colors"
                  >
                    + Tambah Cepat Sosmed Populer (IG, TikTok, FB, YT, X, dll)
                  </button>
                </div>

                {accounts.length > 1 && (
                  <SliderRow
                    label="Jarak Antar Kartu"
                    value={`${gap}px`}
                    min={0}
                    max={24}
                    current={gap}
                    onChange={(val) => updateContent({ socialFollowerGap: val })}
                  />
                )}

                {/* Daftar Kartu Akun */}
                <div className="space-y-2.5">
                  {accounts.length === 0 ? (
                    <div className="py-4 px-3 rounded-lg border border-dashed border-slate-300 bg-slate-50 text-center text-xs text-slate-500">
                      Belum ada akun sosial media. Pilih platform di atas lalu klik{' '}
                      <strong>Tambah</strong>.
                    </div>
                  ) : (
                    accounts.map((acc, idx) => {
                      const meta = SOCIAL_PLATFORMS[acc.platform] ?? SOCIAL_PLATFORMS.instagram;
                      return (
                        <div
                          key={acc.id}
                          draggable
                          onDragStart={(e) => {
                            const activeTag = document.activeElement?.tagName;
                            if (
                              activeTag === 'INPUT' ||
                              activeTag === 'TEXTAREA' ||
                              activeTag === 'SELECT'
                            ) {
                              e.preventDefault();
                              return;
                            }
                            e.dataTransfer.setData('application/lynk-sfol-item', acc.id);
                            e.dataTransfer.effectAllowed = 'move';
                            setDragItemState({ draggedId: acc.id, targetId: null });
                          }}
                          onDragOver={(e) => {
                            e.preventDefault();
                            if (dragItemState.targetId !== acc.id) {
                              setDragItemState((prev) => ({ ...prev, targetId: acc.id }));
                            }
                          }}
                          onDrop={(e) => {
                            e.preventDefault();
                            const draggedId = e.dataTransfer.getData('application/lynk-sfol-item');
                            if (draggedId && draggedId !== acc.id) {
                              handleReorderSocialFollowerAccount(draggedId, acc.id);
                            }
                            setDragItemState({ draggedId: null, targetId: null });
                          }}
                          onDragEnd={() => setDragItemState({ draggedId: null, targetId: null })}
                          className={`p-2.5 rounded-lg border bg-slate-50/80 space-y-2.5 transition-colors ${
                            dragItemState.draggedId === acc.id ? 'opacity-45' : ''
                          } ${
                            dragItemState.targetId === acc.id &&
                            dragItemState.draggedId !== acc.id
                              ? 'border-blue-500 ring-1 ring-blue-500/30'
                              : 'border-slate-200'
                          }`}
                        >
                          {/* Header Kartu: Drag, Ikon, Pilih Platform, Hapus */}
                          <div className="flex items-center gap-1.5">
                            <span
                              title="Tarik untuk geser urutan kartu"
                              className="text-slate-400 hover:text-slate-600 cursor-grab active:cursor-grabbing shrink-0"
                            >
                              <GripVertical className="w-3.5 h-3.5" />
                            </span>

                            <span
                              style={{ backgroundColor: meta.brandColor }}
                              className="w-6 h-6 rounded-md text-white inline-flex items-center justify-center shrink-0"
                            >
                              <SocialGlyph platform={acc.platform} className="w-3.5 h-3.5" />
                            </span>

                            <select
                              value={acc.platform}
                              onChange={(e) => {
                                const nextPlat = e.target.value as SocialPlatform;
                                const nextMeta = SOCIAL_PLATFORMS[nextPlat];
                                handleUpdateSocialFollowerAccount(acc.id, {
                                  platform: nextPlat,
                                  accountUrl:
                                    !acc.accountUrl || acc.accountUrl === meta.placeholderUrl
                                      ? nextMeta.placeholderUrl
                                      : acc.accountUrl,
                                });
                              }}
                              className="flex-1 min-w-0 px-2 py-1 text-xs font-semibold rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                            >
                              {SOCIAL_PLATFORM_LIST.map((plat) => (
                                <option key={plat.id} value={plat.id}>
                                  #{idx + 1} · {plat.label}
                                </option>
                              ))}
                            </select>

                            <button
                              type="button"
                              onClick={() => handleDeleteSocialFollowerAccount(acc.id)}
                              title="Hapus akun ini"
                              className="p-1 rounded text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer shrink-0"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {/* Foto Profil */}
                          <div className="flex items-center gap-2">
                            <div
                              style={{ backgroundColor: meta.brandColor }}
                              className="w-9 h-9 rounded-full text-white overflow-hidden shrink-0 flex items-center justify-center border border-slate-200"
                            >
                              {acc.avatar ? (
                                <img
                                  src={acc.avatar}
                                  alt={acc.accountName || meta.label}
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                <SocialGlyph platform={acc.platform} className="w-4 h-4" />
                              )}
                            </div>
                            <div className="flex-1 min-w-0 flex items-center gap-1">
                              <input
                                type="url"
                                value={acc.avatar?.startsWith('data:') ? '' : acc.avatar ?? ''}
                                placeholder={
                                  acc.avatar?.startsWith('data:')
                                    ? 'Foto profil terunggah'
                                    : 'URL Foto Profil (opsional)'
                                }
                                onChange={(e) =>
                                  handleUpdateSocialFollowerAccount(acc.id, {
                                    avatar: e.target.value,
                                  })
                                }
                                className="flex-1 min-w-0 px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                              />
                              <label className="inline-flex items-center gap-1 px-2 py-1 rounded border border-slate-200 bg-white hover:bg-slate-100 text-[11px] font-medium text-slate-700 cursor-pointer shrink-0">
                                <Upload className="w-3 h-3 text-blue-600" />
                                <span>Upload</span>
                                <input
                                  type="file"
                                  accept="image/*"
                                  onChange={(e) => handleSocialFollowerAvatarUpload(acc.id, e)}
                                  className="hidden"
                                />
                              </label>
                              {acc.avatar && (
                                <button
                                  type="button"
                                  title="Reset foto ke ikon platform"
                                  onClick={() =>
                                    handleUpdateSocialFollowerAccount(acc.id, { avatar: '' })
                                  }
                                  className="p-1 rounded border border-slate-200 bg-white text-slate-400 hover:text-red-600 cursor-pointer shrink-0"
                                >
                                  <X className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Nama & Handle */}
                          <div className="grid grid-cols-2 gap-1.5">
                            <div>
                              <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                                Nama Akun
                              </label>
                              <input
                                type="text"
                                value={acc.accountName}
                                placeholder="Studio Kreatif Nusantara"
                                onChange={(e) =>
                                  handleUpdateSocialFollowerAccount(acc.id, {
                                    accountName: e.target.value,
                                  })
                                }
                                className="w-full px-2 py-1 text-xs font-semibold rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                                Username / Handle
                              </label>
                              <input
                                type="text"
                                value={acc.handle}
                                placeholder="@studiokreatif"
                                onChange={(e) =>
                                  handleUpdateSocialFollowerAccount(acc.id, {
                                    handle: e.target.value,
                                  })
                                }
                                className="w-full px-2 py-1 text-xs rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                              />
                            </div>
                          </div>

                          {/* Teks Tombol & Link Profil */}
                          <div className="grid grid-cols-2 gap-1.5">
                            <div>
                              <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                                Teks Tombol
                              </label>
                              <input
                                type="text"
                                value={acc.followLabel ?? 'Ikuti'}
                                placeholder="Ikuti"
                                onChange={(e) =>
                                  handleUpdateSocialFollowerAccount(acc.id, {
                                    followLabel: e.target.value,
                                  })
                                }
                                className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                                Link Profil Akun
                              </label>
                              <input
                                type="url"
                                value={acc.accountUrl ?? ''}
                                placeholder={meta.placeholderUrl}
                                onChange={(e) =>
                                  handleUpdateSocialFollowerAccount(acc.id, {
                                    accountUrl: e.target.value,
                                  })
                                }
                                className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500"
                              />
                            </div>
                          </div>

                          {/* Centang Verifikasi */}
                          <div className="flex items-center justify-between gap-2 pt-0.5">
                            <span className="text-[11px] font-medium text-slate-700">
                              Centang Verifikasi Akun
                            </span>
                            <ToggleSwitch
                              checked={acc.verified ?? true}
                              onChange={(checked) =>
                                handleUpdateSocialFollowerAccount(acc.id, { verified: checked })
                              }
                              label="Centang Verifikasi Akun"
                            />
                          </div>

                          {/* 3 Statistik (Angka + Label Opsional) */}
                          <div className="p-2 rounded-lg bg-white border border-slate-200 space-y-1.5">
                            <div className="text-[10px] font-semibold text-slate-500">
                              Statistik &amp; Follower (kosongkan angka untuk sembunyikan)
                            </div>
                            <div className="grid grid-cols-3 gap-1.5">
                              <div className="space-y-1">
                                <input
                                  type="text"
                                  value={acc.postsCount ?? ''}
                                  placeholder="128"
                                  onChange={(e) =>
                                    handleUpdateSocialFollowerAccount(acc.id, {
                                      postsCount: e.target.value,
                                    })
                                  }
                                  className="w-full px-1.5 py-1 text-[11px] font-bold rounded border border-slate-200 bg-slate-50 outline-none focus:border-blue-500 tabular-nums text-center"
                                />
                                <input
                                  type="text"
                                  value={acc.postsLabel ?? 'Postingan'}
                                  placeholder="Postingan"
                                  onChange={(e) =>
                                    handleUpdateSocialFollowerAccount(acc.id, {
                                      postsLabel: e.target.value,
                                    })
                                  }
                                  className="w-full px-1.5 py-0.5 text-[10px] text-slate-600 rounded border border-slate-200 bg-white outline-none focus:border-blue-500 text-center"
                                />
                              </div>
                              <div className="space-y-1">
                                <input
                                  type="text"
                                  value={acc.followers ?? ''}
                                  placeholder="45,8 rb"
                                  onChange={(e) =>
                                    handleUpdateSocialFollowerAccount(acc.id, {
                                      followers: e.target.value,
                                    })
                                  }
                                  className="w-full px-1.5 py-1 text-[11px] font-bold rounded border border-slate-200 bg-slate-50 outline-none focus:border-blue-500 tabular-nums text-center"
                                />
                                <input
                                  type="text"
                                  value={acc.followersLabel ?? 'Follower'}
                                  placeholder="Follower"
                                  onChange={(e) =>
                                    handleUpdateSocialFollowerAccount(acc.id, {
                                      followersLabel: e.target.value,
                                    })
                                  }
                                  className="w-full px-1.5 py-0.5 text-[10px] text-slate-600 rounded border border-slate-200 bg-white outline-none focus:border-blue-500 text-center"
                                />
                              </div>
                              <div className="space-y-1">
                                <input
                                  type="text"
                                  value={acc.following ?? ''}
                                  placeholder="312"
                                  onChange={(e) =>
                                    handleUpdateSocialFollowerAccount(acc.id, {
                                      following: e.target.value,
                                    })
                                  }
                                  className="w-full px-1.5 py-1 text-[11px] font-bold rounded border border-slate-200 bg-slate-50 outline-none focus:border-blue-500 tabular-nums text-center"
                                />
                                <input
                                  type="text"
                                  value={acc.followingLabel ?? 'Mengikuti'}
                                  placeholder="Mengikuti"
                                  onChange={(e) =>
                                    handleUpdateSocialFollowerAccount(acc.id, {
                                      followingLabel: e.target.value,
                                    })
                                  }
                                  className="w-full px-1.5 py-0.5 text-[10px] text-slate-600 rounded border border-slate-200 bg-white outline-none focus:border-blue-500 text-center"
                                />
                              </div>
                            </div>
                          </div>

                          {/* Bio Opsional */}
                          <div>
                            <label className="block text-[10px] font-medium text-slate-500 mb-0.5">
                              Bio Singkat (Opsional)
                            </label>
                            <textarea
                              rows={2}
                              value={acc.bio ?? ''}
                              placeholder="Deskripsi singkat akun sosmed..."
                              onChange={(e) =>
                                handleUpdateSocialFollowerAccount(acc.id, {
                                  bio: e.target.value,
                                })
                              }
                              className="w-full px-2 py-1 text-[11px] rounded border border-slate-200 bg-white outline-none focus:border-blue-500 resize-y"
                            />
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })()}
            </section>
          )}

          {inspectorTab === 'appearance' && (() => {
            const isProfilePhoto =
              selectedBlock.type === 'image' &&
              (c.imageShape === 'circle' ||
                selectedBlock.label.toLowerCase().includes('profil'));
            const isCustomTextColor = s.useThemeTextColor === false;
            const isContainerLike =
              selectedBlock.type === 'container' ||
              selectedBlock.type === 'toggle_container' ||
              selectedBlock.type === 'row';

            const applyInheritToDescendants = (
              children?: BuilderBlock[]
            ): BuilderBlock[] | undefined =>
              children?.map((ch) => ({
                ...ch,
                style: {
                  ...ch.style,
                  useThemeTextColor: true,
                  textColor: theme.textColor,
                },
                children: applyInheritToDescendants(ch.children),
              }));

            return (
            <div className="space-y-6">
              {isProfilePhoto && (
                <div className="p-3 rounded-xl bg-[#EFF7F4]/80 border border-emerald-200/80 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-slate-800">
                      Outline &amp; Shadow Foto Profil
                    </span>
                    {c.imageShape !== 'circle' && (
                      <button
                        type="button"
                        onClick={() =>
                          updateContent({
                            imageShape: 'circle',
                            aspectRatio: '1/1',
                            circleSize: c.circleSize ?? 112,
                            imageZoom: c.imageZoom ?? 100,
                          })
                        }
                        className="px-2 py-0.5 rounded-md bg-white border border-emerald-200 text-[10px] font-semibold text-emerald-700 hover:bg-emerald-50 cursor-pointer"
                      >
                        Jadikan Bulat
                      </button>
                    )}
                  </div>

                  {/* Ukuran Outline */}
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-medium text-slate-700">Ukuran Outline</span>
                      <span className="font-semibold text-emerald-700 tabular-nums">
                        {s.borderWidth}px
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={16}
                      step={1}
                      value={s.borderWidth}
                      onChange={(e) => updateStyle({ borderWidth: Number(e.target.value) })}
                      className="w-full accent-emerald-600 cursor-pointer"
                    />
                    <div className="grid grid-cols-5 gap-1 mt-1.5">
                      {[0, 2, 4, 6, 8].map((w) => (
                        <button
                          key={w}
                          type="button"
                          onClick={() => updateStyle({ borderWidth: w })}
                          className={`py-1 rounded-md border text-[10px] font-semibold cursor-pointer transition-colors ${
                            s.borderWidth === w
                              ? 'bg-emerald-500 text-white border-emerald-500'
                              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          {w}px
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Warna Outline */}
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1.5">
                      Warna Outline
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={s.borderColor || '#FFFFFF'}
                        onChange={(e) =>
                          updateStyle({
                            borderColor: e.target.value,
                            borderWidth: s.borderWidth > 0 ? s.borderWidth : 4,
                          })
                        }
                        className="w-9 h-8 rounded-lg border border-slate-200 p-0.5 cursor-pointer shrink-0 bg-white"
                      />
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {[
                          { color: '#FFFFFF', title: 'Putih' },
                          { color: '#0F172A', title: 'Gelap' },
                          { color: theme.accentColor, title: 'Aksen Tema' },
                          { color: '#F59E0B', title: 'Emas' },
                        ].map((sw, idx) => (
                          <button
                            key={`${sw.color}_${idx}`}
                            type="button"
                            title={sw.title}
                            onClick={() =>
                              updateStyle({
                                borderColor: sw.color,
                                borderWidth: s.borderWidth > 0 ? s.borderWidth : 4,
                              })
                            }
                            style={{ backgroundColor: sw.color }}
                            className={`w-6 h-6 rounded-full border cursor-pointer transition-transform ${
                              s.borderColor.toLowerCase() === sw.color.toLowerCase()
                                ? 'ring-2 ring-emerald-500 ring-offset-1 border-slate-300 scale-105'
                                : 'border-slate-300 hover:scale-105'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Shadow Foto Profil */}
                  <div className="space-y-2">
                    <label className="block text-xs font-medium text-slate-700">
                      Shadow Foto
                    </label>
                    <div className="grid grid-cols-4 gap-1">
                      {(
                        [
                          { id: 'none', label: 'Tanpa' },
                          { id: 'sm', label: 'Halus' },
                          { id: 'md', label: 'Sedang' },
                          { id: 'lg', label: 'Tegas' },
                        ] as const
                      ).map((opt) => (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => updateStyle({ shadow: opt.id })}
                          className={`py-1 px-1.5 rounded-lg border text-[11px] font-semibold cursor-pointer transition-colors ${
                            s.shadow === opt.id
                              ? 'bg-emerald-500 text-white border-emerald-500'
                              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>

                    {s.shadow !== 'none' && (
                      <div className="flex items-center justify-between gap-2 pt-0.5">
                        <span className="text-[11px] font-medium text-slate-600">
                          Warna Shadow
                        </span>
                        <div className="flex items-center gap-1.5">
                          <input
                            type="color"
                            value={s.shadowColor || '#0F172A'}
                            onChange={(e) => updateStyle({ shadowColor: e.target.value })}
                            className="w-7 h-7 rounded border border-slate-200 p-0.5 cursor-pointer bg-white"
                          />
                          {s.shadowColor && (
                            <button
                              type="button"
                              onClick={() => updateStyle({ shadowColor: undefined })}
                              className="px-2 py-1 rounded-md bg-white border border-slate-200 text-[10px] font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
                            >
                              Default
                            </button>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* 1. Full Kanan-Kiri (Tanpa Margin) */}
              <div className="p-3 rounded-xl bg-[#EFF7F4]/80 border border-emerald-200/70 space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[13px] font-semibold text-slate-800 flex items-center gap-1.5">
                    <LayoutTemplate className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Full Kanan-Kiri (Tanpa Margin)</span>
                  </span>
                  <ToggleSwitch
                    checked={Boolean(s.fullBleed)}
                    onChange={(checked) =>
                      updateStyle(
                        checked
                          ? { fullBleed: true, widthPercent: 100 }
                          : { fullBleed: false }
                      )
                    }
                    label="Full Kanan-Kiri (Tanpa Margin)"
                  />
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[12px] text-slate-600">
                    {s.fullBleed
                      ? 'Menempel penuh ke tepi kiri & kanan.'
                      : 'Melebarkan kotak ini saja sampai tepi.'}
                  </span>
                  {s.fullBleed && s.borderRadius > 0 && (
                    <button
                      type="button"
                      onClick={() => updateStyle({ borderRadius: 0 })}
                      className="px-2 py-0.5 rounded-lg bg-white border border-emerald-200 text-[11px] font-semibold text-emerald-700 hover:bg-emerald-50 shrink-0 cursor-pointer"
                    >
                      Sudut 0px
                    </button>
                  )}
                </div>
              </div>

              {/* Jarak Atas Halaman */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-slate-800">
                    Jarak Atas Halaman
                  </span>
                  <span className="text-xs font-semibold text-emerald-700 tabular-nums">
                    {advanceOptions.pageTopPadding ?? (s.fullBleed ? 0 : 12)}px
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { val: 0, label: '0px Rapat' },
                    { val: 12, label: '12px Rapi' },
                    { val: 24, label: '24px Lega' },
                  ].map((opt) => {
                    const currentTop = advanceOptions.pageTopPadding ?? (s.fullBleed ? 0 : 12);
                    const active = currentTop === opt.val;
                    return (
                      <button
                        key={opt.val}
                        type="button"
                        onClick={() => onUpdateAdvanceOptions({ pageTopPadding: opt.val })}
                        className={`py-1 px-2 rounded-lg border text-[11px] font-semibold transition-colors cursor-pointer ${
                          active
                            ? 'bg-emerald-500 text-white border-emerald-500'
                            : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {opt.label}
                      </button>
                    );
                  })}
                </div>
                <input
                  type="range"
                  min={0}
                  max={48}
                  step={2}
                  value={advanceOptions.pageTopPadding ?? (s.fullBleed ? 0 : 12)}
                  onChange={(e) =>
                    onUpdateAdvanceOptions({ pageTopPadding: Number(e.target.value) })
                  }
                  className="w-full accent-emerald-600 cursor-pointer"
                />
              </div>

              {/* 2. Block Layout (jika Katalog) */}
              {selectedBlock.type === 'catalog' && (
                <>
                  {renderAdvanceOptionSection()}
                  <hr className="border-slate-100" />
                </>
              )}

              {/* 3. Tata Letak & Spasi */}
              <section className="space-y-3.5">
                <h3 className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#64748B]">
                  Tata Letak &amp; Spasi
                </h3>

                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1.5">
                    Posisi Isi di Dalamnya
                  </label>
                  <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 rounded-lg">
                    {(
                      [
                        { id: 'left', icon: <AlignLeft className="w-3.5 h-3.5" />, label: 'Kiri' },
                        { id: 'center', icon: <AlignCenter className="w-3.5 h-3.5" />, label: 'Tengah' },
                        { id: 'right', icon: <AlignRight className="w-3.5 h-3.5" />, label: 'Kanan' },
                      ] as const
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => updateStyle({ align: opt.id })}
                        title={opt.label}
                        className={`flex items-center justify-center gap-1 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                          s.align === opt.id
                            ? 'bg-white text-blue-600 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        {opt.icon}
                      </button>
                    ))}
                  </div>
                </div>

          <SliderRow
            label="Lebar Elemen"
            value={`${s.widthPercent}%`}
            min={30}
            max={100}
            current={s.widthPercent}
            onChange={(val) => updateStyle({ widthPercent: val, fullBleed: val < 100 ? false : s.fullBleed })}
          />

          <SliderRow
            label="Tinggi Minimal"
            value={`${s.minHeight}px`}
            min={0}
            max={300}
            current={s.minHeight}
            onChange={(val) => updateStyle({ minHeight: val })}
          />

          {selectedBlock.type === 'image' &&
          (selectedBlock.content.imageShape === 'circle' ||
            selectedBlock.label.toLowerCase().includes('profil')) ? (
            <div className="space-y-3 p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
              <SliderRow
                label="Padding Atas"
                value={`${s.paddingTop ?? s.padding}px`}
                min={0}
                max={48}
                current={s.paddingTop ?? s.padding}
                onChange={(val) => updateStyle({ paddingTop: val })}
              />
              <SliderRow
                label="Padding Bawah"
                value={`${s.paddingBottom ?? s.padding}px`}
                min={0}
                max={48}
                current={s.paddingBottom ?? s.padding}
                onChange={(val) => updateStyle({ paddingBottom: val })}
              />
            </div>
          ) : (
            <SliderRow
              label="Padding Atas & Bawah"
              value={`${s.padding}px`}
              min={0}
              max={40}
              current={s.padding}
              onChange={(val) =>
                updateStyle({
                  padding: val,
                  paddingTop: undefined,
                  paddingBottom: undefined,
                })
              }
            />
          )}

          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="font-medium text-slate-600">Padding Kanan &amp; Kiri</span>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => updateStyle({ paddingX: 0 })}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-semibold border cursor-pointer transition-colors ${
                    (s.paddingX ?? s.padding) === 0
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  0px (Full)
                </button>
                <span className="font-semibold text-slate-800 tabular-nums">
                  {s.paddingX ?? s.padding}px
                </span>
              </div>
            </div>
            <input
              type="range"
              min={0}
              max={40}
              value={s.paddingX ?? s.padding}
              onChange={(e) => updateStyle({ paddingX: Number(e.target.value) })}
              className="w-full accent-blue-600 cursor-pointer"
            />
          </div>

          <SliderRow
            label="Jarak Bawah (Margin)"
            value={`${s.marginBottom}px`}
            min={0}
            max={48}
            current={s.marginBottom}
            onChange={(val) => updateStyle({ marginBottom: val })}
          />
        </section>

        <hr className="border-slate-100" />

        {/* Section 3: Gaya Visual */}
        <section className="space-y-3.5">
          <h3 className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#64748B]">
            Gaya Visual
          </h3>

          <SliderRow
            label="Lengkung Sudut"
            value={`${s.borderRadius}px`}
            min={0}
            max={36}
            current={s.borderRadius}
            onChange={(val) => updateStyle({ borderRadius: val })}
          />

          <SliderRow
            label="Efek Kaca (Blur)"
            value={`${s.blur}px`}
            min={0}
            max={24}
            current={s.blur}
            onChange={(val) => updateStyle({ blur: val })}
          />

          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">
              Efek Bayangan (Shadow)
            </label>
            <select
              value={s.shadow}
              onChange={(e) => updateStyle({ shadow: e.target.value as ShadowPreset })}
              className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-white outline-none"
            >
              <option value="none">Tanpa Bayangan</option>
              <option value="sm">Halus</option>
              <option value="md">Sedang</option>
              <option value="lg">Tegas</option>
            </select>
            {s.shadow !== 'none' && (
              <div className="mt-2 flex items-center justify-between gap-2">
                <span className="text-[11px] font-medium text-slate-600">Warna Shadow</span>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={s.shadowColor || '#0F172A'}
                    onChange={(e) => updateStyle({ shadowColor: e.target.value })}
                    className="w-7 h-7 rounded border border-slate-200 p-0.5 cursor-pointer bg-white"
                  />
                  {s.shadowColor && (
                    <button
                      type="button"
                      onClick={() => updateStyle({ shadowColor: undefined })}
                      className="px-2 py-1 rounded border border-slate-200 text-[10px] font-semibold text-slate-600 hover:bg-slate-50 cursor-pointer"
                    >
                      Default
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Warna Latar</label>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={s.backgroundColor === 'transparent' ? '#ffffff' : s.backgroundColor}
                  onChange={(e) => updateStyle({ backgroundColor: e.target.value })}
                  className="w-8 h-8 rounded border border-slate-200 p-0.5 cursor-pointer shrink-0"
                />
                <button
                  type="button"
                  onClick={() => updateStyle({ backgroundColor: 'transparent' })}
                  className="text-[11px] px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600 cursor-pointer"
                >
                  Transparan
                </button>
              </div>
            </div>

            {/* Warna Teks: Default Ikut Template + Opsi Kustom */}
            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-slate-700">Warna Teks</span>
                <div className="inline-flex rounded-lg bg-slate-200/70 p-0.5">
                  <button
                    type="button"
                    onClick={() =>
                      updateStyle({
                        useThemeTextColor: true,
                        textColor: theme.textColor,
                      })
                    }
                    className={`px-2 py-0.5 rounded-md text-[10px] font-semibold transition-colors cursor-pointer ${
                      !isCustomTextColor
                        ? 'bg-white text-emerald-700 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Ikut Template
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      updateStyle({
                        useThemeTextColor: false,
                        textColor: s.textColor || theme.textColor,
                      })
                    }
                    className={`px-2 py-0.5 rounded-md text-[10px] font-semibold transition-colors cursor-pointer ${
                      isCustomTextColor
                        ? 'bg-white text-emerald-700 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Kustom
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={isCustomTextColor ? s.textColor : theme.textColor}
                  onChange={(e) =>
                    updateStyle({
                      useThemeTextColor: false,
                      textColor: e.target.value,
                    })
                  }
                  className="w-8 h-8 rounded-lg border border-slate-200 p-0.5 cursor-pointer shrink-0 bg-white"
                />
                <div className="flex items-center gap-1.5 flex-wrap">
                  {[
                    { color: '#FFFFFF', title: 'Putih' },
                    { color: '#0F172A', title: 'Gelap' },
                    { color: theme.textColor, title: 'Warna Template' },
                    { color: theme.accentColor, title: 'Aksen Tema' },
                  ].map((sw, idx) => {
                    const activeColor = isCustomTextColor ? s.textColor : theme.textColor;
                    return (
                      <button
                        key={`${sw.color}_${idx}`}
                        type="button"
                        title={sw.title}
                        onClick={() =>
                          updateStyle({
                            useThemeTextColor: false,
                            textColor: sw.color,
                          })
                        }
                        style={{ backgroundColor: sw.color }}
                        className={`w-6 h-6 rounded-full border cursor-pointer transition-transform ${
                          activeColor.toLowerCase() === sw.color.toLowerCase() && isCustomTextColor
                            ? 'ring-2 ring-emerald-500 ring-offset-1 border-slate-300 scale-105'
                            : 'border-slate-300 hover:scale-105'
                        }`}
                      />
                    );
                  })}
                </div>
              </div>

              <p className="text-[11px] text-slate-500 leading-snug">
                {isCustomTextColor
                  ? isContainerLike
                    ? 'Warna kustom aktif — otomatis diterapkan ke teks di dalam kartu yang mengikuti template.'
                    : 'Menggunakan warna teks kustom untuk elemen ini.'
                  : 'Default mengikuti warna template (atau warna kartu pembungkusnya).'}
              </p>

              {isContainerLike && isCustomTextColor && (
                <button
                  type="button"
                  onClick={() =>
                    onUpdateBlock(selectedBlock.id, (blk) => ({
                      ...blk,
                      children: applyInheritToDescendants(blk.children),
                    }))
                  }
                  className="w-full py-1.5 px-2.5 rounded-lg bg-white border border-emerald-200 text-[11px] font-semibold text-emerald-700 hover:bg-emerald-50 transition-colors cursor-pointer"
                >
                  Samakan Semua Teks di Dalam Kartu
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">
                Garis Tepi ({s.borderWidth}px)
              </label>
              <input
                type="range"
                min={0}
                max={16}
                value={s.borderWidth}
                onChange={(e) => updateStyle({ borderWidth: Number(e.target.value) })}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Warna Tepi</label>
              <input
                type="color"
                value={s.borderColor}
                onChange={(e) => updateStyle({ borderColor: e.target.value })}
                className="w-full h-8 rounded border border-slate-200 p-0.5 cursor-pointer"
              />
            </div>
          </div>
        </section>
      </div>
            );
          })()}
        </div>
      </div>
    );
  };

  return (
    <aside className="w-80 bg-white border-l border-slate-100 flex flex-col shrink-0 h-full overflow-hidden">
      <div className="px-4 py-2.5 border-b border-slate-100 flex items-center justify-between gap-2 bg-white shrink-0">
        <span className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#64748B]">
          {inspectorMode === 'navbar' ? 'Pengaturan Navbar' : 'Pengaturan'}
        </span>
        <button
          type="button"
          onClick={() =>
            onChangeInspectorMode(inspectorMode === 'navbar' ? 'element' : 'navbar')
          }
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-[11px] font-semibold cursor-pointer transition-colors ${
            inspectorMode === 'navbar'
              ? 'bg-emerald-600 text-white border-emerald-600'
              : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-emerald-300 hover:bg-[#EFF7F4]'
          }`}
        >
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              bottomNavbar.enabled
                ? inspectorMode === 'navbar'
                  ? 'bg-emerald-200'
                  : 'bg-emerald-500'
                : 'bg-slate-300'
            }`}
          />
          <PanelBottom className="w-3.5 h-3.5" />
          <span>Navbar Bawah</span>
        </button>
      </div>

      {inspectorMode === 'navbar' ? renderNavbarSettings() : renderElementSettings()}
    </aside>
  );
}

function ToggleSwitch({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={`relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-emerald-600 ${
        checked ? 'bg-emerald-500' : 'bg-slate-200'
      }`}
    >
      <span
        className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-xs transition-transform ${
          checked ? 'translate-x-4.5' : 'translate-x-0.5'
        }`}
      />
    </button>
  );
}

function LayoutWireframe({ mode }: { mode: BlockLayoutMode }) {
  if (mode === 'default') {
    return (
      <div className="w-full h-full flex flex-col justify-between gap-1 py-0.5">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="flex-1 rounded bg-slate-500/80 px-1.5 flex items-center gap-1.5"
          >
            <div className="w-3 h-3 rounded-xs bg-white/80 shrink-0" />
            <div className="flex-1 h-1 rounded-full bg-white/70" />
          </div>
        ))}
      </div>
    );
  }

  if (mode === 'grid') {
    return (
      <div className="w-full h-full grid grid-cols-2 gap-1 py-0.5">
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            className="rounded bg-slate-500/80 flex items-center justify-center"
          >
            <div className="w-3.5 h-3.5 rounded-xs border border-white/70" />
          </div>
        ))}
      </div>
    );
  }

  if (mode === 'large-image') {
    return (
      <div className="w-full h-full flex flex-col gap-1 py-0.5">
        <div className="flex-1 rounded bg-slate-500/80 flex flex-col justify-between p-1.5">
          <div className="flex-1 flex items-center justify-center">
            <div className="w-4 h-4 rounded-xs border border-white/70" />
          </div>
          <div className="h-1 w-3/4 rounded-full bg-white/80" />
        </div>
      </div>
    );
  }

  // compact
  return (
    <div className="w-full h-full flex flex-col justify-center py-0.5">
      <div className="w-full h-full rounded bg-slate-300/80 p-1.5 flex flex-col justify-between gap-1">
        <div className="flex items-center gap-1.5">
          <div className="w-4 h-4 rounded-xs bg-white/90 shrink-0" />
          <div className="flex-1 space-y-1">
            <div className="h-1 w-4/5 rounded-full bg-white/90" />
            <div className="h-1 w-3/5 rounded-full bg-white/70" />
          </div>
        </div>
        <div className="w-full py-0.5 rounded bg-slate-500/75 text-[7px] font-bold text-white text-center leading-none">
          CTA
        </div>
      </div>
    </div>
  );
}

function SliderRow({
  label,
  value,
  min,
  max,
  current,
  onChange,
}: {
  label: string;
  value: string;
  min: number;
  max: number;
  current: number;
  onChange: (val: number) => void;
}) {
  return (
    <div>
      <div className="flex items-center justify-between text-xs mb-1">
        <span className="font-medium text-slate-600">{label}</span>
        <span className="font-mono text-[11px] text-emerald-700 bg-[#EFF7F4] px-1.5 py-0.5 rounded tabular-nums">
          {value}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={current}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-emerald-500 cursor-pointer"
      />
    </div>
  );
}
