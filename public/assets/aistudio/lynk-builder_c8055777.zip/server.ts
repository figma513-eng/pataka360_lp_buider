import express from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import type {
  AccessSettingsConfig,
  AnalyticsEventRecord,
  ProjectRecord,
} from './src/types/builder.ts';
import {
  extractInstagramInfo,
  extractTikTokId,
  isDirectVideoUrl,
  isValidFacebookVideoUrl,
  isValidInstagramVideoUrl,
  isValidTikTokUrl,
} from './src/utils/videoHelpers.ts';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const DATA_DIR = path.join(__dirname, '.data');
const STORE_FILE = path.join(DATA_DIR, 'lynk-server-store.json');

interface StoredProjectEntry {
  record: ProjectRecord;
  renderedHtml: string;
  savedAt: number;
}

interface ServerStoreData {
  projects: Record<string, StoredProjectEntry>;
  events: AnalyticsEventRecord[];
  accessSettings?: AccessSettingsConfig;
}

let storeCache: ServerStoreData | null = null;
let writeQueue: Promise<void> = Promise.resolve();

function defaultServerAccessSettings(): AccessSettingsConfig {
  const now = Date.now();
  return {
    allUsersSuperAdmin: true,
    autoGrantSuperAdminOnJoin: true,
    defaultRole: 'super_admin',
    activeMemberId: 'owner-super-admin',
    members: [
      {
        id: 'owner-super-admin',
        name: 'Super Admin Utama',
        email: 'owner@lynkbuilder.local',
        role: 'super_admin',
        isActive: true,
        unitScope: 'all',
        permissions: {
          editor: true,
          projects: true,
          publishing: true,
          ads_wa: true,
          analytics: true,
          export_backup: true,
          access_control: true,
        },
        createdAt: now,
      },
    ],
    updatedAt: now,
  };
}

async function loadServerStore(): Promise<ServerStoreData> {
  if (storeCache) return storeCache;
  try {
    const raw = await fs.readFile(STORE_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as Partial<ServerStoreData>;
    storeCache = {
      projects: parsed.projects && typeof parsed.projects === 'object' ? parsed.projects : {},
      events: Array.isArray(parsed.events) ? parsed.events : [],
      accessSettings: parsed.accessSettings || defaultServerAccessSettings(),
    };
  } catch {
    storeCache = { projects: {}, events: [], accessSettings: defaultServerAccessSettings() };
  }
  return storeCache;
}

function persistServerStore(data: ServerStoreData): Promise<void> {
  storeCache = data;
  writeQueue = writeQueue
    .then(async () => {
      await fs.mkdir(DATA_DIR, { recursive: true });
      const tmpFile = `${STORE_FILE}.tmp`;
      await fs.writeFile(tmpFile, JSON.stringify(data), 'utf-8');
      await fs.rename(tmpFile, STORE_FILE);
    })
    .catch(() => {
      // Ignore transient disk errors
    });
  return writeQueue;
}

function normalizeServerSlug(raw: string, fallback = 'unit-usaha'): string {
  const cleaned = (raw || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/-{2,}/g, '-')
    .replace(/^-+|-+$/g, '');
  return cleaned || fallback;
}

function normalizeHostHeader(rawHost?: string): string {
  return (rawHost || '').trim().toLowerCase().split(':')[0] || '';
}

function renderStatusHtml(title: string, message: string): string {
  return `<!doctype html><html lang="id"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0"/><title>${title}</title><style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;font-family:-apple-system,BlinkMacSystemFont,sans-serif;background:#F7F9F8;color:#0F172A;box-sizing:border-box;}.box{max-width:420px;width:100%;background:#FFFFFF;border:1px solid #E2E8F0;border-radius:16px;padding:28px;text-align:center;}h1{margin:0 0 8px;font-size:18px;}p{margin:0;font-size:13px;color:#475569;line-height:1.6;}</style></head><body><div class="box"><h1>${title}</h1><p>${message}</p></div></body></html>`;
}

function getMetaCapiToken(): string {
  const raw = process.env.META_CAPI_ACCESS_TOKEN?.trim() || '';
  if (!raw) return '';
  const lower = raw.toLowerCase();
  if (['-', 'skip', 'none', 'null', 'undefined', 'belum', 'n/a'].includes(lower)) {
    return '';
  }
  return raw;
}

async function forwardToMetaCapi(
  pixelId: string,
  event: AnalyticsEventRecord,
  metaEventName: string,
  testEventCode?: string,
  clientIp?: string,
  userAgent?: string
) {
  const token = getMetaCapiToken();
  if (!token || !pixelId) return;

  const eventName =
    event.eventType === 'page_view'
      ? 'PageView'
      : event.eventType === 'form_submit'
      ? 'Lead'
      : metaEventName || 'Lead';

  const payload: Record<string, unknown> = {
    data: [
      {
        event_name: eventName,
        event_time: Math.floor((event.createdAt || Date.now()) / 1000),
        event_id: event.id,
        action_source: 'website',
        user_data: {
          client_ip_address: clientIp || undefined,
          client_user_agent: userAgent || undefined,
        },
        custom_data: {
          content_name: event.ctaLabel || event.projectTitle,
          content_category: event.channel,
          currency: 'IDR',
          value: typeof event.orderValue === 'number' ? event.orderValue : 0,
        },
      },
    ],
  };

  if (testEventCode?.trim()) {
    payload.test_event_code = testEventCode.trim();
  }

  try {
    await fetch(
      `https://graph.facebook.com/v21.0/${encodeURIComponent(pixelId)}/events?access_token=${encodeURIComponent(token)}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }
    );
  } catch {
    // Jangan ganggu response user jika Meta CAPI timeout
  }
}

function isPrivateOrBlockedHost(hostname: string): boolean {
  const host = hostname.toLowerCase();
  if (
    host === 'localhost' ||
    host.endsWith('.localhost') ||
    host.endsWith('.local') ||
    host === 'metadata.google.internal'
  ) {
    return true;
  }
  const ipType = net.isIP(host);
  if (ipType === 4) {
    const parts = host.split('.').map(Number);
    if (
      parts[0] === 10 ||
      parts[0] === 127 ||
      parts[0] === 0 ||
      (parts[0] === 169 && parts[1] === 254) ||
      (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) ||
      (parts[0] === 192 && parts[1] === 168)
    ) {
      return true;
    }
  } else if (ipType === 6) {
    if (host === '::1' || host.startsWith('fc') || host.startsWith('fd') || host.startsWith('fe80')) {
      return true;
    }
  }
  return false;
}

function unescapeJsonString(raw?: string): string | null {
  if (!raw) return null;
  try {
    return JSON.parse(`"${raw}"`);
  } catch {
    return raw.replace(/\\\//g, '/').replace(/\\u0025/g, '%').replace(/&amp;/g, '&');
  }
}

async function fetchWithTimeout(
  url: string,
  options: RequestInit = {},
  timeoutMs = 7000
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...options,
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timer);
  }
}

async function verifyPlayableVideoUrl(videoUrl: string | null): Promise<string | null> {
  if (!videoUrl) return null;
  try {
    const head = await fetchWithTimeout(
      videoUrl,
      {
        method: 'HEAD',
        headers: { 'User-Agent': USER_AGENT },
      },
      4500
    );
    const corp = (head.headers.get('cross-origin-resource-policy') || '').toLowerCase();
    const ct = (head.headers.get('content-type') || '').toLowerCase();
    if (head.ok && corp !== 'same-origin' && (ct.includes('video') || ct.includes('octet-stream') || !ct)) {
      return videoUrl;
    }
  } catch {
    // ignore
  }
  return null;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '25mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, capiConfigured: Boolean(getMetaCapiToken()) });
  });

  // Custom domain host mapping middleware untuk domain kustom per unit usaha
  app.use(async (req, res, next) => {
    if (req.method !== 'GET' || req.path.startsWith('/api/') || req.path.startsWith('/p/')) {
      return next();
    }
    const reqHost = normalizeHostHeader(req.headers.host);
    if (!reqHost || reqHost === 'localhost' || reqHost.endsWith('.run.app')) {
      return next();
    }
    const store = await loadServerStore();
    const matched = Object.values(store.projects).find((entry) => {
      const pub = entry.record.project.publishing;
      if (!pub?.isPublished || !pub.useCustomDomain || !pub.customDomain) return false;
      return pub.customDomain.toLowerCase() === reqHost;
    });
    if (!matched) return next();
    const cleanPath = req.path.replace(/^\/+|\/+$/g, '');
    const slug = normalizeServerSlug(matched.record.project.publishing?.slug || '', '');
    if (cleanPath === '' || cleanPath === slug) {
      return res.status(200).setHeader('Content-Type', 'text/html; charset=utf-8').send(matched.renderedHtml);
    }
    return next();
  });

  app.post('/api/projects/:id/save', async (req, res) => {
    const projectId = req.params.id;
    const body = req.body as { record?: ProjectRecord; renderedHtml?: string };
    if (!body?.record?.project || typeof body.renderedHtml !== 'string') {
      return res.status(400).json({ error: 'Payload proyek tidak valid' });
    }
    const store = await loadServerStore();
    const requestedSlug = normalizeServerSlug(
      body.record.project.publishing?.slug || body.record.project.title || projectId,
      'unit-usaha'
    );

    const conflict = Object.values(store.projects).find(
      (entry) =>
        entry.record.id !== projectId &&
        normalizeServerSlug(entry.record.project.publishing?.slug || '', '') === requestedSlug
    );
    if (conflict) {
      return res.status(409).json({
        error: `Slug "/p/${requestedSlug}" sudah dipakai oleh unit usaha "${conflict.record.project.title}". Gunakan slug lain.`,
      });
    }

    const savedAt = Date.now();
    const updatedRecord: ProjectRecord = {
      ...body.record,
      lastSavedAt: savedAt,
      project: {
        ...body.record.project,
        publishing: {
          slug: requestedSlug,
          customDomain: normalizeHostHeader(body.record.project.publishing?.customDomain),
          useCustomDomain: Boolean(body.record.project.publishing?.useCustomDomain),
          isPublished: Boolean(body.record.project.publishing?.isPublished),
          publishedAt: body.record.project.publishing?.publishedAt,
          seoTitle: body.record.project.publishing?.seoTitle,
          seoDescription: body.record.project.publishing?.seoDescription,
        },
      },
    };

    store.projects[projectId] = {
      record: updatedRecord,
      renderedHtml: body.renderedHtml,
      savedAt,
    };
    await persistServerStore(store);

    return res.json({ ok: true, savedAt, slug: requestedSlug });
  });

  app.post('/api/projects/:id/publish', async (req, res) => {
    const projectId = req.params.id;
    const body = req.body as { record?: ProjectRecord; renderedHtml?: string };
    if (!body?.record?.project || typeof body.renderedHtml !== 'string') {
      return res.status(400).json({ error: 'Payload publikasi tidak valid' });
    }
    const store = await loadServerStore();
    const requestedSlug = normalizeServerSlug(
      body.record.project.publishing?.slug || body.record.project.title || projectId,
      'unit-usaha'
    );

    const conflict = Object.values(store.projects).find(
      (entry) =>
        entry.record.id !== projectId &&
        normalizeServerSlug(entry.record.project.publishing?.slug || '', '') === requestedSlug
    );
    if (conflict) {
      return res.status(409).json({
        error: `Slug "/p/${requestedSlug}" sudah dipakai oleh unit usaha "${conflict.record.project.title}". Pilih slug unik terlebih dahulu.`,
      });
    }

    const now = Date.now();
    const updatedRecord: ProjectRecord = {
      ...body.record,
      lastSavedAt: now,
      project: {
        ...body.record.project,
        publishing: {
          slug: requestedSlug,
          customDomain: normalizeHostHeader(body.record.project.publishing?.customDomain),
          useCustomDomain: Boolean(body.record.project.publishing?.useCustomDomain),
          isPublished: true,
          publishedAt: now,
          seoTitle: body.record.project.publishing?.seoTitle,
          seoDescription: body.record.project.publishing?.seoDescription,
        },
      },
    };

    store.projects[projectId] = {
      record: updatedRecord,
      renderedHtml: body.renderedHtml,
      savedAt: now,
    };
    await persistServerStore(store);

    return res.json({ ok: true, savedAt: now, slug: requestedSlug });
  });

  app.delete('/api/projects/:id', async (req, res) => {
    const projectId = req.params.id;
    const store = await loadServerStore();
    if (store.projects[projectId]) {
      delete store.projects[projectId];
      await persistServerStore(store);
    }
    return res.json({ ok: true });
  });

  app.post('/api/track/event', async (req, res) => {
    const raw = (req.body || {}) as Partial<AnalyticsEventRecord>;
    if (!raw.projectId || !raw.eventType) {
      return res.status(400).json({ error: 'Data event tidak lengkap' });
    }

    const ua = String(req.headers['user-agent'] || '');
    const inferredDevice: 'mobile' | 'desktop' =
      raw.deviceType === 'mobile' || raw.deviceType === 'desktop'
        ? raw.deviceType
        : /mobile|android|iphone|ipad|ipod/i.test(ua)
        ? 'mobile'
        : 'desktop';

    const event: AnalyticsEventRecord = {
      id: raw.id || `evt_${crypto.randomBytes(6).toString('hex')}`,
      projectId: String(raw.projectId),
      projectTitle: String(raw.projectTitle || 'Unit Usaha'),
      slug: String(raw.slug || ''),
      eventType:
        raw.eventType === 'wa_click' || raw.eventType === 'form_submit'
          ? raw.eventType
          : 'page_view',
      channel: raw.channel || 'organic',
      sourceLabel: String(raw.sourceLabel || 'Organik'),
      ctaLabel: raw.ctaLabel ? String(raw.ctaLabel).slice(0, 80) : undefined,
      waPhone: raw.waPhone ? String(raw.waPhone).slice(0, 24) : undefined,
      orderValue: typeof raw.orderValue === 'number' ? raw.orderValue : undefined,
      utmSource: raw.utmSource ? String(raw.utmSource).slice(0, 60) : undefined,
      utmMedium: raw.utmMedium ? String(raw.utmMedium).slice(0, 60) : undefined,
      utmCampaign: raw.utmCampaign ? String(raw.utmCampaign).slice(0, 80) : undefined,
      utmContent: raw.utmContent ? String(raw.utmContent).slice(0, 80) : undefined,
      clickIdType: raw.clickIdType,
      deviceType: inferredDevice,
      isTest: Boolean(raw.isTest),
      createdAt: typeof raw.createdAt === 'number' ? raw.createdAt : Date.now(),
    };

    const store = await loadServerStore();
    const exists = store.events.some((e) => e.id === event.id);
    if (!exists) {
      store.events = [event, ...store.events].slice(0, 5000);
      await persistServerStore(store);
    }

    const projEntry = store.projects[event.projectId];
    const ads = projEntry?.record.project.adsConfig;
    if (!event.isTest && ads?.metaCapiForwarding && ads.metaPixelId) {
      void forwardToMetaCapi(
        ads.metaPixelId,
        event,
        ads.metaWaEvent || 'Lead',
        ads.metaTestEventCode,
        req.ip,
        ua
      );
    }

    return res.json({ ok: true, id: event.id });
  });

  app.get('/api/analytics', async (req, res) => {
    const store = await loadServerStore();
    const projectId = typeof req.query.projectId === 'string' ? req.query.projectId : '';
    const events = projectId
      ? store.events.filter((ev) => ev.projectId === projectId)
      : store.events;

    return res.json({
      events,
      capiConfiguredOnServer: Boolean(getMetaCapiToken()),
    });
  });

  app.delete('/api/analytics', async (req, res) => {
    const store = await loadServerStore();
    const projectId = typeof req.query.projectId === 'string' ? req.query.projectId : '';
    store.events = projectId
      ? store.events.filter((ev) => ev.projectId !== projectId)
      : [];
    await persistServerStore(store);
    return res.json({ ok: true });
  });

  app.get('/api/access-settings', async (_req, res) => {
    const store = await loadServerStore();
    const settings = store.accessSettings || defaultServerAccessSettings();
    return res.json({ settings });
  });

  app.put('/api/access-settings', async (req, res) => {
    const raw = (req.body as { settings?: AccessSettingsConfig } | undefined)?.settings;
    if (!raw || typeof raw !== 'object' || !Array.isArray(raw.members)) {
      return res.status(400).json({ error: 'Payload access settings tidak valid.' });
    }
    const store = await loadServerStore();
    const allSuper = Boolean(raw.allUsersSuperAdmin);
    const fullPermissions = {
      editor: true,
      projects: true,
      publishing: true,
      ads_wa: true,
      analytics: true,
      export_backup: true,
      access_control: true,
    };
    const nextSettings: AccessSettingsConfig = {
      allUsersSuperAdmin: allSuper,
      autoGrantSuperAdminOnJoin:
        typeof raw.autoGrantSuperAdminOnJoin === 'boolean' ? raw.autoGrantSuperAdminOnJoin : true,
      defaultRole: allSuper ? 'super_admin' : raw.defaultRole || 'super_admin',
      activeMemberId: raw.activeMemberId || raw.members[0]?.id || 'owner-super-admin',
      members: raw.members.map((m, idx) => ({
        id: m.id || `member-${idx + 1}`,
        name: String(m.name || `Pengguna ${idx + 1}`).slice(0, 80),
        email: String(m.email || `user${idx + 1}@tim.local`).slice(0, 120),
        role: allSuper ? 'super_admin' : m.role || 'super_admin',
        isActive: allSuper ? true : Boolean(m.isActive),
        unitScope: allSuper ? 'all' : m.unitScope || 'all',
        permissions:
          allSuper || m.role === 'super_admin'
            ? { ...fullPermissions }
            : m.permissions || { ...fullPermissions },
        createdAt: typeof m.createdAt === 'number' ? m.createdAt : Date.now(),
      })),
      updatedAt: Date.now(),
    };

    store.accessSettings = nextSettings;
    await persistServerStore(store);
    return res.json({ ok: true, settings: nextSettings });
  });

  app.get('/p/:slug', async (req, res) => {
    const slug = normalizeServerSlug(req.params.slug || '', '');
    if (!slug) {
      return res
        .status(404)
        .setHeader('Content-Type', 'text/html; charset=utf-8')
        .send(renderStatusHtml('Halaman Tidak Ditemukan', 'Slug halaman tidak valid.'));
    }

    const store = await loadServerStore();
    const entry = Object.values(store.projects).find(
      (item) => normalizeServerSlug(item.record.project.publishing?.slug || '', '') === slug
    );

    if (!entry) {
      return res
        .status(404)
        .setHeader('Content-Type', 'text/html; charset=utf-8')
        .send(
          renderStatusHtml(
            'Halaman Belum Tersedia',
            `Landing page dengan slug "/p/${slug}" belum disimpan atau dipublikasikan. Silakan klik Simpan & Tayangkan di Lynk Builder.`
          )
        );
    }

    const allowDraftPreview = req.query.preview === '1';
    if (!entry.record.project.publishing?.isPublished && !allowDraftPreview) {
      return res
        .status(403)
        .setHeader('Content-Type', 'text/html; charset=utf-8')
        .send(
          renderStatusHtml(
            'Halaman Masih Berstatus Draft',
            `Unit usaha "${entry.record.project.title}" sudah tersimpan, namun status publikasinya masih Draft. Aktifkan status Tayang Publik di menu Domain & Iklan.`
          )
        );
    }

    return res.status(200).setHeader('Content-Type', 'text/html; charset=utf-8').send(entry.renderedHtml);
  });

  app.get('/api/resolve-video', async (req, res) => {
    const rawUrl = typeof req.query.url === 'string' ? req.query.url.trim() : '';
    const platform = typeof req.query.platform === 'string' ? req.query.platform.trim() : '';

    if (!rawUrl) {
      return res.status(400).json({ error: 'URL wajib diisi' });
    }

    const normalizedInput = rawUrl.startsWith('http://') || rawUrl.startsWith('https://')
      ? rawUrl
      : `https://${rawUrl}`;

    let parsed: URL;
    try {
      parsed = new URL(normalizedInput);
    } catch {
      return res.status(400).json({ error: 'Format URL tidak valid' });
    }

    if ((parsed.protocol !== 'http:' && parsed.protocol !== 'https:') || isPrivateOrBlockedHost(parsed.hostname)) {
      return res.status(400).json({ error: 'URL tidak diizinkan' });
    }

    if (isDirectVideoUrl(normalizedInput)) {
      return res.json({
        canonicalUrl: normalizedInput,
        directVideoUrl: normalizedInput,
        posterUrl: null,
        videoId: null,
      });
    }

    const allowed =
      (platform === 'tiktok' && isValidTikTokUrl(normalizedInput)) ||
      (platform === 'facebook' && isValidFacebookVideoUrl(normalizedInput)) ||
      (platform === 'instagram' && isValidInstagramVideoUrl(normalizedInput));

    if (!allowed) {
      return res.status(400).json({ error: 'URL tidak cocok dengan platform' });
    }

    try {
      let canonicalUrl = normalizedInput;
      let pageHtml = '';

      try {
        const resp = await fetchWithTimeout(normalizedInput, {
          redirect: 'follow',
          headers: {
            'User-Agent': USER_AGENT,
            Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9,id;q=0.8',
          },
        });
        if (resp.url) canonicalUrl = resp.url;
        if (resp.ok) pageHtml = await resp.text();
      } catch {
        // lanjutkan dengan URL asli jika fetch halaman utama timeout
      }

      if (platform === 'tiktok') {
        let videoId = extractTikTokId(canonicalUrl) || extractTikTokId(normalizedInput);
        let posterUrl: string | null = null;

        const targetForOembed = videoId
          ? `https://www.tiktok.com/@tiktok/video/${videoId}`
          : canonicalUrl;

        try {
          const oe = await fetchWithTimeout(
            `https://www.tiktok.com/oembed?url=${encodeURIComponent(targetForOembed)}`,
            { headers: { 'User-Agent': USER_AGENT } },
            5000
          );
          if (oe.ok) {
            const data = (await oe.json()) as {
              thumbnail_url?: string;
              embed_product_id?: string;
              html?: string;
            };
            if (data.thumbnail_url) posterUrl = data.thumbnail_url;
            if (!videoId && data.embed_product_id) videoId = data.embed_product_id;
            if (!videoId && data.html) {
              const m = data.html.match(/player\/v1\/(\d{10,25})|data-video-id="(\d{10,25})"/);
              if (m) videoId = m[1] || m[2] || null;
            }
          }
        } catch {
          // ignore oembed failure
        }

        if (!videoId && pageHtml) {
          const canonMatch = pageHtml.match(/rel="canonical"\s+href="([^"]+)"/i)?.[1];
          if (canonMatch) {
            canonicalUrl = canonMatch;
            videoId = extractTikTokId(canonMatch);
          }
        }

        return res.json({
          canonicalUrl,
          videoId,
          posterUrl,
          directVideoUrl: null,
        });
      }

      if (platform === 'facebook') {
        const canonMatch = pageHtml.match(/rel="canonical"\s+href="([^"]+)"/i)?.[1];
        if (canonMatch && isValidFacebookVideoUrl(canonMatch)) {
          canonicalUrl = canonMatch;
        }

        let directVideoUrl: string | null = null;
        let posterUrl: string | null =
          pageHtml.match(/property="og:image"\s+content="([^"]+)"/i)?.[1]?.replace(/&amp;/g, '&') ??
          null;

        try {
          const pluginResp = await fetchWithTimeout(
            `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(canonicalUrl)}&show_text=false`,
            {
              headers: {
                'User-Agent': USER_AGENT,
                Accept: 'text/html,application/xhtml+xml',
              },
            },
            7000
          );
          if (pluginResp.ok) {
            const pHtml = await pluginResp.text();
            const rawVideo =
              pHtml.match(/"hd_src_no_ratelimit":"([^"]+)"/)?.[1] ||
              pHtml.match(/"hd_src":"([^"]+)"/)?.[1] ||
              pHtml.match(/"sd_src_no_ratelimit":"([^"]+)"/)?.[1] ||
              pHtml.match(/"sd_src":"([^"]+)"/)?.[1] ||
              pHtml.match(/"playable_url_quality_hd":"([^"]+)"/)?.[1] ||
              pHtml.match(/"playable_url":"([^"]+)"/)?.[1];

            const candidate = unescapeJsonString(rawVideo);
            directVideoUrl = await verifyPlayableVideoUrl(candidate);

            if (!posterUrl) {
              const rawThumb =
                pHtml.match(/"thumbnailImage":\{"uri":"([^"]+)"/)?.[1] ||
                pHtml.match(/"preferred_thumbnail":\{"image":\{"uri":"([^"]+)"/)?.[1];
              posterUrl = unescapeJsonString(rawThumb);
            }
          }
        } catch {
          // fallback ke iframe FB jika plugin fetch gagal
        }

        return res.json({
          canonicalUrl,
          directVideoUrl,
          posterUrl,
          videoId: null,
        });
      }

      if (platform === 'instagram') {
        const canonMatch = pageHtml.match(/rel="canonical"\s+href="([^"]+)"/i)?.[1];
        if (canonMatch && isValidInstagramVideoUrl(canonMatch)) {
          canonicalUrl = canonMatch;
        }

        const igInfo = extractInstagramInfo(canonicalUrl) || extractInstagramInfo(normalizedInput);
        let directVideoUrl: string | null = null;
        let posterUrl: string | null =
          pageHtml.match(/property="og:image"\s+content="([^"]+)"/i)?.[1]?.replace(/&amp;/g, '&') ??
          null;

        const rawOgVid = pageHtml.match(/property="og:video(?::secure_url)?"\s+content="([^"]+)"/i)?.[1];
        if (rawOgVid) {
          directVideoUrl = await verifyPlayableVideoUrl(rawOgVid.replace(/&amp;/g, '&'));
        }

        if (!directVideoUrl && igInfo) {
          try {
            const igEmbedResp = await fetchWithTimeout(
              `https://www.instagram.com/${igInfo.kind}/${igInfo.code}/embed/`,
              {
                headers: {
                  'User-Agent': USER_AGENT,
                  Accept: 'text/html,application/xhtml+xml',
                },
              },
              6000
            );
            if (igEmbedResp.ok) {
              const igHtml = await igEmbedResp.text();
              const rawVid = igHtml.match(/"video_url":"([^"]+)"/)?.[1];
              const candidate = unescapeJsonString(rawVid);
              if (candidate) {
                directVideoUrl = await verifyPlayableVideoUrl(candidate);
              }
              if (!posterUrl) {
                const rawImg = igHtml.match(/"display_url":"([^"]+)"/)?.[1];
                posterUrl = unescapeJsonString(rawImg);
              }
            }
          } catch {
            // fallback ke IG embed iframe
          }
        }

        return res.json({
          canonicalUrl,
          videoId: igInfo ? `${igInfo.kind}/${igInfo.code}` : null,
          directVideoUrl,
          posterUrl,
        });
      }

      return res.json({ canonicalUrl, directVideoUrl: null, posterUrl: null, videoId: null });
    } catch {
      return res.status(500).json({ error: 'Gagal memproses tautan video' });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', async (_req, res) => {
      const html = await fs.readFile(path.join(distDir, 'index.html'), 'utf-8');
      res.status(200).setHeader('Content-Type', 'text/html').end(html);
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
